# Configuring your machines and models

Everything about *which machine runs which model for which job* lives in one file, `config.json`. This guide explains it from the ground up. The model names in the shipped file (`gemma4:e4b`, `gemma4:26b-a4b-it-mtp-q4_K_M`, and so on) are **reference values** measured on the original author's hardware. Replace them with yours. Nothing in the system requires those particular names, with the handful of exceptions listed in "Names written into the code" near the end.

Check your work at any time with:

```bash
./show_routing.py      # offline: prints where each kind of job would go, and what to fix
./swarm.py nodes       # online: which machines answer, and which models they hold
./team.py warm         # preload the models
```

`show_routing.py` never contacts a machine. Run it after every edit to `config.json`.

---

## 1. The model in one minute

- A **node** is one machine running Ollama (it has a name and a URL).
- A **model** is a tag that node serves (`gemma4:e4b`, `llama3.3:70b`, whatever `ollama list` shows on that machine).
- Every model has a **capability** from 1 to 4: *how hard a job it is allowed to be given.* You set it by judgement:

| Capability | Meaning | Typical model |
|---|---|---|
| 1 | trivial jobs: classify, one-line answers | about 2B parameters |
| 2 | simple jobs: boilerplate files, reading and summarising | about 4B to 8B |
| 3 | a middle rung. Nothing in the shipped settings requires exactly 3, but a model rated 3 still qualifies for any job needing 3 or lower | about 12B |
| 4 | hard jobs: planning, writing the items of a set, judging | your strongest model |

- Every job has a **floor**: the minimum capability it needs. A job may go to any enabled model whose capability is at or above its floor. A model below the floor is never given it.
- Among the models that qualify, the router prefers the faster one for easy jobs and the better one for hard jobs, and avoids a machine that is already busy.

**The rule that makes one model enough:** if you have a single model rated 4, every floor (1, 2 and 4) is satisfied by it, so every job goes there. See recipe A.

---

## 2. Difficulty levels

There are two places a floor is decided.

**The one-prompt router (`./swarm.py "question"`).** It sorts a prompt into one of four difficulty tiers using cheap keyword rules, and asks a small model for a second opinion only when the prompt is borderline. Each tier needs a minimum capability, set in `routing.tier_floor`:

| Tier | Shipped floor | Shipped lean |
|---|---|---|
| trivial | 1 | speed matters most |
| simple | 1 | speed matters most |
| moderate | 2 | quality starts to matter |
| hard | 4 | quality matters most |

The lean comes from `routing.speed_weight_by_tier` and `routing.quality_weight_by_tier`. With the shipped numbers: if you own a small fast model, trivial and simple prompts go to it, while moderate and hard prompts go to your strongest model unless the small one is much faster. If no model meets a floor, the router takes the strongest model available instead of failing.

**The team and the loop (`./team.py do`, `ralph.sh`).** A planner splits the job into pieces and gives each piece floor 2 (routine files) or floor 4 (hard files). Planning itself and, for a stored set, writing every item are floor 4. `team.py` does **not** fall back below the floor for planning: with no capability-4 model enabled you get `no floor-4 model free` and `could not decompose`. During a fan-out, the scheduler also charges extra for spending an over-qualified model on an easy piece (`team.overkill_penalty`), so a fleet with a few small models keeps the strong one free for the hard pieces.

If you have only one tier of model, set its capability to 4 and ignore everything about tiers.

---

## 3. Recipes

### A. One model, everything goes there

Assumes this model is strong enough to write hard code and plan (capability 4). Edit `config.json`:

1. Keep one node, enabled. Put your model tag in its `models` list.
2. In the `models` block, add or edit the entry with `"capability": 4`.
3. If the model is **not** Gemma, also do step 4. If it is Gemma, skip it.
4. Tell the family gate about your model (see section 5): put `"family": "yourfamily"` on the model, then set `team.restrict_to_family` and `team.primary_family` to `"yourfamily"`, or delete `team.restrict_to_family`.
5. Point the helpers at it (section 6): set `team.judge_model` to your model tag (or delete the key), and `routing.classifier_model` to your model tag.
6. `./show_routing.py`, then `./swarm.py nodes`, then `./team.py warm`.

A complete working config for a single non-Gemma model on this machine:

```json
{
  "nodes": [
    {
      "name": "mac",
      "url": "http://127.0.0.1:11434",
      "models": ["llama3.3:70b"],
      "max_parallel": 1,
      "pin_ctx": 32768,
      "enabled": true
    }
  ],
  "models": {
    "llama3.3:70b": {
      "capability": 4,
      "quality": 1.0,
      "max_ctx": 32768,
      "decode_tps_hint": 20,
      "family": "llama"
    }
  },
  "routing": { "classifier_model": "llama3.3:70b", "tier_floor": [1, 1, 2, 4] },
  "team": { "restrict_to_family": "llama", "primary_family": "llama" }
}
```

(Keep the node name `mac`; see section 6.) The shipped file has more keys with sensible defaults. The minimal one above is enough for the routing tables; for a real run start from the shipped `config.json` and change the pieces listed in steps 1-5.

What was tested for this recipe (offline, using the same selection code a run uses): with one model rated 4 and the family gate matching, the one-prompt router sent all four difficulty tiers to it, and the team planner, floor-2 writer and judge all resolved to it. With one Gemma model set to capability 4 and the shipped config otherwise unchanged, the same held. With a non-Gemma model left under `restrict_to_family: gemma`, the one-prompt router still worked but every team role resolved to nobody. That is the most likely first-run mistake, and `show_routing.py` reports it.

### B. Add a smaller model for easy work

Add the small model to the same node only if the machine can hold both (otherwise use a second node, recipe C). Put it in `models` with a lower capability:

```json
"gemma4:e4b": { "capability": 2, "quality": 0.72, "max_ctx": 32768, "decode_tps_hint": 40, "family": "gemma" }
```

and add its tag to a node's `models` list. A node that lists two models should keep `"single_slot": true` (the default whenever it lists more than one): it means the machine can only keep one model loaded at a time, so the scheduler counts a swap as a reload. Prefer putting each model on its own machine.

### C. Add more machines

Copy a node block, give it a unique `name`, its `url` (`http://ADDRESS:11434`) and its `models`. The other machine's Ollama must be reachable (see `SETUP.md`). More machines let work run in parallel, one request at a time per machine unless you raise that node's `max_parallel`.

### D. Take a machine out for a while

Set `"enabled": false` on its node. Nothing is routed there and nothing else changes. Delete nothing.

---

## 4. Field reference

### A node (an entry in `nodes`)

| Field | What it does | Touch it when |
|---|---|---|
| `name` | Unique label used in logs and routing | always set |
| `url` | Where Ollama answers, `http://host:11434` | always set |
| `os` | Label only | never needed |
| `models` | Tags this machine serves. Pull each with `ollama pull`. | always set |
| `enabled` | `false` takes the node out of every selection | maintenance |
| `max_parallel` | Requests this node may run at once. Start at 1. | after you have tested concurrency on that box |
| `single_slot` | Machine keeps only one model resident (default true if it lists more than one) | two models on one box |
| `bias` | Multiplier for how much the router likes this node (above 1 prefers it, below 1 avoids it) | a slow or shared machine, such as your own laptop |
| `model_bias` | `{ "tag": number }` per-model preference. Below 0.5 takes the model out of normal selection while keeping it listed. | keep a model in reserve |
| `pin_ctx` | Fixed context window to load the model with. Ollama reloads a model whenever the window changes (tens of seconds), so a pinned size avoids repeated reloads. Never above `max_ctx`. | set it on every node; 32768 is a safe start |
| `max_ctx` | Largest window this node will ever use (number, or `{ "tag": number }`) | the box runs out of memory at large windows |
| `cooldown_s` | Seconds to rest between requests to this node | a box that crashes when hit back to back |
| `sample` | Sampling settings: `temperature`, `top_p`, `top_k`, `min_p` | the model loops under greedy decoding. The shipped `writer` node sets these for the 26B model for that reason. |
| `think_budget`, `think_budget_message` | Cap on reasoning tokens for a thinking model, then a nudge to answer | thinking models only |
| `notes` | Free text. Ignored by the code. Write down why you chose the numbers. | always worth filling in |

### A model (an entry in `models`, keyed by tag)

| Field | What it does |
|---|---|
| `capability` | 1 to 4, the hardest job it may be given (section 1) |
| `quality` | 0 to 1. How much you trust its answers relative to your other models. Only the relative size matters. Use about 1.0 for your best and scale the others down. |
| `max_ctx` | Largest window this model should be given, in tokens |
| `decode_tps_hint` | Rough tokens per second, used until real measurements exist. After the first runs the system uses what it measured. |
| `thinking_tokens` | How many reasoning tokens this model typically spends before answering. Raises its time estimate. Use 0 or a small number for a model that does not think. |
| `family` | A label for the model lineage, used only by the family gate (section 5) |

A model listed on a node but missing from the `models` block is not an error: the system guesses a capability from the tag name (a name containing `e2b` is 1, `e4b` is 2, `12b` is 3, anything else is 4) and a window of 16384. That guess is why you should always write the entry yourself.

### `routing`

| Key | Meaning |
|---|---|
| `tier_floor` | Four numbers, the capability required for trivial, simple, moderate, hard prompts. Shipped `[1, 1, 2, 4]`. |
| `speed_weight_by_tier`, `quality_weight_by_tier` | How strongly speed and quality count at each tier. Shipped values favour speed for easy prompts and quality for hard ones. |
| `classifier_model` | The small model asked for a second opinion on a borderline prompt. Optional: if no enabled node serves it, the router simply keeps its keyword-based decision. |
| `think_by_tier` | Whether to turn reasoning on for each tier (for models that support it) |
| `max_escalations` | How many times a model may reply `ESCALATE` to bump a job to a stronger model |
| `cold_start_penalty_s`, `warm_window_s` | How much a model that is not currently loaded is penalised against one that is |

### `team`

| Key | Meaning |
|---|---|
| `restrict_to_family` | Only models with this `family` may do team work. Delete the key to allow any model. |
| `primary_family` | The family preferred for drafting; others get a lower score if you mix |
| `judge_model` | Ordered list of tags that settle disagreements and judge results. The first one an enabled node serves wins. Delete it and the most capable free model at `judge_floor` is used. |
| `judge_floor`, `critic_floor`, `reduce_floor` | Minimum capability for judging, reviewing and the final combining step |
| `overkill_penalty` | How much extra a strong model is charged for an easy piece, so it stays free for hard ones |
| `unmeasured_penalty` | Extra charge on a model with no speed samples yet, so a good guess does not beat a measured model |
| `warm_first_use` | Preload models before the first run in a session |

---

## 5. Non-Gemma models and the family gate

The original project was built and measured on the Gemma family, and `team.restrict_to_family: "gemma"` makes the team refuse any model not labelled `"family": "gemma"`. It was added after a different family, used as a reviewer, flagged correct code as broken with confident wrong reasoning. That is a measurement on one set of models, not a rule of nature, so the gate is yours to change.

To use another family, do both of these:

1. Give each of your models `"family": "<label>"` in the `models` block (any label you like).
2. Set `team.restrict_to_family` to that same label, or delete the key to allow any model. Set `team.primary_family` to match.

If you skip this, a model with no `family` counts as `unknown`, the gate blocks it, and every team role resolves to nobody. The symptom is `no floor-4 model free`, then `could not decompose`. `./show_routing.py` prints `BLOCKED by the gate` next to each affected model.

If you mix families, check the judge by hand at first: the author's one cross-family trial produced false alarms, and each false alarm triggers an escalation.

---

## 6. Names written into the code

Two small helpers name a node and a model directly in the code instead of reading them from config. They are optional features, and they are the only places a specific name matters.

| Where | What it does | What to change |
|---|---|---|
| `ground.py`, `READER_CANDIDATES` and `GROUND_MODEL` | Reads your existing files so a vague request can be answered from real code. Tries the listed (node, model) pairs in order. If none is usable, it is skipped and the run proceeds ungrounded. | Edit the list to name nodes and models in your own `config.json`. |
| `judge.py`, `DEFAULT_NODE` | The node that answers yes/no rule questions inside a check (the "opinion gate"). Uses the first model that node lists. If it cannot be reached, the rule passes. | Name your node with `JUDGE_NODE=yournode` and optionally `JUDGE_MODEL=tag` in the environment, or keep a node called `mac`. |
| `ground.py` entry-point guard | Same node name (`mac`). Skipped if there is no such node. | Keep a node called `mac` (it need not be a Mac), or accept that it is skipped. |

Everything else, including the planner, the writers, the judge for the team and the router, is chosen from `config.json` by capability, quality and speed.

`./show_routing.py` prints, under "Helpers that name a machine in the code", which node and model each of these will use right now, and an "Optional" note when one is pointing at something you do not have.

---

## 7. Warming and keeping models loaded

A model that is not loaded costs 10 to 70 seconds the first time it is used, which is often longer than the job. Two things reduce that.

- **`./team.py warm`** loads a model on every enabled node in parallel. By default it loads the smallest model on each node. Use `--floor 4` to load the model rated 4 instead, and `--node NAME` (repeatable) to warm only some machines.

  ```bash
  ./team.py warm --floor 4          # make sure the strong writer is resident
  ./team.py warm --node writer
  ```

- **Keep it resident on the machine.** Warming only works while Ollama keeps the model in memory. On a dedicated box set `OLLAMA_KEEP_ALIVE=-1` in that machine's Ollama service (`SETUP.md` shows how). On the computer you work on, leave the short default so the model frees its memory.

Also set `pin_ctx` so the window never changes between jobs. Every change of window forces a reload.

Re-measure after changing models or hardware:

```bash
./team.py calibrate     # compares predicted vs actual timing per node
```

---

## 8. Checklist after any change

1. `./show_routing.py` shows no "Fix before running" and the right model against each row.
2. `./swarm.py nodes` shows every enabled machine `ok` and your model tags listed. For a missing tag, run `ollama pull TAG` on that machine.
3. `./team.py warm` reports every node warm.
4. A small test request: `./team.py do "write hello.py that prints hello"` in an empty folder.
