# START_HERE

Audience: an AI coding agent that has been handed this folder and told to get a person running their own job. A human can read it too. The human-facing explanation is `SWARM_MAP.html` (three interactive charts, no setup needed). This file is the procedure.

## 1. What this is

A runner that drives local Ollama models as one team. The operator supplies:

- **A check**: a script in the project folder that exits 0 only when the work is acceptable, and otherwise prints one line per problem, each starting `CHECK FAILED:` and saying what was measured and what to change.
- **A request**: one sentence naming what to produce and where to store it.

`ralph.sh` repeats the same request every round. Each round runs the check, and if it fails it calls `team.py do`, which plans, asks a model for one piece, tests the piece against the check on a throwaway copy, and keeps it only if it introduces no new failures. The loop ends when a round opens with the check exiting 0. Nothing is kept that the check did not accept.

Terms used below:

| Term | Meaning |
|---|---|
| node | one machine running Ollama (name + URL), declared in `config.json` |
| model | an Ollama tag a node serves |
| capability | 1 to 4, set per model in `config.json`; the hardest job it may be given |
| floor | the minimum capability a job requires; a job may go to any enabled model at or above its floor |
| Blossom | the mode for producing a large set of different items under one check (read `BLOSSOM.md`) |
| Ralph | `ralph.sh`, the repeat-until-done loop |

## 2. Rules for the agent

1. **Operate; do not reimplement.** `team.py`, `swarm.py`, `ralph.sh` already do the work. Drive them by command. Do not rewrite or edit any `.py` file. The only files you edit are `config.json`, the operator's own project files, and (only if section 4, step 3 says so) the `READER_CANDIDATES` list in `ground.py`.
2. **Ask, don't guess, for these inputs.** Do not invent them:
   - the machines available (address, OS, memory) and which models each can hold
   - what the operator wants produced and how to judge it
3. **One Ralph per project folder.** Before starting one: `ps -eo pid,etime,command | grep -E "ralph|team\.py" | grep -v grep`. Two share one output file and one model.
4. **Long jobs go in the background.** Start with `nohup ... > run.out 2>&1 &`, then poll `ralph.log`. A model's first load can take up to 4 minutes; that is not a hang. Tell the operator how to stop it (`kill` the PID, or `python3 killswarm.py`).
5. **Credentials.** Never print `.env` values, and never put them in a request or `config.json`.
6. **A check you did not test is not a check.** See section 5.
7. **Done means Ralph printed `ralph: done after N round(s)`** (exit 0). A `team.py` exit code of 0 only means one round ended.
8. **Do not run the whole original test suite or glob-run files here.** It is not included, and generated files may open windows or dial the network.

## 3. Inputs to collect from the operator

Collect these before editing anything. If any is missing, ask.

| # | Input | Used for |
|---|---|---|
| 1 | Machines: name, address, OS, memory | `nodes` in `config.json` |
| 2 | For each machine, which model tags it holds or can pull | `models` lists and `models` block |
| 3 | Is at least one model strong enough to plan and write hard code? Which? | that model gets `capability` 4 |
| 4 | Model family of each model (`gemma` or something else) | `family` and `team.restrict_to_family` |
| 5 | What to produce, how many items, and where to store them | the request sentence |
| 6 | What makes an item valid | the check |
| 7 | Is Node.js installed (for the example, or for a JavaScript check)? | `node --version` |

## 4. Procedure

Run each step in this folder. After each, compare with "Expect"; on a mismatch use "If not".

### Step 1. Preflight

```bash
python3 --version        # Expect 3.9 or newer
bash --version           # Expect any version. Windows: use WSL.
ollama --version         # Expect a version, on every machine that will run a model
```

If not: tell the operator to install the missing tool (Python 3.9+, bash, Ollama from ollama.com). Do not continue until all three exist.

### Step 2. Make the scripts executable

```bash
chmod +x ralph.sh team.py swarm.py openapi.py killswarm.py judge.py show_routing.py
```

Expect: no output.

### Step 3. Edit `config.json` from the inputs

Read `CONFIGURING_MODELS.md` (sections 1 to 6). The shipped values are reference values from the original author's hardware: replace them. Apply these decisions:

| Situation | Edit |
|---|---|
| Models not yet downloaded | on each machine: `ollama pull TAG` |
| One machine | keep node `mac` (keep this exact name even on Linux: three helper features look for it); disable or delete node `writer` |
| Several machines | add one `nodes` entry per machine: unique `name`, `url` as `http://ADDRESS:11434`, `models` list. Other machines need `OLLAMA_HOST=0.0.0.0:11434` and an open port (see `SETUP.md`). |
| Each model | an entry in the `models` block with `capability`, `quality`, `max_ctx`, `family` |
| At least one model, capability 4 | **required.** `team.py do` fails with `no floor-4 model free` and `could not decompose` without one. A single model that is strong enough takes capability 4 and receives every kind of job. |
| Model family is not Gemma | set `"family": "<label>"` on every model, then set `team.restrict_to_family` and `team.primary_family` to that label (or delete `team.restrict_to_family`). Otherwise every team role resolves to nobody. |
| `team.judge_model` | set to a model tag you have, or delete the key |
| `routing.classifier_model` | set to a model tag you have (optional: if absent the router falls back to keyword rules) |
| `ground.py` `READER_CANDIDATES` | optional feature. Edit the list to a (node name, model tag) you have, or leave it; unmatched means requests are simply not grounded |

### Step 4. Offline routing check

```bash
./show_routing.py
```

Expect: exit 0 and the last line `Nothing required to fix. Next: ./swarm.py nodes, then ./team.py warm`.

If not: it prints `Fix before running:` followed by exact causes. Apply each, rerun. An `Optional:` note does not block.

### Step 5. Machines answer

```bash
./swarm.py nodes
```

Expect: one `ok` line per enabled node, with each of its model tags listed beneath.

If not:

| Output | Cause and action |
|---|---|
| `DOWN ... cannot reach` | wrong `url`, Ollama not running, firewall, or `OLLAMA_HOST` not `0.0.0.0` on that machine. If every node is DOWN at once, check this machine's own network first. |
| a tag missing under a node | `ollama pull TAG` on that machine |

### Step 6. Preload

```bash
./team.py warm --floor 4      # loads the capability-4 model on every node that has one
./team.py warm                # loads the smallest model on every node
```

Expect: one `warm in N.Ns` line per node, then a note about `OLLAMA_KEEP_ALIVE`. A first load of 10 to 70 seconds is normal. On a dedicated machine set `OLLAMA_KEEP_ALIVE=-1` in the Ollama service so models stay loaded.

### Step 7. Smoke test (about a minute once the model is warm)

```bash
mkdir -p /tmp/swarm-smoke && cd /tmp/swarm-smoke && rm -f add.py
cat > check.py <<'EOF'
import sys
sys.path.insert(0, ".")
try:
    import add
    assert add.add(2, 3) == 5, "add(2, 3) returned %r, not 5" % (add.add(2, 3),)
except Exception as e:
    print("CHECK FAILED:", e)
    sys.exit(1)
EOF
THIS_DIR=/path/to/this/folder   # set to the absolute path of the unzipped folder
$THIS_DIR/team.py do --check "python3 check.py" "write add.py with a function add(a, b) that returns a + b"
python3 check.py && echo CHECK_PASS
```

Expect: output contains `1/1 component(s) passed every gate` and the last line is `CHECK_PASS`. This exact test passed on a single small model with capability 4.

If not: read the printed `failed (...)` reason. `no floor-4 model free` means step 3's capability-4 row was missed. Other causes: step 5.

### Step 8. First real run

Either the included example or the operator's own job (section 5).

```bash
cd example_platformer
node check_game.js        # Expect: CHECK FAILED: cannot load level.js. Correct for a fresh start.
nohup env -u RALPH_TEAM ../ralph.sh \
  --check "node check_game.js" \
  "Store the levels generateLevel(seed) returns, for every seed the check loops over, in level.js." \
  > run.out 2>&1 &
echo $!                   # report this PID to the operator
```

Poll with `tail -n 40 ralph.log`. Add `-n 20` before the request to cap at 20 rounds. This run needs a strong model and takes many rounds; the example was not run end-to-end for this package, so report progress honestly, do not promise a time.

## 5. The operator's own run (Blossom)

Use this when the work is "one function called on many inputs, and the set as a whole has properties (order, variety, coverage)".

1. Read `BLOSSOM.md` fully. It is the spec for the check and the request.
2. Create a project folder (not this folder). Write the check there. Rules of the check:
   - exits 0 only when acceptable; otherwise prints `CHECK FAILED: ...`, one line per problem, each naming the input, what was measured, and what to change
   - sizes are **floors** (fail when under a minimum, never when over)
   - rules the writer must know go in plain comments between `WRITER-CONTEXT-BEGIN` and `WRITER-CONTEXT-END`; name the check script as a token of `--check` (for example `--check "node check.js"`) so it is shown to the writer
   - model: `example_platformer/check_game.js`
3. **Test the check on degenerate input before the run.** Feed it the laziest value (empty, all identical, a copy of one value, all solid). If it passes, tighten it first. Record the result for the operator.
4. Write the request: one sentence naming the collection, the function the check calls, and the file that stores the values. Example: `Store the records generateRecord(i) returns, for every i the check loops over, in records.js.` Do not list the values and do not chain several jobs in one request.
5. Launch from the project folder:

```bash
nohup env -u RALPH_TEAM /path/to/this/folder/ralph.sh \
  --check "node check.js" \
  "Store the records generateRecord(i) returns, for every i the check loops over, in records.js." \
  > run.out 2>&1 &
```

6. Monitor `ralph.log` and `.ralph/last-check.txt`. Log lines and their meaning are tabulated in `BLOSSOM.md`, "What a round is doing". Finished set: the file named in the request. Saved progress: `.ralph/stored.json`. Running Ralph again resumes from it.

### Monitoring decisions

| Observation | Action |
|---|---|
| `ralph: done after N round(s)` | finished. Report the output file and run the check once yourself to confirm exit 0. |
| The same `CHECK FAILED` line across many rounds with no change in the numbers | the check line does not say what to change, or the rule is unsatisfiable. Stop, show the operator the line, propose a clearer message or a relaxed rule. Do not edit the check mid-run without telling the operator: edits apply on the next ask. |
| `reply was cut off at N tokens` | normal; the next ask allows more |
| Nothing in the log for over 4 minutes | check `ps` for your own process, then `curl -s http://NODE:11434/api/ps` for activity before concluding a hang |
| Operator wants to restart the set | stop Ralph, delete `.ralph/stored.json` and the output file in the project folder, relaunch |
| Operator wants to stop | `kill PID` or `python3 killswarm.py`. Progress is kept. |

## 6. Stop and ask the operator when

- an input in section 3 is missing or ambiguous
- step 3 requires a model the operator does not have and cannot pull
- `./show_routing.py` still reports `Fix before running` after you applied its causes
- a check line repeats for many rounds (section 5 monitoring)
- the next action would install software, change a firewall, or modify a machine other than this one

## 7. Files

Machine-readable index: `MANIFEST.json`.

| Path | Role |
|---|---|
| `START_HERE.md` | this procedure |
| `SWARM_MAP.html`, `SWARM_MAP.md` | human-facing presentation of the whole system (same content; send the HTML to people) |
| `CONFIGURING_MODELS.md` | models, capability, floors, every config field, warming, family gate, names in code |
| `config.json` | machines and models. The file you edit. |
| `show_routing.py` | offline routing check (step 4) |
| `ralph.sh` | the loop |
| `team.py`, `swarm.py` | orchestrator and router; entry points |
| `codegen.py`, `intent.py`, `checks.py`, `crossref.py`, `patterns.py`, `evidence.py`, `ground.py`, `session.py`, `attach.py`, `usage.py`, `openapi.py`, `mockapi.py` | imported by the two above; keep in one folder; do not edit |
| `judge.py` | optional yes/no model gate callable from a check |
| `killswarm.py` | stops stray runs (`--dry-run` lists them) |
| `context/` | standing rules handed to models; `_TEMPLATE.md` shows the card format |
| `example_platformer/` | worked example: check, drawing program, physics, game page |
| `BLOSSOM.md` | how to write the check and request for a set |
| `OPERATING.md` | every command |
| `SETUP.md` | exposing Ollama on a network |
| `AGENTS.md`, `LOCAL.md`, `ralph.md` | deeper reference. The machine names in them describe the original author's network. Read `config.json` for the real fleet. |

Stdlib Python only; nothing to install. The original repository's offline test suite is not included.
