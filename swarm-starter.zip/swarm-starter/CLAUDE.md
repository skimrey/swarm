@AGENTS.md

Claude Code reads this file rather than AGENTS.md, so the line above imports it
at session start. AGENTS.md stays the single source of truth; put anything
Claude-specific below this line.

## If you were handed this folder to set someone up

Read `START_HERE.md` first and follow its procedure (sections 2 to 6). The machine
names in `AGENTS.md`, `LOCAL.md` and `OPERATING.md` (mac, e4b-linux, g26b, p40, and
so on) describe the original author's network and are examples. The real machines
and models are in `config.json`; model guidance is in `CONFIGURING_MODELS.md`.
Run `./show_routing.py` after every config edit.
