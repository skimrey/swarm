#!/usr/bin/env python3
"""Show which machine and model each kind of job would go to, from config.json.

    ./show_routing.py                      # read config.json next to this file
    SWARM_CONFIG=other.json ./show_routing.py

Offline: it never contacts a machine. It reads the config, asks the same
selection functions the real run uses, and prints the answer. Run it after
every edit to config.json, before `./team.py warm`.

It also names the three configuration mistakes that stop a run before it
starts: no model rated high enough for planning, a model blocked by the
family gate, and a helper (reader, judge) pointed at a node that does not
exist.
"""
import os
import sys

HERE = os.path.dirname(os.path.realpath(__file__))
sys.path.insert(0, HERE)

import swarm  # noqa: E402
import team  # noqa: E402


def label(found):
    return "%s / %s" % (found[0].name, found[1]) if found else "NOBODY"


def main() -> int:
    cfg = swarm.Config.load()
    os.makedirs(os.path.dirname(swarm.STATE_PATH), exist_ok=True)
    state = swarm.State(swarm.STATE_PATH)
    problems = []
    notes = []

    print("config:", cfg.path)
    print()
    print("Machines and models (capability 1-4 is how hard a job the model may be given)")
    for node in cfg.nodes:
        flag = "enabled " if node.enabled else "DISABLED"
        print("  %s %-12s %s" % (flag, node.name, node.url))
        for m in node.models:
            meta = cfg.model_meta(m)
            known = "" if m in cfg.models else "   <- not in the models block: capability guessed from its name"
            print("             %-34s capability %s  quality %s  family %s%s" % (
                m, meta.get("capability"), meta.get("quality"),
                meta.get("family", "(none set)"), known))
    print()

    restrict = cfg.data.get("team", {}).get("restrict_to_family")
    if restrict:
        print("Family gate: only models with \"family\": %r may do team work." % restrict)
        blocked = [(n.name, m) for n in cfg.enabled_nodes() for m in n.models
                   if not team.allowed_family(cfg, m, restrict)]
        for n, m in blocked:
            print("  BLOCKED by the gate: %s / %s (its family is %r)" % (
                n, m, cfg.model_meta(m).get("family", "unknown")))
        if blocked:
            problems.append(
                "Some models are blocked by team.restrict_to_family. Give each its "
                "\"family\" in the models block and set team.restrict_to_family to "
                "match, or delete team.restrict_to_family.")
        print()

    print("Where a job goes, by difficulty (the one-prompt router, ./swarm.py)")
    for tier in range(4):
        floor = swarm.tier_floor(cfg, tier)
        cand, _ = swarm.choose(cfg, state, floor, 500, 200, tier=tier)
        who = (cand.node.name + " / " + cand.model) if cand else "NOBODY"
        print("  %-8s needs capability >= %d  ->  %s" % (swarm.TIER_NAMES[tier], floor, who))
    print()

    print("Where team work goes (./team.py do, ralph.sh)")
    family = restrict or None
    roles = []
    for floor, what in ((4, "planner and item writer (floor 4)"), (2, "simple files and reading (floor 2)")):
        found = team.pick_role_model(cfg, state, floor, family=family)
        roles.append((floor, found))
        print("  %-38s ->  %s" % (what, label(found)))
    judge = team.judging_model(cfg, state, int(cfg.data.get("team", {}).get("judge_floor", 4)))
    print("  %-38s ->  %s" % ("judge / second opinion", label(judge)))
    if roles[0][1] is None:
        problems.append(
            "Nothing can serve floor 4, and `team.py do` needs a floor-4 model to plan. "
            "Enable a node whose model has capability 4, or set capability 4 on your "
            "strongest model in the models block.")
    print()

    print("Helpers that name a machine in the code")
    try:
        import ground
        reader = ground.pick_reader(cfg)
        print("  file reader (ground.py)        ->  %s" % (
            "%s / %s" % (reader[0].name, reader[1]) if reader[0] else "none; vague requests will not be grounded"))
        if reader[0] and reader[1] not in reader[0].models:
            notes.append(
                "ground.py wants %r on node %r, which that node does not list. Optional "
                "feature: until you edit READER_CANDIDATES in ground.py to name a node "
                "and model you have, vague requests simply are not grounded." % (
                    reader[1], reader[0].name))
        if reader[0] is None:
            notes.append(
                "ground.py found no reader. Edit READER_CANDIDATES in ground.py to name "
                "a node and model you have. Optional: without it, requests are not grounded.")
    except Exception as exc:  # noqa: BLE001
        print("  file reader (ground.py)        ->  could not check (%s)" % exc)
    jn = os.environ.get("JUDGE_NODE") or "mac"
    jnode = cfg.node(jn)
    print("  judge inside a check (judge.py) ->  %s" % (
        "%s / %s" % (jnode.name, os.environ.get("JUDGE_MODEL") or jnode.models[0])
        if jnode and jnode.models else "node %r not found; the rule is skipped" % jn))
    print()

    if notes:
        print("Optional:")
        for n in notes:
            print("  - " + n)
        print()
    if problems:
        print("Fix before running:")
        for p in problems:
            print("  - " + p)
        return 1
    print("Nothing required to fix. Next: ./swarm.py nodes, then ./team.py warm")
    return 0


if __name__ == "__main__":
    sys.exit(main())
