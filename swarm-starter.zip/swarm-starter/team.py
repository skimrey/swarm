#!/usr/bin/env python3
"""Team: parallel DAG orchestration across the swarm.

Where swarm.py answers "which single model should handle this prompt", team.py
answers "how do I get this whole body of work done in the least wall-clock
time, using every node at once".

The scheduling problem is: a task DAG, heterogeneous workers with different
measured speeds, and a reload penalty when a node has to swap which model it
holds. That is the classic heterogeneous DAG scheduling setup, and this uses a
HEFT-style list scheduler (Heterogeneous Earliest-Finish-Time): rank tasks by
their longest path to completion so the critical path starts first, then place
each task wherever it will actually finish soonest.

The practical consequence is the thing you want: the slow specialist starts on
the hard core immediately, and every peripheral chunk it doesn't need gets
packed onto other nodes inside that same window, so nothing is still being
computed when it's time to recombine.

    ./team.py split "summarise this file" src/*.py --reduce
    ./team.py run plan.json --dry-run
    ./team.py run plan.json
    ./team.py review "is this migration plan sound?  ..."

Standard library only, Python 3.9+. Requires swarm.py alongside it.
"""

from __future__ import annotations

import argparse
import ast
import contextlib
import datetime
import json
import os
import queue
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from typing import Any, Callable, Dict, List, Optional, Sequence, Set, Tuple

import attach
import checks
import codegen
import crossref
import evidence
import ground
import intent
import patterns
import session
import swarm

BUNDLE_DIR = os.path.join(swarm.HERE, ".swarm", "bundles")


# --------------------------------------------------------------------------
# plan model
# --------------------------------------------------------------------------


class Task:
    """One unit of work in the plan.

    `floor` is the minimum model capability allowed, same scale swarm.py uses.
    `deps` are task ids that must finish first; their outputs are substituted
    into this task's prompt wherever `{{dep_id}}` appears.
    """

    def __init__(self, raw: Dict[str, Any]):
        self.id: str = str(raw["id"])
        self.prompt: str = str(raw.get("prompt", ""))
        self.deps: List[str] = [str(d) for d in raw.get("deps", [])]
        self.floor: int = int(raw.get("floor", 1))
        self.est_output: int = int(raw.get("est_output", 400))
        self.role: str = raw.get("role", "worker")
        self.pin: Optional[str] = raw.get("pin")  # force node/model
        self.family: Optional[str] = raw.get("family")  # require this lineage
        self.exclude_family: Optional[str] = raw.get("exclude_family")
        self.system: Optional[str] = raw.get("system")
        self.max_tokens: int = int(raw.get("max_tokens", -1))
        self.label: str = raw.get("label", self.id)
        # Reasoning helps generation and does nothing measurable for short
        # structured verdicts, where it cost 10x wall-clock for no accuracy
        # -- and defaulted to on anyway, which this comment already argued
        # against, because nothing here ever set the key. `cmd_split`'s own
        # task construction (and the reduce step's) never write "think" into
        # a task dict, so every split/run task that has ever run through
        # this path reasoned by default, on exactly the short, structured,
        # per-file summaries this project's own measurements say gain
        # nothing from it and lose 10x wall-clock. `codegen.generate_file`,
        # `ground.py`, `openapi.py`'s planner calls and every writer `do`/
        # `code` uses already default the opposite way -- off unless a
        # caller opts in -- and this was the one path that never caught up.
        # A task that genuinely wants reasoning still can, explicitly, with
        # `"think": true` in the plan.
        self.think: bool = bool(raw.get("think", False))

        self.output: Optional[str] = None
        self.error: Optional[str] = None
        self.done = threading.Event()
        self.actual_seconds: Optional[float] = None
        self.actual_target: Optional[str] = None

    def resolved_prompt(self, tasks: Dict[str, "Task"]) -> str:
        text = self.prompt
        for dep in self.deps:
            token = "{{%s}}" % dep
            if token in text:
                text = text.replace(token, tasks[dep].output or "")
        return text


class Plan:
    def __init__(self, raw: Dict[str, Any]):
        self.goal: str = raw.get("goal", "")
        self.tasks: Dict[str, Task] = {}
        order: List[str] = []
        for entry in raw.get("tasks", []):
            t = Task(entry)
            self.tasks[t.id] = t
            order.append(t.id)
        self.order = order
        self.reduce_spec: Optional[Dict[str, Any]] = raw.get("reduce")
        if self.reduce_spec:
            self._append_reduce()
        self._validate()

    def _append_reduce(self) -> None:
        spec = self.reduce_spec or {}
        self.reduce_to: str = spec.get("to", "model")
        leaves = [tid for tid in self.order
                  if not any(tid in self.tasks[o].deps for o in self.order)]
        if self.reduce_to == "assistant":
            # Nothing to schedule: the findings get bundled and handed back.
            self.reduce_leaves = leaves
            return
        rid = spec.get("id", "reduce")
        template = spec.get("prompt") or (
            "You are combining independent findings into one answer.\n\n"
            "GOAL: %s\n\nFINDINGS:\n%s\n\n"
            "Produce the final answer. Reconcile any contradictions explicitly."
        )
        # Head each finding with its human label, not its task id, or the
        # synthesis ends up citing "t3" at the reader.
        findings = "\n\n".join("--- %s ---\n{{%s}}" % (self.tasks[l].label, l)
                               for l in leaves)
        prompt = template if "{{" in template else template % (self.goal, findings)
        self.tasks[rid] = Task({
            "id": rid,
            "prompt": prompt,
            "deps": leaves,
            "floor": int(spec.get("floor", 4)),
            "est_output": int(spec.get("est_output", 900)),
            "role": "reduce",
            "label": "reduce",
        })
        self.order.append(rid)

    def _validate(self) -> None:
        for t in self.tasks.values():
            for d in t.deps:
                if d not in self.tasks:
                    raise SystemExit("task %r depends on unknown task %r" % (t.id, d))
        # cycle check via simple DFS
        state: Dict[str, int] = {}

        def visit(tid: str) -> None:
            if state.get(tid) == 2:
                return
            if state.get(tid) == 1:
                raise SystemExit("plan has a dependency cycle at %r" % tid)
            state[tid] = 1
            for d in self.tasks[tid].deps:
                visit(d)
            state[tid] = 2

        for tid in self.tasks:
            visit(tid)

    def successors(self, tid: str) -> List[str]:
        return [o for o in self.order if tid in self.tasks[o].deps]


# --------------------------------------------------------------------------
# cost model
# --------------------------------------------------------------------------


ASSUME_WARM = False


def rates(cfg: swarm.Config, state: swarm.State, node: swarm.Node, model: str
          ) -> Tuple[float, float, float]:
    """(prefill tok/s, decode tok/s, cold load seconds) from measurements."""
    perf = state.throughput(node.name, model)
    meta = cfg.model_meta(model)
    if perf and perf.get("decode_tps"):
        decode = perf["decode_tps"]
        prefill = perf.get("prefill_tps") or 0.0
    else:
        decode = float(meta.get("decode_tps_hint", 20.0))
        prefill = 0.0
    # Prefill processes the prompt in parallel batches while decode is strictly
    # one token at a time, so prefill below decode speed is not a slow machine,
    # it is a bad measurement. Fall back rather than believe it.
    if prefill < decode * 2.0:
        prefill = decode * 15.0
    if ASSUME_WARM:
        cold = 0.0
    else:
        cold = state.cold_load_s(node.name, model) or float(
            cfg.routing.get("cold_start_penalty_s", 6.0))
    return max(prefill, 1.0), max(decode, 0.5), cold


def allowed_family(cfg: swarm.Config, model: str, family: Optional[str]) -> bool:
    """Gate every role selection on the approved lineage.

    Enforced here rather than left to config contents so that adding a model
    to a node cannot quietly put it into rotation.
    """
    if not family:
        return True
    return cfg.model_meta(model).get("family", "unknown") == family


def prompt_tokens_for(plan: Plan, task: Task) -> int:
    """Estimated prompt size, counting text that dependencies will supply.

    A reduce task is nearly all `{{placeholder}}` at scheduling time, so
    measuring its literal prompt would hide the fact that it has to prefill
    every chunk its children produced.
    """
    total = swarm.est_tokens(task.prompt)
    for dep in task.deps:
        if "{{%s}}" % dep in task.prompt:
            total += plan.tasks[dep].est_output
    return total


def task_candidates(plan: Plan, task: Task, cfg: swarm.Config
                    ) -> List[Tuple[swarm.Node, str]]:
    out: List[Tuple[swarm.Node, str]] = []
    restrict = cfg.data.get("team", {}).get("restrict_to_family")
    for node in cfg.enabled_nodes():
        for model in node.models:
            meta = cfg.model_meta(model)
            if int(meta.get("capability", 1)) < task.floor:
                continue
            if not allowed_family(cfg, model, restrict):
                continue
            fam = meta.get("family", "unknown")
            if task.family and fam != task.family:
                continue
            if task.exclude_family and fam == task.exclude_family:
                continue
            if task.pin:
                if task.pin not in (node.name, model, "%s/%s" % (node.name, model)):
                    continue
            out.append((node, model))
    return out


def compute_cost(cfg: swarm.Config, state: swarm.State, task: Task,
                 node: swarm.Node, model: str, prompt_tokens: int) -> float:
    """Seconds of compute, inflated by preference and by uncertainty.

    Two adjustments keep pure-makespan scheduling from making choices you
    would not endorse:

    Bias is applied as a cost multiplier, so the pins already tuned in
    config.json carry over. A model pinned to 0.05 looks twenty times more
    expensive and quietly stops winning routine work, without being banned --
    it can still be drafted deliberately by family or by pin, because a role
    assignment is not a preference auction.

    Models with no measured samples are inflated too. An optimistic hint in
    config should never beat a model that has actually demonstrated its speed.
    """
    prefill, decode, _cold = rates(cfg, state, node, model)
    # Reasoning tokens decode at the same rate as the answer and are billed
    # from the same budget, so they belong in the duration estimate. Measured
    # additively rather than as a multiple: reasoning length tracks how hard
    # the question is, not how long the answer is, so a short answer with a
    # hard question thinks just as much as a long one.
    generated = task.est_output + (thinking_tokens(cfg, model) if task.think else 0)
    return prompt_tokens / prefill + generated / decode


CONTEXT_BUDGET = 2400


def project_context(query: str, budget_tokens: int = CONTEXT_BUDGET) -> str:
    """Hard-context cards relevant to this request, or "" when none are.

    The pool writes code for a project it cannot see. Conventions, topology and
    house rules live in `context/` as tagged cards, and without this the specs
    sent out carry none of it -- every file is written by a model reasoning
    from the request alone.

    Deliberately silent when nothing scores well. `pack_context` gates on
    relevance for a reason: a couple of incidental word matches will drag a
    whole card into a prompt with no use for it, and here that is worse than
    wasteful.

    The budget bounds how many *relevant* cards arrive in full, which is a
    different question from whether irrelevant ones are excluded -- that is
    the relevance gate's job, and it is unaffected by this number. At 600 a
    card over roughly 600 tokens could never arrive as anything but its
    one-line summary no matter how well it scored, so the rules inside it
    never reached a writer: measured, `policy-api-writes` scored 11.5 on
    the request it was written for and arrived as 69 tokens of abstract.
    Silently degrading the best match is the worst available failure, since
    it looks exactly like the card being attached.

    Raising it is cheap for the reason raising `max_ctx` was. `num_ctx` is
    sized per call from the real prompt and only clamped at the ceiling, so
    a few hundred extra tokens change nothing that was not already being
    clamped. The reload risk is about the window *varying between
    components*, and cards are selected from the request rather than the
    component, so every writer in a run gets the same ones.
    """
    try:
        packed = swarm.pack_context(query, budget_tokens)
    except Exception:  # noqa: BLE001 -- context is a nicety, never a blocker
        return ""
    text = (packed.get("text") or "").strip()
    if not text:
        return ""
    return ("\nProject context (conventions and environment, already true -- "
            "do not restate it in the file):\n\n%s\n" % text)


def measured_rate(state: swarm.State, node: str, model: str) -> float:
    """Median observed decode rate for one model on one box, tokens per second.

    Median rather than mean because a single cold run with the load time folded
    in drags an average down far enough to reorder the fleet. Zero when nothing
    has been measured, which callers read as "no opinion" rather than "slow".
    """
    samples = sorted(
        r["decode_tps"] for r in state.db.execute(
            "SELECT decode_tps FROM perf WHERE node=? AND model=? "
            "AND decode_tps > 0 ORDER BY ts DESC LIMIT 9", (node, model)))
    return samples[len(samples) // 2] if samples else 0.0


def thinking_tokens(cfg: swarm.Config, model: Optional[str] = None) -> int:
    """How many reasoning tokens this model will spend before answering.

    Not a constant across the fleet. Measured on one fan-out-plus-reduce run:
    the small models spent about 600 reasoning tokens each, while the 26b spent
    roughly 2270 on the reduce -- it emitted 2387 tokens to produce a 117-token
    answer. Reasoning length tracks how hard the model finds the question, and
    the capable model is the one being handed the hard questions, so a single
    figure either flatters the big model or slanders the small ones.

    Per-model when config says so, otherwise the fleet default.
    """
    team_cfg = cfg.data.get("team", {})
    if model:
        meta = cfg.model_meta(model)
        hint = meta.get("thinking_tokens")
        if hint:
            return int(hint)
    return int(team_cfg.get("thinking_tokens", 700))


def preference_multiplier(cfg: swarm.Config, state: swarm.State, task: Task,
                          node: swarm.Node, model: str) -> float:
    """How much to inflate a candidate's cost when ranking it.

    Kept separate from compute_cost so the predicted timeline stays honest:
    preference decides who gets the work, measured speed decides when it lands.
    """
    mult = 1.0
    team = cfg.data.get("team", {})
    meta = cfg.model_meta(model)
    if not (task.pin or task.family):
        # Only per-model bias, deliberately not node bias. Node bias was tuned
        # as a routing preference that partly stands in for "this box is slow",
        # and this scheduler already measures decode speed directly -- applying
        # both charges the slow nodes twice and collapses the fan-out back onto
        # one machine. Per-model bias survives because it encodes something
        # throughput cannot see: that this tag wrecks this particular host.
        mult /= max(float(node.model_bias.get(model, 1.0)), 0.01)
        fam = meta.get("family", "unknown")
        primary = team.get("primary_family")
        if primary and fam != primary:
            mult /= max(float(team.get("offfamily_bias", 0.5)), 0.01)
        # Opportunity cost: a greedy scheduler will happily burn the one model
        # that can handle the hard step on a chunk any node could have done,
        # and then pay a full reload to get it back for the reduce. Charging
        # for overkill keeps the specialist free without hard-reserving it.
        over = int(meta.get("capability", 1)) - task.floor
        if over > 0:
            mult *= float(team.get("overkill_penalty", 1.4)) ** over
    if not state.throughput(node.name, model):
        mult *= float(team.get("unmeasured_penalty", 1.5))
    return mult


# --------------------------------------------------------------------------
# HEFT scheduler
# --------------------------------------------------------------------------


class Assignment:
    def __init__(self, task: Task, node: swarm.Node, model: str,
                 start: float, finish: float, swap: float):
        self.task = task
        self.node = node
        self.model = model
        self.start = start
        self.finish = finish
        self.swap = swap

    @property
    def target(self) -> str:
        return "%s/%s" % (self.node.name, self.model)


def upward_ranks(plan: Plan, cfg: swarm.Config, state: swarm.State) -> Dict[str, float]:
    """Longest path from each task to a terminal task, in average seconds.

    Scheduling in decreasing rank order is what makes the critical path start
    first instead of getting stuck behind cheap work.
    """
    memo: Dict[str, float] = {}

    def avg_cost(task: Task) -> float:
        """Representative duration: the true cost of the candidate we would
        most likely choose. Textbook HEFT averages over all workers, but with
        a pool this lopsided -- and with models deliberately pinned out of
        rotation -- the average describes a machine that will never run it."""
        cands = task_candidates(plan, task, cfg)
        if not cands:
            return float(task.est_output) / 10.0
        ptoks = prompt_tokens_for(plan, task)
        scored = [(compute_cost(cfg, state, task, n, m, ptoks)
                   * preference_multiplier(cfg, state, task, n, m),
                   compute_cost(cfg, state, task, n, m, ptoks))
                  for n, m in cands]
        return min(scored)[1]

    def rank(tid: str) -> float:
        if tid in memo:
            return memo[tid]
        task = plan.tasks[tid]
        succ = plan.successors(tid)
        best_succ = max((rank(s) for s in succ), default=0.0)
        memo[tid] = avg_cost(task) + best_succ
        return memo[tid]

    for tid in plan.order:
        rank(tid)
    return memo


def schedule(plan: Plan, cfg: swarm.Config, state: swarm.State,
             warm_pass: bool = True) -> Tuple[List[Assignment], float]:
    ranks = upward_ranks(plan, cfg, state)
    ordered = sorted(plan.order, key=lambda t: -ranks[t])

    # Per-node slot availability, plus which model each node is projected to
    # be holding. Single-slot nodes must drain before swapping models, which
    # is exactly the cost that made 12b a bad roommate for the 26b.
    slots: Dict[str, List[float]] = {}
    resident: Dict[str, Optional[str]] = {}
    touched: Dict[str, bool] = {}
    for node in cfg.enabled_nodes():
        n_slots = max(1, node.max_parallel)
        slots[node.name] = [0.0] * n_slots
        cur = state.resident_model(node.name)
        resident[node.name] = cur[0] if cur else None
        touched[node.name] = False

    finish_at: Dict[str, float] = {}
    assignments: List[Assignment] = []

    for tid in ordered:
        task = plan.tasks[tid]
        cands = task_candidates(plan, task, cfg)
        if not cands:
            raise SystemExit(
                "no node satisfies task %r (floor=%d family=%s)"
                % (task.id, task.floor, task.family))

        dep_ready = max((finish_at.get(d, 0.0) for d in task.deps), default=0.0)
        ptoks = prompt_tokens_for(plan, task)

        best: Optional[Tuple[float, float, float, float, swarm.Node, str, int]] = None
        for node, model in cands:
            _pf, _dc, cold = rates(cfg, state, node, model)
            node_slots = slots[node.name]
            first_use = not touched[node.name]
            needs_swap = node.single_slot and resident[node.name] not in (None, model)
            cold_needed = needs_swap or resident[node.name] != model

            if needs_swap:
                # a single-slot node must drain before it can swap what it holds
                slot_free = max(node_slots)
                slot_idx = node_slots.index(min(node_slots))
            else:
                slot_free = min(node_slots)
                slot_idx = node_slots.index(slot_free)

            if cold_needed and first_use and warm_pass:
                # This load is kicked off on every node at t=0 in parallel, so
                # it overlaps other nodes' work instead of extending the run.
                swap_cost = 0.0
                start = max(dep_ready, slot_free, cold)
            else:
                swap_cost = cold if cold_needed else 0.0
                start = max(dep_ready, slot_free)

            dur = swap_cost + compute_cost(cfg, state, task, node, model, ptoks)
            eft = start + dur
            rank_key = start + swap_cost + dur * preference_multiplier(
                cfg, state, task, node, model)
            if best is None or rank_key < best[0]:
                best = (rank_key, eft, start, swap_cost, node, model, slot_idx)

        _rk, eft, start, swap_cost, node, model, slot_idx = best  # type: ignore
        touched[node.name] = True
        if node.single_slot and resident[node.name] not in (None, model):
            # draining the node: every slot is busy until the swap completes
            slots[node.name] = [eft] * len(slots[node.name])
        else:
            slots[node.name][slot_idx] = eft
        resident[node.name] = model
        finish_at[tid] = eft
        assignments.append(Assignment(task, node, model, start, eft, swap_cost))

    makespan = max(finish_at.values()) if finish_at else 0.0
    assignments.sort(key=lambda a: a.start)
    return assignments, makespan


def serial_estimate(plan: Plan, cfg: swarm.Config, state: swarm.State) -> float:
    """What this would cost one-at-a-time, for a speedup comparison."""
    total = 0.0
    for tid in plan.order:
        task = plan.tasks[tid]
        cands = task_candidates(plan, task, cfg)
        if not cands:
            continue
        ptoks = prompt_tokens_for(plan, task)
        total += min(compute_cost(cfg, state, task, n, m, ptoks) for n, m in cands)
    return total


def render_gantt(assignments: List[Assignment], makespan: float, width: int = 46) -> str:
    if not assignments:
        return "(nothing scheduled)"
    scale = width / makespan if makespan > 0 else 0
    lines = []
    for a in assignments:
        pad = int(a.start * scale)
        span = max(1, int((a.finish - a.start) * scale))
        bar = " " * pad + "#" * span
        swap = "  +%.0fs load" % a.swap if a.swap > 0.5 else ""
        lines.append("  %-14s %-24s |%-*s| %5.1f-%5.1fs%s"
                     % (a.task.label[:14], a.target[:24], width, bar[:width],
                        a.start, a.finish, swap))
    return "\n".join(lines)


# --------------------------------------------------------------------------
# execution
# --------------------------------------------------------------------------


def plan_contexts(assignments: List[Assignment], plan: Plan, cfg: swarm.Config
                  ) -> Dict[Tuple[str, str], int]:
    """One context size per node+model for the whole run.

    Ollama reloads the weights whenever num_ctx changes -- measured directly:
    warming at 1024 then requesting at 8192 paid the full 35s load again, and
    dropping back to 1024 paid it a third time. Sizing each task's window to
    its own prompt therefore bought a small VRAM saving at the price of a
    reload between tasks, which is how a warmed run still paid a cold start on
    every node.

    So each node+model gets a single window, big enough for its largest
    assigned task, and warming uses that same number. One load per run.
    """
    need: Dict[Tuple[str, str], int] = {}
    for a in assignments:
        task = a.task
        ptoks = prompt_tokens_for(plan, task)
        ptoks += swarm.est_tokens(task.system or "")
        if cfg.context.get("standing_policy", True):
            ptoks += swarm.est_tokens(swarm.standing_policy())
        reserve = max(task.est_output,
                      task.max_tokens if task.max_tokens > 0 else 0) \
            + (thinking_tokens(cfg, a.model) * 2 if task.think else 0)
        ctx = swarm.pick_num_ctx(cfg, a.node, a.model, ptoks, reserve,
                                 reasoning=False)
        key = (a.node.name, a.model)
        need[key] = max(need.get(key, 0), ctx)
    return need


def warm_targets(assignments: List[Assignment], cfg: swarm.Config,
                 state: swarm.State,
                 contexts: Optional[Dict[Tuple[str, str], int]] = None) -> None:
    """Fire a 1-token request at each node's first model, all at once.

    Without this, each node pays its load penalty serially when its turn
    arrives. Loading four nodes concurrently turns four sequential stalls into
    one. The window must match what the tasks will ask for, or the load is
    simply paid twice.
    """
    first: Dict[str, Tuple[swarm.Node, str]] = {}
    for a in assignments:
        if a.node.name not in first:
            first[a.node.name] = (a.node, a.model)

    def warm(node: swarm.Node, model: str) -> None:
        ctx = (contexts or {}).get((node.name, model), 4096)
        try:
            swarm.chat(node, model, [{"role": "user", "content": "hi"}],
                       num_ctx=ctx, num_predict=1, temperature=0.0, timeout=600)
            state.mark_resident(node.name, model)
        except swarm.OllamaError:
            pass

    threads = [threading.Thread(target=warm, args=(n, m), daemon=True)
               for n, m in first.values()]
    for t in threads:
        t.start()
    for t in threads:
        t.join()


def run_task(a: Assignment, plan: Plan, cfg: swarm.Config, state: swarm.State,
             verbose: bool,
             contexts: Optional[Dict[Tuple[str, str], int]] = None) -> None:
    task = a.task
    for dep in task.deps:
        plan.tasks[dep].done.wait()
        if plan.tasks[dep].error:
            task.error = "skipped: dependency %s failed" % dep
            task.done.set()
            return

    prompt = task.resolved_prompt(plan.tasks)
    policy = swarm.standing_policy() if cfg.context.get("standing_policy", True) else ""
    messages = swarm.build_messages(prompt, task.system, "", False, policy)
    ptoks = sum(swarm.est_tokens(m["content"]) for m in messages)
    # Size the window for reasoning as well as the answer, or a long think
    # runs off the end of the context instead of off the token budget.
    reserve = max(task.est_output, task.max_tokens if task.max_tokens > 0 else 0) \
        + (thinking_tokens(cfg, a.model) * 2 if task.think else 0)
    fallback_ctx = swarm.pick_num_ctx(cfg, a.node, a.model, ptoks, reserve,
                                      reasoning=False)

    started = time.monotonic()
    # Try the scheduled placement, then any other capable node. A box that
    # runs out of VRAM mid-generation takes down every task that depended on
    # it, so one bad node should cost a retry, not the whole run.
    attempts: List[Tuple[swarm.Node, str]] = [(a.node, a.model)]
    for alt_node, alt_model in task_candidates(plan, task, cfg):
        if alt_node.name != a.node.name:
            attempts.append((alt_node, alt_model))
    attempts = attempts[:1 + max(0, int(cfg.data.get("team", {}).get("failover_tries", 2)))]

    for index, (node, model) in enumerate(attempts):
        # Reuse the window this node was warmed at, so the run does not pay a
        # reload just because this task's prompt is a different size.
        num_ctx = max((contexts or {}).get((node.name, model), 0), fallback_ctx)
        lease = state.acquire_lease(node.name, model, a.finish - a.start)
        try:
            with swarm.node_claim(state, node, model):
                result = swarm.chat_complete(
                    node, model, messages, num_ctx=num_ctx,
                    answer_tokens=task.max_tokens,
                    think=None if task.think else False, timeout=1800)
            task.output = result["text"]
            task.error = None
            task.actual_target = "%s/%s" % (node.name, model)
            state.record_perf(node.name, model, result["sample"])
            state.mark_resident(node.name, model)
            break
        except swarm.OllamaError as exc:
            task.error = str(exc)
            task.actual_target = "%s/%s" % (node.name, model)
            if verbose and index + 1 < len(attempts):
                sys.stderr.write("  [%-12s] %s failed, retrying elsewhere\n"
                                 % (task.label[:12], task.actual_target))
        finally:
            state.release_lease(lease)

    task.actual_seconds = time.monotonic() - started
    task.done.set()

    if verbose:
        status = "FAILED %s" % task.error if task.error else "%d chars" % len(task.output or "")
        sys.stderr.write("  [%-12s] %-22s %6.1fs  %s\n"
                         % (task.label[:12], a.target, task.actual_seconds, status))
        sys.stderr.flush()


def execute(plan: Plan, assignments: List[Assignment], cfg: swarm.Config,
            state: swarm.State, verbose: bool = True,
            contexts: Optional[Dict[Tuple[str, str], int]] = None) -> float:
    """Run the schedule. Each node slot gets a worker thread that walks its
    assigned tasks in scheduled order, blocking on dependencies."""
    by_node: Dict[str, List[Assignment]] = {}
    for a in assignments:
        by_node.setdefault(a.node.name, []).append(a)

    started = time.monotonic()
    threads: List[threading.Thread] = []
    for node_name, items in by_node.items():
        items.sort(key=lambda a: a.start)

        def worker(items=items) -> None:
            for a in items:
                run_task(a, plan, cfg, state, verbose, contexts)

        t = threading.Thread(target=worker, daemon=True)
        threads.append(t)
        t.start()
    for t in threads:
        t.join()
    return time.monotonic() - started


def report_accuracy(assignments: List[Assignment], plan: Plan) -> None:
    """Per-task predicted vs actual, so drift is visible instead of inferred.

    Worth printing every run because the two ways this model goes wrong look
    identical from the makespan alone. If the per-task compute predictions are
    close and the total is still long, the gap is model loading -- which is
    large enough to dominate on this hardware, around 35s against 3s of actual
    compute -- and the fix is warming, not a different estimate.
    """
    rows = []
    for a in assignments:
        actual = plan.tasks[a.task.id].actual_seconds
        if actual is None or plan.tasks[a.task.id].error:
            continue
        rows.append((a.task.label or a.task.id, a.finish - a.start, actual))
    if not rows:
        return
    print("\n  per-task predicted vs actual:")
    ratios = []
    for label, pred, actual in rows:
        ratio = (actual / pred) if pred > 0.05 else 0.0
        ratios.append(ratio)
        print("    %-26s pred %6.1fs  actual %6.1fs  %s"
              % (label[:26], pred, actual,
                 ("%.1fx" % ratio) if ratio else "-"))
    good = [r for r in ratios if r]
    if good:
        good.sort()
        median = good[len(good) // 2]
        verdict = ("compute estimates are sound" if 0.6 <= median <= 1.6
                   else "compute estimates need recalibration")
        print("    median ratio %.2fx -- %s" % (median, verdict))


def write_bundle(plan: Plan, elapsed: float, makespan: float) -> str:
    os.makedirs(BUNDLE_DIR, exist_ok=True)
    path = os.path.join(BUNDLE_DIR, time.strftime("%Y%m%d-%H%M%S") + ".json")
    with open(path, "w", encoding="utf-8") as fh:
        json.dump({
            "goal": plan.goal,
            "predicted_makespan_s": round(makespan, 1),
            "actual_seconds": round(elapsed, 1),
            "tasks": [{
                "id": t.id, "label": t.label, "target": t.actual_target,
                "seconds": round(t.actual_seconds or 0, 1),
                "error": t.error, "output": t.output,
            } for t in (plan.tasks[i] for i in plan.order)],
        }, fh, indent=2)
    return path


# --------------------------------------------------------------------------
# draft / critique
# --------------------------------------------------------------------------

CRITIC_PROMPT = """You are reviewing another model's answer. Be skeptical and specific.

Reply in exactly this format:

VERDICT: AGREE or MINOR or MAJOR
ISSUES:
- one line per concrete problem, or "none"

Use AGREE if the answer is correct and complete. Use MINOR for style, omissions
that do not change the conclusion, or small inaccuracies. Use MAJOR only if the
answer is wrong, misleading, or would cause a bad decision.

TASK GIVEN TO THE OTHER MODEL:
{task}

ITS ANSWER:
{answer}"""


def parse_verdict(text: str) -> Tuple[str, List[str]]:
    verdict = "UNKNOWN"
    issues: List[str] = []
    for line in text.splitlines():
        s = line.strip()
        up = s.upper()
        if up.startswith("VERDICT"):
            for level in ("MAJOR", "MINOR", "AGREE"):
                if level in up:
                    verdict = level
                    break
        elif s.startswith("-") and s.strip("- ").lower() not in ("none", ""):
            issues.append(s.lstrip("- ").strip())
    return verdict, issues


AGREEMENT_PROMPT = """Two models answered the same question independently. Decide \
whether they actually agree on substance. Wording differences do not matter.

Reply in exactly this format:

VERDICT: AGREE or DIFFER
DIFFERENCE:
- one line describing each substantive disagreement, or "none"

QUESTION:
{task}

ANSWER A:
{a}

ANSWER B:
{b}"""


def parse_agreement(text: str) -> Tuple[str, List[str]]:
    verdict = "UNKNOWN"
    diffs: List[str] = []
    for line in text.splitlines():
        s = line.strip().lstrip("*# ").strip()
        up = s.upper()
        if up.startswith("VERDICT"):
            if "DIFFER" in up:
                verdict = "DIFFER"
            elif "AGREE" in up:
                verdict = "AGREE"
        elif s.startswith("-") and s.strip("- ").lower() not in ("none", ""):
            diffs.append(s.lstrip("- ").strip())
    return verdict, diffs


_CLAIM_BUSY_ESTIMATE_S = 60.0


def _node_load(state: swarm.State, node: swarm.Node) -> Tuple[bool, float]:
    """(busy, queued_seconds) from real, cross-process in-flight leases,
    plus `node_claims` for the gaps `leases` alone cannot see.

    "Warm" only ever meant "resident in VRAM a moment ago" -- it says
    nothing about whether some other process's request against that exact
    node is in flight right now. Once several models share one capability
    tier, that gap stops being harmless: a single-model node like
    `e4b-linux` is *always* warm to itself (it never has to swap), so a
    scorer that only reads warm/cold treats "nobody else is using it" and
    "six other `team do` processes are already queued on it" identically,
    and every one of them independently concludes the same node is the
    cheapest pick. Measured live: exactly that, on a `generate.sh` fan-out
    of six parallel `team do` processes -- every planner call and every
    floor-4 write funnelled onto `e4b-linux` because it kept looking warm
    while `g26b` kept losing the race and looking cold, snowballing.

    `state.load_for` already exists for this -- `leases` is a real
    cross-process sqlite table, and `split`/`run`'s own task execution
    (`_run_task`) already registers one per request via `acquire_lease`/
    `release_lease`. `do`/`code` never did, so `load_for` reported 0
    in-flight for every node no matter how many concurrent processes were
    actually hammering it. See the `swarm.node_claim`-wrapped calls in
    `build_components` and `codegen.generate_file` for the matching lease
    now taken around each real request.

    That lease, though, only exists for the few hundred milliseconds of
    an actual `chat_complete` round trip -- `codegen.generate_file` holds
    `node_claim` (a *different* table, `node_claims`) for its whole
    attempt loop, acquiring and releasing a `leases` row once per
    individual request inside that loop. In the gap between two of a
    busy process's own requests -- gate-checking a candidate, building
    the next repair prompt -- `leases` legitimately shows nothing even
    though the node is still genuinely locked for however long that
    attempt loop keeps running. Measured live: several independent
    `team do` processes (one per step of a parallel fan-out, each
    running its own decompose-and-write with no visibility into any
    other) all scored the same fast, always-warm, single-model node as
    their best pick during exactly one of those gaps, and all queued
    behind it -- correctly and atomically (`try_claim_node` never lets
    two attempts actually run at once), but for no reason connected to
    whether a genuinely idle box was sitting right next to it the whole
    time. `swarm.State.active_claim` reads the table that actually
    reflects this, so this function now checks both rather than only
    the one that misses the gap.
    """
    # A lease from a process that no longer exists must not read as busy --
    # see `swarm.State.prune_dead_leases` for the live case this caught
    # (two ~8-minute-old rows for dead PIDs making both `e4b-linux` and
    # `g26b` look occupied to every caller of this function).
    state.prune_dead_leases()
    depth, queue_s = state.load_for(node.name)
    busy = depth >= node.max_parallel
    if not busy:
        claim = state.active_claim(node.name)
        if claim is not None:
            busy = True
            # No `est_seconds` on this table to size the wait accurately --
            # the point is only to stop scoring this node as free, not to
            # predict exactly how long it stays locked. A fixed, modest
            # estimate is enough to push it behind a node `load_for` can
            # actually measure, without inventing false precision.
            queue_s = max(queue_s, _CLAIM_BUSY_ESTIMATE_S)

    # `busy` above is a single bit and `queue_s` a flat estimate either
    # way -- neither says whether one sibling process is ahead of this
    # caller or five are. Every independent `team do` process reads the
    # exact same bit, so they all rank the same node "busy but only by
    # 60s" and every one of them queues a worker thread onto it, while a
    # node with zero waiters right now sits untouched. Measured live: a
    # `generate.sh`-style fan-out concentrated its entire floor-4 backlog
    # onto one node this way, each new process seeing the same flat
    # signal the one before it saw and reaching the same conclusion.
    # `waiter_count` is the number actually queued (holding or waiting)
    # system-wide, so scoring an extra `_CLAIM_BUSY_ESTIMATE_S` per
    # waiter beyond the first turns "everyone independently thinks this
    # is the best node" into "the fifth caller sees four people already
    # in line and picks someone else" -- what makes work actually spread
    # out instead of pile up.
    waiters = state.waiter_count(node.name)
    if waiters >= 1:
        busy = True
        queue_s = max(queue_s, waiters * _CLAIM_BUSY_ESTIMATE_S)
    return busy, queue_s


def pick_solvers(cfg: swarm.Config, state: swarm.State, floor: int, count: int = 2,
                 family: Optional[str] = None, max_over: Optional[int] = None
                 ) -> List[Tuple[swarm.Node, str]]:
    """Pick distinct solvers on distinct nodes, fastest first.

    One per node matters: two solvers sharing a machine would serialise, and
    on a single-slot node they would evict each other. Spread across boxes,
    the second opinion is effectively free in wall-clock.

    `max_over` caps how far above the floor a model may be. Without it a floor
    is only a minimum, so asking for capability 2 to get cheap boilerplate
    written quietly enrolled the 26b as well -- and it then spent five minutes
    on a slugify function that a small box does in forty seconds. When the
    floor expresses "this is routine", the ceiling has to be said too.

    A node already serving another process's request is scored as if its
    warm-up cost were the length of that request's own queue, on top of
    whatever it would cost to actually run once it is free -- not excluded
    outright, since every capable node being simultaneously busy is a real
    state this must still return *something* for, but no longer indistinguishable
    from "free and warm" the way plain warm/cold made it.
    """
    per_node: List[Tuple[float, swarm.Node, str]] = []
    for node in cfg.enabled_nodes():
        busy, queue_s = _node_load(state, node)
        best = None
        for model in node.models:
            meta = cfg.model_meta(model)
            capability = int(meta.get("capability", 1))
            if capability < floor:
                continue
            if max_over is not None and capability > floor + max_over:
                continue
            if not allowed_family(cfg, model, family):
                continue
            if float(node.model_bias.get(model, 1.0)) < 0.5:
                continue
            _pf, decode, cold = rates(cfg, state, node, model)
            cur = state.resident_model(node.name)
            score = (0.0 if (cur and cur[0] == model) else cold) + 600.0 / decode
            if busy:
                score += queue_s
            if best is None or score < best[0]:
                best = (score, node, model)
        if best:
            per_node.append(best)
    per_node.sort(key=lambda x: x[0])
    return [(n, m) for _s, n, m in per_node[:count]]


def pick_writer(cfg: swarm.Config, state: swarm.State, floor: int,
                family: Optional[str] = None
                ) -> Optional[Tuple[swarm.Node, str]]:
    """One writer for `floor`, falling back to the best weaker model when
    nothing in the fleet meets it, rather than giving up.

    `run_components`'s own pool selection already does this once, up
    front, for a component's first attempt (`if not strong: strong =
    light[:1]`) -- but every *repair* pass (`interface_gate`,
    `fix_redefinitions`, the integration-check retry loop) picks its
    writer fresh, per call, and each one used to stop at `if not writers:
    continue` the moment no node offered the requested floor. That was
    silent: a component skipped this way looks identical, in the run's
    own output, to one repair round finding nothing wrong. Measured live
    against the case that motivated this -- toggling the whole g26b box
    off (`swarm.Config.toggle_26b`) removes the only floor-4 model in the
    fleet entirely, so every one of these three call sites would go quiet
    on a floor-4 file needing a fix, forever, with nothing printed to say
    why.

    So a repair always gets someone: exact floor first, then anything at
    or above it, then -- new here -- the best model below it, the same
    "still better than nobody" call `run_components` already makes for a
    component's very first attempt. `None` only when literally no enabled
    node offers any model at all.

    Ranked idle-first within each tier, the same real cross-process lease
    check `pick_fallback_writer` already uses for the identical reason.
    Every call to this function is one direct, unraced attempt -- unlike
    an ordinary component's first write, a repair through `interface_gate`/
    `repair_redefinitions`/`integration_gate` never gets `run_components`'
    own idle-race protection if the node it lands on turns out to be slow.
    Measured live: two successive `interface_gate` repair rounds for the
    same file both landed on `e2b-2` -- this fleet's slowest, most-often-
    asleep box, per its own config notes. In that run every other node was
    genuinely busy with sibling components too, so `e2b-2` really was the
    only idle candidate and this fix alone would not have changed that
    outcome -- but `pick_solvers`' own busy-awareness is a *soft*,
    additive score penalty (a flat estimated wait added on top of a real
    speed measurement), not a hard rule, so a busy node that is fast
    enough can still outscore an idle one that is much slower. `count` is
    raised so each tier has more than one candidate to choose among, and
    `_node_load` (the same busy/idle signal `pick_fallback_writer` and
    `pick_idle_race_candidates` already trust) breaks the tie with a hard
    idle-first rule instead -- a stable sort, so `pick_solvers`' own
    speed/bias ranking is preserved among candidates that are equally idle
    or equally busy, and only overridden when one is actually free and a
    faster one is not.
    """
    def idle_first(cands: List[Tuple[swarm.Node, str]]
                  ) -> List[Tuple[swarm.Node, str]]:
        return sorted(cands, key=lambda nm: _node_load(state, nm[0])[0])

    exact = pick_solvers(cfg, state, floor, count=4, family=family, max_over=0)
    if exact:
        return idle_first(exact)[0]
    at_or_above = pick_solvers(cfg, state, floor, count=4, family=family)
    if at_or_above:
        return idle_first(at_or_above)[0]
    fallback = pick_solvers(cfg, state, 1, count=4, family=family)
    return idle_first(fallback)[0] if fallback else None


def pick_stronger_writer(cfg: swarm.Config, state: swarm.State,
                         current_model: str, floor: int,
                         family: Optional[str] = None,
                         ) -> Optional[Tuple[swarm.Node, str]]:
    """The rung between "restart the same model" and "ask the planner to
    reconsider the CONTRACT".

    Two independent rolls on the same model failing the same way is
    already read elsewhere in this file as a verdict on the *plan*, not
    the code -- but that conflates two different explanations. The other
    one is that this model, specifically, was not capable enough, and
    nothing before this point ever tested it: every repair attempt and
    the whole-loop restart both stay on whatever `(node, model)` the
    worker thread that claimed this component happened to be. `LOCAL.md`
    already documents the fix as a move an operator makes by hand ("when
    a task is worth minutes of extra depth, the 26b is still there");
    this is that move, offered automatically, exactly once, only after
    the cheaper explanations have already failed to converge.

    Deliberately narrow in both directions. Only a *strictly* higher
    `quality` counts as stronger -- a tie is a coin flip, not an
    escalation, and escalating to a same-or-lower-quality model would
    spend real time restating "this model isn't the problem" a second
    way. And unlike `pick_solvers`, a model held down by `model_bias`
    (`gemma4:12b` and `gemma4-fixed:latest` on `g26b`, deliberately
    excluded from *routine* selection so the default writer owns the
    box) is not filtered out here -- that bias exists precisely to keep
    those models in reserve for exactly this case, and filtering them out
    of the one caller that is supposed to reach for them would make the
    reserve permanently unreachable.

    Returns `None` when no enabled node offers anything strictly better
    at or above `floor` -- including the ordinary case where the model
    that just failed twice already is the fleet's best, so there is
    nowhere to escalate to and the existing replan path is unchanged.
    """
    cur_quality = float(cfg.model_meta(current_model).get("quality", 0.0))
    best: Optional[Tuple[float, swarm.Node, str]] = None
    for node in cfg.enabled_nodes():
        for model in node.models:
            if model == current_model:
                continue
            meta = cfg.model_meta(model)
            if int(meta.get("capability", 1)) < floor:
                continue
            if not allowed_family(cfg, model, family):
                continue
            quality = float(meta.get("quality", 0.0))
            if quality <= cur_quality:
                continue
            if best is None or quality > best[0]:
                best = (quality, node, model)
    if best is None:
        return None
    return best[1], best[2]


def pick_fallback_writer(cfg: swarm.Config, state: swarm.State,
                         current_node: str, floor: int,
                         family: Optional[str] = None,
                         ) -> Optional[Tuple[swarm.Node, str]]:
    """Any other eligible (node, model) for this floor, when the reason to
    move on is not that the model answered wrongly but that it did not
    answer at all.

    `pick_stronger_writer`, just above, exists for the opposite failure --
    the code came back wrong twice, so a *strictly better* model is worth
    trying, and a tie or a downgrade tells you nothing about whether the
    model was the problem. That bar is the wrong one for a `"budget: gave
    up ... the node stopped answering"` failure, because that history
    entry is not a verdict on quality at all -- it is a report that this
    one box did not respond in time. Measured live: a component spent its
    entire generation budget, then the whole-loop restart's entire budget
    again, both on the same node, and was reported FAILED with nothing
    else ever tried, on a fleet that had other idle capacity the whole
    time. The fix a slow-or-wedged node calls for is not "a smarter
    model", it is "a different box" -- of any quality at or above the
    floor, the same one this component would have been given if the
    unresponsive node had simply never been picked.

    Ranked idle-first -- the same real, cross-process lease check
    `_node_load` gives `pick_role_candidates`, so this genuinely means "try
    something available right now" rather than "try whatever scores
    highest and hope it is free" -- and quality only breaks a tie among
    equally-available candidates, never required to be higher. A node that
    looks busy is not excluded outright, only deprioritised: if every
    other eligible node happens to be busy too, the least-bad option is
    still better than reporting the component FAILED without trying
    anyone else. `model_bias` is ignored for the same reason
    `pick_stronger_writer` ignores it: this only ever fires after ordinary
    selection and a full restart have both already failed, which is
    exactly the reserve capacity that bias exists to protect.
    """
    candidates: List[Tuple[bool, float, float, swarm.Node, str]] = []
    for node in cfg.enabled_nodes():
        if node.name == current_node:
            continue
        for model in node.models:
            meta = cfg.model_meta(model)
            if int(meta.get("capability", 1)) < floor:
                continue
            if not allowed_family(cfg, model, family):
                continue
            busy, queue_s = _node_load(state, node)
            quality = float(meta.get("quality", 0.0))
            candidates.append((busy, queue_s, quality, node, model))
    if not candidates:
        return None
    # Idle before busy, shortest queue before longest, highest quality
    # last (so it sorts as the tiebreak among otherwise-equal candidates,
    # since Python's sort is stable and this is the final key compared).
    candidates.sort(key=lambda c: (c[0], c[1], -c[2]))
    _, _, _, node, model = candidates[0]
    return node, model


def pick_idle_race_candidates(cfg: swarm.Config, state: swarm.State,
                              exclude_node: str, floor: int,
                              family: Optional[str] = None,
                              ) -> List[Tuple[swarm.Node, str]]:
    """Every node that is genuinely idle *right now*, besides
    `exclude_node`, one best-quality model each.

    `pick_fallback_writer` answers "who should this move to", singular,
    and tries them one at a time. That is the wrong shape for the case
    this feeds: a component already on the "node stopped answering" rung,
    with more than one other box sitting idle at that exact moment. Trying
    the top-ranked one, waiting out its own full attempt budget, and only
    then trying the next idle box in turn wastes whichever of them would
    actually have answered fastest -- the fix is `race_generate_file`,
    below, and this is only the candidate list for it.

    Restricted to nodes that are idle *right now*, not merely eligible. A
    node that already has a real request in flight is excluded outright
    rather than included and scored low: racing against it would not free
    up any real capacity, since `node_claim` would just queue the racer
    behind whatever that node is already doing, and it would slow that
    other request down for a race this one has no real chance of winning.
    If nothing is idle, this returns `[]` and the caller falls back to
    `pick_fallback_writer`'s ordinary single-candidate behaviour, which
    still tries the least-bad busy node rather than nothing at all.

    `model_bias` is ignored for the same reason `pick_fallback_writer`
    ignores it: this only ever runs after ordinary selection and a full
    restart have both already failed, which is exactly the reserve
    capacity that bias exists to protect.
    """
    out: List[Tuple[swarm.Node, str]] = []
    for node in cfg.enabled_nodes():
        if node.name == exclude_node:
            continue
        busy, _queue_s = _node_load(state, node)
        if busy:
            continue
        best: Optional[Tuple[float, str]] = None
        for model in node.models:
            meta = cfg.model_meta(model)
            if int(meta.get("capability", 1)) < floor:
                continue
            if not allowed_family(cfg, model, family):
                continue
            quality = float(meta.get("quality", 0.0))
            if best is None or quality > best[0]:
                best = (quality, model)
        if best:
            out.append((node, best[1]))
    return out


def solve_parallel(targets: List[Tuple[swarm.Node, str]], prompt: str,
                   cfg: swarm.Config, state: swarm.State,
                   ) -> List[Dict[str, Any]]:
    """Run the same prompt on several nodes at once, independently."""
    policy = swarm.standing_policy()
    out: List[Dict[str, Any]] = [{} for _ in targets]

    def solve(i: int, node: swarm.Node, model: str) -> None:
        t0 = time.monotonic()
        try:
            messages = swarm.build_messages(prompt, None, "", False, policy)
            ptoks = sum(swarm.est_tokens(m["content"]) for m in messages)
            with swarm.node_claim(state, node, model):
                r = swarm.chat_complete(
                    node, model, messages,
                    num_ctx=swarm.pick_num_ctx(cfg, node, model, ptoks, 3000),
                    answer_tokens=700, timeout=1800)
            state.record_perf(node.name, model, r["sample"])
            state.mark_resident(node.name, model)
            out[i] = {"target": "%s/%s" % (node.name, model), "answer": r["text"],
                      "thinking_chars": len(r.get("thinking") or ""),
                      "seconds": round(time.monotonic() - t0, 1)}
        except swarm.OllamaError as exc:
            out[i] = {"target": "%s/%s" % (node.name, model), "error": str(exc),
                      "seconds": round(time.monotonic() - t0, 1)}

    threads = [threading.Thread(target=solve, args=(i, n, m), daemon=True)
               for i, (n, m) in enumerate(targets)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    return out


def _race_scratch_path(real_path: str, label: str, i: int) -> str:
    """A scratch path for one race/hedge candidate's own `generate_file`
    call, sharing the real path's extension rather than appending a
    `.tmp` suffix after it.

    `codegen.is_python(path)` is `path.endswith(".py")`, and every
    Python-only gate in `generate_file`'s per-attempt chain --
    `gate_fabricated_client`, `gate_output_json_key`,
    `gate_placeholder_id_literal`, `gate_required_cli_args`, and half a
    dozen more -- is silently skipped whenever that is False. The
    original scratch name here was `<out_path>.race0.tmp`, which for a
    real path of `main.py` produces `main.py.race0.tmp` -- ending in
    `.tmp`, not `.py`. Every one of those gates was therefore quietly
    disabled for any component that ever raced or hedged, which measured
    live is not a rare path: a `create_task` step won a hedge race and
    shipped a hand-written `MockClient` that never called `requests` at
    all, the exact shape `gate_fabricated_client` exists to catch and
    does catch when run against the same file directly outside this
    code path.

    The marker segment (`intent.RACE_SCRATCH_MARKER`) keeps the base name
    unambiguous as scratch without touching the extension, so a straggler
    that finishes late and leaves a stray file behind is still never
    picked up by `run_components`' own `os.listdir(root)` scan for real,
    existing `.py` content on a later request in the same project (nor by
    `session.py`'s equivalent scans, which check the same marker).
    """
    root, ext = os.path.splitext(real_path)
    return "%s%s_%s%d__%s" % (root, intent.RACE_SCRATCH_MARKER, label, i, ext)


def race_generate_file(candidates: List[Tuple[swarm.Node, str]], spec: str,
                       out_path: str, cfg: swarm.Config, state: swarm.State,
                       *, attempts: int, answer_tokens: int, root: str,
                       extra: str, env_extra: Optional[Dict[str, str]],
                       component_label: str,
                       mock: Optional[Any] = None,
                       expected_counts: Optional[Dict[str, int]] = None,
                       implied_nonempty: Optional[Set[str]] = None,
                       dep_paths_val: Optional[Sequence[str]] = None,
                       forbid_required_cli_args: bool = False,
                       env_names: Optional[Sequence[str]] = None,
                       original_request: str = "",
                       ) -> Tuple[Dict[str, Any], swarm.Node, str]:
    """Run `generate_file` on every idle candidate at once; accept
    whichever finishes first with `ok`, and abandon the rest.

    Fed by `pick_idle_race_candidates`, and only ever called with more
    than one candidate -- a single one has no race to run, and the
    caller uses the ordinary single-node path for that case.

    Each racer writes to its own scratch path (`_race_scratch_path`,
    which keeps `out_path`'s own extension so every Python-only gate in
    `generate_file` still runs -- see its docstring), never to the real
    `out_path` directly: two `generate_file` calls writing to and
    gate-testing the same file at once would corrupt each other, one
    thread's `gate_import` reading the file mid-rewrite by another
    thread. Only the winner's content ever reaches the real path, copied
    there once the race is decided, with the same backup-before-overwrite
    step an ordinary single-write
    already performs (`codegen.generate_file` only backs up the *real*
    path, which none of these calls ever touch, so it has to be done
    here instead).

    Each racer is also tagged with its own `SWARM_COMPONENT` suffix
    (`<label>#raceN`), so a losing racer's traffic against the mock is
    never mistaken for the component that actually ships -- `mockapi.
    rejected_for` matches this header verbatim -- and never contaminates
    the winner's own rejected/count checks with a different attempt's
    concurrent calls.

    Losers are not waited for. They are daemon threads that may still be
    mid-request when this returns, and that is deliberate: this only
    fires when the fleet is otherwise idle, so the compute is free, and
    blocking on the slowest box to finish before returning would defeat
    the entire point of racing it against faster ones. Their scratch
    files, if any of them ever finish, are cleaned up on a best-effort
    basis by the loop below for whichever ones happen to have already
    reported in; a straggler that finishes after this function has
    already returned leaves a `_race_scratch_path`-named file behind.
    Its extension still matches the real target's (so gates ran on it
    correctly while it was being written), but
    `intent.is_race_scratch_name` is what actually keeps it from being
    read back as real project content later -- `run_components`' own
    scan for existing `.py` files on a later request in this directory
    checks it explicitly.
    """
    q: "queue.Queue[Tuple[int, swarm.Node, str, Dict[str, Any], str]]" \
        = queue.Queue()

    def attempt(i: int, node: swarm.Node, model: str) -> None:
        tag = "%s#race%d" % (component_label, i)
        scratch = _race_scratch_path(out_path, "race", i)
        env = dict(env_extra or {})
        env["SWARM_COMPONENT"] = tag
        rejected = sent_count = count_check = None
        if mock is not None:
            rejected = lambda since, p=tag: mock.rejected_for(p, since)
            sent_count = lambda: len(mock.calls)
            count_check = (lambda since, p=tag:
                          mock.count_problems_for(p, since, expected_counts)
                          + mock.zero_problems_for(
                              p, since, implied_nonempty or set()))
        try:
            r = codegen.generate_file(
                spec, scratch, node, model, cfg, state, check=None,
                attempts=attempts, answer_tokens=answer_tokens,
                thinking=thinking_tokens(cfg, model), root=root,
                extra=extra, verbose=False, env_extra=env,
                rejected=rejected, sent_count=sent_count,
                count_check=count_check, dep_paths=dep_paths_val,
                forbid_required_cli_args=forbid_required_cli_args,
                env_names=env_names or env_vocabulary(cfg, root),
                original_request=original_request)
        except Exception as exc:                        # noqa: BLE001
            r = {"ok": False, "attempts": 0, "seconds": 0.0,
                "history": [{"stage": "race", "error": str(exc)}],
                "target": "%s/%s" % (node.name, model)}
        q.put((i, node, model, r, scratch))

    threads = [threading.Thread(target=attempt, args=(i, n, m), daemon=True)
              for i, (n, m) in enumerate(candidates)]
    for t in threads:
        t.start()

    finished: List[Tuple[int, swarm.Node, str, Dict[str, Any], str]] = []
    winner = None
    for _ in range(len(threads)):
        item = q.get()
        finished.append(item)
        if item[3].get("ok"):
            winner = item
            break

    if winner is None:
        # Nobody won -- clean up whatever has reported in so far and
        # report the first result for a consistent history entry. Every
        # candidate genuinely failed, so which one's error is shown
        # matters less than that the caller still gets a real `res` to
        # log against `component.history_trail`.
        for _i, _n, _m, _r, scratch in finished:
            try:
                os.remove(scratch)
            except OSError:
                pass
        _i, node, model, r, _s = finished[0]
        return r, node, model

    _i, node, model, r, scratch = winner
    try:
        if os.path.exists(out_path):
            backup = codegen.backup_path(out_path)
            os.makedirs(os.path.dirname(backup), exist_ok=True)
            shutil.copy2(out_path, backup)
        shutil.copy2(scratch, out_path)
    finally:
        for _i2, _n2, _m2, _r2, s in finished:
            try:
                os.remove(s)
            except OSError:
                pass
    return r, node, model


def named_model(cfg: swarm.Config, name: str) -> Optional[Tuple[swarm.Node, str]]:
    """Locate one specific model by name on any enabled node.

    Deliberately ignores `model_bias`, because bias expresses what should be
    picked for routine work and this is the opposite case: a model held back
    from ordinary traffic precisely so it is available when it is wanted.
    """
    for node in cfg.enabled_nodes():
        for model in node.models:
            if model == name:
                return node, model
    return None


def static_report(paths: List[str], root: str) -> int:
    """Parse every file and run the detectors. No model, no network.

    Kept separate from the model review because the two have opposite
    economics. This half is milliseconds and was the only half that found a
    real bug across a night of measurement; the other half is minutes and
    confirmed two findings that were false.
    """
    findings = 0
    broken = []
    # Python only. `compile_check` and every detector in `patterns` read a
    # Python syntax tree, so handing them a page reports `invalid syntax at
    # line 1` about a file that is perfectly well-formed HTML -- which is
    # the false positive this project keeps deciding is worse than no
    # detector, and here it also names an innocent file in a run's summary.
    paths = [p for p in paths if codegen.is_python(p)]
    for path in paths:
        res = evidence.compile_check(path)
        if not res["parses"]:
            broken.append((os.path.relpath(path, root), res["error"]))
    if broken:
        print("\nparse errors:")
        for rel, err in broken:
            print("  FAIL  %s: %s" % (rel, err))
        findings += len(broken)

    hits = patterns.scan_all(paths, root)
    if hits:
        print("\nstatic analysis found %d issue(s):" % len(hits))
        for h in hits:
            print("  %s:%s  %s" % (h["file"], h["lines"], h["claim"]))
            print("      %s" % h["why"])
        findings += len(hits)
    elif not broken:
        print("\n%d file(s) parse clean, no static issues." % len(paths))
    return findings


PLAN_DIR = os.path.join(swarm.HERE, ".swarm", "plans")


def _plan_path(root: str) -> str:
    """One saved plan per project, kept beside the pool rather than in the tree.

    Storing it under the project would put a dot-directory into whatever
    checkout you pointed this at, which is rude for a tool invoked from
    anywhere. Keying by the root means several projects can each have a last
    run without colliding.

    Shares `session.project_key` rather than hashing the root again here, so
    a plan and that project's history can never end up under different names
    -- a `--retry` that finds its plan while the planner finds no history for
    the same directory is the confusing half-state that follows.
    """
    return os.path.join(PLAN_DIR, session.project_key(root) + ".json")


DEFAULT_ENV_NAMES = ["API_BASE_URL", "API_KEY"]


def env_vocabulary(cfg: swarm.Config, root: str = "") -> List[str]:
    """The environment variable names generated code must read.

    Nothing told a writer what to call a credential, so three consecutive
    runs asked for `AUTH_TOKEN`, `API_KEY` and `API_AUTH_TOKEN`. Each file
    was internally consistent and every run reported clean; the operator
    exported the previous run's name and the script refused to start.

    Deliberately a property of the pool rather than of a directory. Reading
    the names a project already uses was tried first and is the same bug
    slowed down: a fresh directory has nothing to inherit, so every new
    project invents its own name again, and the operator is back to reading
    generated source to find out what to export. One name everywhere is the
    only version of this that an operator can hold in their head.

    So it comes from `config.json`, where an operator can change it once and
    have every project follow. A `.env` still contributes its own names --
    those are facts about the operator's actual credentials, and the point
    of reading them was always that `STRIPE_API_KEY` should not come back as
    `STRIPE_KEY`.
    """
    names = list(cfg.data.get("env_names") or DEFAULT_ENV_NAMES)
    for extra in attach.env_names(root) if root else []:
        if extra not in names:
            names.append(extra)
    return names


def entry_points(components: Sequence[intent.Component]) -> List[str]:
    """The files an operator actually runs, not every file that can run.

    Every generated component carries a demo block by construction, so
    "has a `__main__`" describes all of them and the how-to-run block
    listed the whole package -- four invocations where one was wanted, and
    no way to tell which one did the job.

    The entry point is the sink of the dependency graph: it depends on
    others and nothing depends on it. That is a fact about the plan rather
    than a guess about intent, and it is the same structural test
    `checks.joins` uses to decide a component has no behaviour of its own
    to assert.

    Several sinks means several answers, which is honest -- a package with
    two independent tools has two commands. A single-component plan has no
    graph to read, so its one file is the answer.
    """
    built = [c for c in components if c.ok]
    if len(built) <= 1:
        return [c.path for c in built]
    depended_on = {d for c in components for d in c.deps}
    sinks = [c.path for c in built if c.name not in depended_on]
    # A cycle, or a plan where everything is depended on, leaves no sink.
    # Saying nothing would be worse than saying too much.
    return sinks or [c.path for c in built]


    # The one truly content-free "running ..." line -- literally a label
    # for the traceback dump that follows it, nothing more. `gate_smoke`
    # has since grown other messages that also start with "running " but
    # are themselves the diagnosis (`_missing_sibling_error`,
    # `_no_mock_sink_error`'s message) -- filtering every "running "
    # prefix indiscriminately, as this used to, threw those away too and
    # replaced a clear "this is not a defect" explanation with the bare
    # exception line from the traceback tail still attached below it, the
    # exact "wrong line wins" failure this project already fixed once for
    # `crossref.Finding.text()`. Matched narrowly, on the literal
    # boilerplate shape and nothing else.
_RUNNING_RAISED_RE = re.compile(r"^running \S+ raised:?$")


def why_it_failed(error: str) -> str:
    """The line of a gate failure worth putting in a summary.

    The first line of a smoke failure is `running main.py raised:` -- a
    label, not a reason -- and printing it turned a real diagnosis into
    "smoke: running main.py raised", which says only what the reader could
    already see from the stage name. The exception is the last line of a
    traceback, so that is what is shown, along with the mock's verdict when
    there is one, since that is the sentence an operator can act on.

    A "running ..." line that is *not* that exact boilerplate -- one that
    names what actually went wrong, like "running main.py could not find
    ../01_create_project/output.json: a sibling step has not been run
    yet" -- is the opposite case: it is the reason, and the traceback tail
    still attached below it is the noise this time. Keeping it is what
    lets an operator see "this is not a defect in the file" in the
    one-line summary instead of a bare `RuntimeError` that reads like one.
    """
    lines = [ln.strip() for ln in (error or "").splitlines() if ln.strip()]
    if not lines:
        return "no detail"
    refused = [ln for ln in lines if " -> 4" in ln or " -> 5" in ln]
    rest = [ln for ln in lines if ln not in refused
            and not ln.startswith(("File \"", "The API ", "Traceback"))
            and not _RUNNING_RAISED_RE.match(ln)]
    # A self-explanatory "running ..." diagnosis line outranks a bare
    # exception line from the traceback tail below it -- it is strictly
    # more informative about whether this is worth rewriting the file
    # over, so prefer it if one is present rather than falling through to
    # whatever happens to be last.
    diagnosis = next((ln for ln in rest if ln.startswith("running ")
                      and "could not" in ln), None)
    exception = diagnosis or (rest[-1] if rest else lines[-1])
    if refused:
        return "%s  (%s)" % (exception, refused[-1])
    return exception


def save_plan(root: str, request: str, components: List[intent.Component],
              check: Optional[str], answer_tokens: int,
              api: Optional[str] = None,
              decompose_failed: bool = False) -> None:
    """Record what was attempted so a later run can pick up the failures.

    `decompose_failed` marks the one shape where `components` is `[]` for a
    reason other than "every component already succeeded" -- the planner
    never produced anything to attempt at all. Without the flag this is
    indistinguishable on load from a clean run, and `--retry` would report
    "nothing failed; nothing to retry" for a run that never got the chance
    to fail.
    """
    try:
        os.makedirs(PLAN_DIR, exist_ok=True)
        payload = {
            "root": os.path.abspath(root),
            "request": request,
            "check": check,
            "answer_tokens": answer_tokens,
            # Which registered spec this run used, so a retry can put the
            # mock back. Without it a retried API client is tested with
            # nothing listening: every request fails, every attempt fails,
            # and the run looks like the model cannot write the file.
            "api": api,
            "when": time.time(),
            "decompose_failed": decompose_failed,
            # The contract has to survive too. It is the only statement of who
            # owns each shared name, so a retry that drops it both stops
            # telling writers what to agree on and leaves ownership to be
            # guessed from the dependency arrows -- which points the repair
            # pass at the file that was right. Observed exactly that: a plan
            # saying `room_map.py owns Room` came back from a retry as
            # "room_map.py redeclares Room, which belongs to engine.py".
            "contract": next((c.contract for c in components
                              if getattr(c, "contract", "")), ""),
            "components": [{"name": c.name, "path": c.path, "floor": c.floor,
                            "deps": list(c.deps), "spec": c.spec,
                            "ok": bool(c.ok), "error": c.error or "",
                            # Total attempts/wall-clock across every rung
                            # this component needed, not just the last one
                            # -- previously computed at runtime and then
                            # dropped before the plan was ever written to
                            # disk, so a component that took 12 attempts
                            # and 20 minutes to eventually pass looked
                            # identical, on disk, to one that passed first
                            # try. This is what a bulk scan across many
                            # saved plans needs to rank "which of these
                            # successful runs actually struggled" without
                            # re-parsing every generate.log by hand.
                            "attempts": int(getattr(c, "attempts", 0) or 0),
                            "seconds": round(
                                float(getattr(c, "seconds", 0.0) or 0.0), 1),
                            # `error` is retracted to "" the moment a
                            # component succeeds (see run_components,
                            # "Succeeding has to retract it"), so a
                            # component that needed a restart or an
                            # escalation before it passed would otherwise
                            # leave no trace anywhere that it ever failed
                            # at all, on disk or on screen -- see
                            # run_components' own "needed N rung(s)"
                            # print for the live-log half of this fix.
                            # Saved regardless of final `ok`, since the
                            # question "why did this need repair" is just
                            # as real for a component that now passes.
                            "history_trail": list(
                                getattr(c, "history_trail", None) or [])}
                           for c in components],
        }
        with open(_plan_path(root), "w", encoding="utf-8") as fh:
            json.dump(payload, fh, indent=2)
    except OSError:
        # Losing the retry record must never fail a run that otherwise worked.
        pass


def load_plan(root: str) -> Optional[Dict[str, Any]]:
    try:
        with open(_plan_path(root), encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


def _retry_restored_request(root: str, request: str) -> str:
    """The saved plan's own request text, when this call has none of its
    own -- which is every `--retry` call, since `--retry` never asks the
    operator to retype it.

    Used for two things now, not one. It always fed the total-decompose-
    failure resume path (there is nothing else to decompose from). It now
    also feeds `cmd_do`'s API slicing/CONTRACT block, which used to be
    skipped outright on every retry on the theory that "a retry has no
    request to slice against" -- true only in the sense that a retry has
    no *new* request; `save_plan` always recorded the original one,
    unconditionally, for both the ordinary resume case and the total-
    failure case. Restoring it here means a retried component's repair
    prompt gets `openapi.auth_block`/`connection_setup_block`/the index
    text again, instead of the mock coming back (the half this always
    restored) with no reminder of how the credentials it broke on are
    supposed to be built. Measured live: a `create_task` step retried
    after a real 401 got its mock back but no auth guidance, because this
    whole block used to be skipped on every retry regardless of whether a
    request was available to slice against.

    A call with its own `request` already (an ordinary, non-retry `do`)
    passes it straight through unchanged -- this only ever fills a gap,
    never overrides a real one.
    """
    if request:
        return request
    return (load_plan(root) or {}).get("request") or request


def project_root() -> str:
    """The tree being worked on, which is not where this script lives.

    `swarm.HERE` locates the pool's own config and state, so those follow the
    script and there is one of each however it is invoked. Files being read or
    written belong to whatever project you are standing in instead: run it from
    a checkout elsewhere and `audit src/` should mean that checkout's `src`,
    and generated components should land there rather than in the swarm's own
    directory. Behaviour is unchanged when the two coincide.
    """
    return os.environ.get("SWARM_ROOT") or os.getcwd()


def judging_model(cfg: swarm.Config, state: swarm.State, floor: int,
                  exclude_family: Optional[str] = None,
                  ) -> Optional[Tuple[swarm.Node, str]]:
    """The model trusted to decide, which is not simply the most capable free one.

    Every role that settles a question goes through here so that changing the
    default *writer* cannot quietly change the *judges*. That is not
    hypothetical: raising `gemma4:12b` to capability 4 so it would write hard
    components also handed it the crosscheck judge, the escalation judge and
    the draft critic, because all three ask for the most capable model at floor
    4 and the 26b had just been pinned down to keep it out of routine work. The
    12b had been measured that same evening as the weaker judge -- it called
    crashing eviction code "functionally correct" -- so three verification
    paths silently got worse as a side effect of a throughput decision.

    An explicit family exclusion still falls through to open selection, since
    the pin names one model and cannot honour a request for a different family.
    """
    names = cfg.data.get("team", {}).get("judge_model")
    if isinstance(names, str):
        names = [names]
    if names and not exclude_family:
        # An ordered list: the first one an enabled node actually serves.
        for name in names:
            found = named_model(cfg, name)
            if found:
                return found
    return pick_role_model(cfg, state, floor, exclude_family=exclude_family)


def pick_role_model(cfg: swarm.Config, state: swarm.State, floor: int,
                    family: Optional[str] = None,
                    exclude_family: Optional[str] = None,
                    ) -> Optional[Tuple[swarm.Node, str]]:
    """Pick a model for a named role: most capable, least busy, then fastest.

    Judging is where capability pays for itself. With reasoning off, the 26b
    returned a perfect verdict in 4.2s while the mid-size models missed errors
    and raised false alarms, and every false alarm triggers an escalation --
    so the cheap judge is not actually the cheap option.

    Ties among equally *capable* models used to go to whichever answered
    soonest, which was a harmless tiebreak back when capability 4 named
    exactly one node (`g26b`). Once `gemma4:e4b`/`gemma4-e4b-fixed:latest`
    also carry capability 4, "soonest" stopped being a tiebreak and became
    the whole decision: a single-model node is always warm to itself, so it
    always looks faster than a multi-model node paying a real cold-load
    penalty for not being the one already resident -- and every planner
    call across a `generate.sh`-style parallel fan-out independently drew
    the same conclusion and piled onto it. Measured live: every plan and
    every floor-4 write funnelled onto `e4b-linux`, `g26b` never got picked
    long enough to warm up, and the run had no more real parallelism than
    running the six requests one at a time.

    So the order is now: not-currently-busy beats busy (real, cross-process
    state from `_node_load`, not "resident a moment ago"); among equally
    busy/free candidates, higher `quality` wins outright rather than being
    ignored in favour of raw latency -- `g26b`'s preferred model measures
    0.90-0.97 against `gemma4:e4b`'s 0.72, and nothing about being warm
    changes what it actually knows. Latency is the last tiebreak, for two
    models that are both free and equally good. This still lets a busy
    `g26b` lose to an idle, lower-quality node rather than making every
    caller queue behind it -- the whole point of adding several capability-4
    boxes was that one being occupied should not stall a role that has to
    be filled -- it just stops "slightly faster to load" from ever
    outranking "actually knows more" when both are equally available.
    """
    candidates = pick_role_candidates(cfg, state, floor, family, exclude_family)
    return candidates[0] if candidates else None


def pick_role_candidates(cfg: swarm.Config, state: swarm.State, floor: int,
                         family: Optional[str] = None,
                         exclude_family: Optional[str] = None,
                         exclude_nodes: Optional[Set[str]] = None,
                         ) -> List[Tuple[swarm.Node, str]]:
    """Every eligible (node, model) for a role, ranked best first.

    `pick_role_model` returns only `candidates[0]` -- this is the ranking it
    is built on, exposed separately so a caller can try more than the top
    choice. See `claim_role_model` for why that turned out to matter: the
    ranking is a snapshot of busyness taken at call time, and several
    parallel callers reading the same snapshot all agree on the same top
    choice, so only one of them should actually wait for it.

    `exclude_nodes` is a set of node names to leave out entirely, not
    merely deprioritise -- for a node this call's own caller already knows
    is genuinely unreachable this run (see `build_components`), as opposed
    to `busy`, which the ranking below already handles by sorting a busy
    node behind an idle one rather than dropping it.
    """
    candidates = []
    for node in cfg.enabled_nodes():
        if exclude_nodes and node.name in exclude_nodes:
            continue
        busy, queue_s = _node_load(state, node)
        for model in node.models:
            meta = cfg.model_meta(model)
            capability = int(meta.get("capability", 1))
            if capability < floor:
                continue
            fam = meta.get("family", "unknown")
            if family and fam != family:
                continue
            if exclude_family and fam == exclude_family:
                continue
            if float(node.model_bias.get(model, 1.0)) < 0.5:
                continue
            if not allowed_family(cfg, model, cfg.data.get("team", {}).get(
                    "restrict_to_family")):
                continue
            _pf, decode, cold = rates(cfg, state, node, model)
            cur = state.resident_model(node.name)
            warm = bool(cur and cur[0] == model)
            quality = float(meta.get("quality", 0.7))
            latency = (0 if warm else cold) + 400.0 / decode
            if busy:
                latency += queue_s
            key = (1 if busy else 0, -quality, latency)
            candidates.append((key, node, model))
    candidates.sort(key=lambda t: t[0])
    return [(n, m) for _, n, m in candidates]


def claim_first_free_role(cfg: swarm.Config, state: swarm.State,
                          floors: Sequence[int],
                          family: Optional[str] = None,
                          exclude_family: Optional[str] = None,
                          exclude_nodes: Optional[Set[str]] = None,
                          ) -> Tuple[Optional[swarm.Node], Optional[str], bool]:
    """Try to claim the best available role candidate, across floors,
    without ever blocking -- returns (node, model, held).

    A single `pick_role_model` call resolves to one best candidate; a
    `node_claim` around it then blocks if that one candidate is taken,
    even when a second, only slightly worse candidate (lower quality, or
    merely cold) is sitting idle right now. This is the same race
    write-phase claiming already fixed with `try_claim_node` + retrying
    across the pool (`claim()`), never carried over to planning, where it
    matters just as much: every parallel `team do` process ranks the
    fleet from the same snapshot, so they all agree `g26b` is the best
    floor-4 planner, all race to claim it, and the losers used to *wait*
    for it rather than immediately trying `e4b-linux` -- also floor 4,
    also idle, never even attempted. Measured live: this is exactly the
    "g26b is planning something else right now; waiting for it" shape a
    real multi-step orchestration run hit on every single step.

    `held=False` on return means every eligible candidate at the first
    floor that has any is genuinely busy; the caller should fall back to
    `swarm.node_claim`'s ordinary blocking wait on the returned
    (node, model) rather than refuse the request outright -- a slow
    answer still beats none.

    A lower floor is tried only when the higher one has *no* eligible
    candidate whatsoever, never merely because every candidate at the
    higher floor is busy right now -- that distinction is load-bearing,
    not cosmetic. The original call this replaces,
    `pick_role_model(4) or pick_role_model(2)`, only ever fell to floor 2
    when `pick_role_model(4)` returned `None` outright (zero floor-4
    nodes configured), since `pick_role_model` itself still returns a
    *busy* floor-4 node in preference to not returning one at all. An
    earlier version of this function instead pooled every floor's
    candidates into one list and tried all of them non-blockingly in a
    single pass, which meant a momentary lull in floor-4 availability --
    both real floor-4 nodes generating something else for a few seconds,
    the ordinary case under any real parallel fan-out -- silently
    demoted planning to whichever floor-2 node happened to be idle at
    that exact instant. Measured live: a plan that should have used a
    floor-4 model planned on `e2b-2/gemma4:e2b` instead, purely because
    `g26b` and `e4b-linux` were both busy for a moment; the weak model
    failed to decompose the request at all ("could not decompose;
    falling back to a single file"), and the fallback path needs `--out`
    for a single-file build, which a backgrounded `--api` orchestration
    step never passes -- so the step failed outright, fast, while its
    siblings were still correctly working. Quality tier is a floor for a
    reason; only genuine absence of that floor should ever move it.
    """
    for floor in floors:
        candidates = pick_role_candidates(cfg, state, floor, family,
                                          exclude_family,
                                          exclude_nodes=exclude_nodes)
        if not candidates:
            # Nothing at all qualifies for this floor -- the one case the
            # original `or` fallback covered. Try the next floor down.
            continue
        for node, model in candidates:
            if state.try_claim_node(node.name, model,
                                    max_parallel=node.max_parallel):
                return node, model, True
        # This floor has real candidates and every one of them is busy
        # right now. Commit to the best of them and let the caller block-
        # wait, exactly as `pick_role_model(floor)` alone would have --
        # never fall through to a lower floor for this reason.
        node, model = candidates[0]
        return node, model, False
    return None, None, False


@contextlib.contextmanager
def hold_or_wait(state: swarm.State, node: swarm.Node, model: str,
                 held: bool, on_wait: Optional[Any] = None) -> Any:
    """Finish what `claim_first_free_role` started.

    If it already won the claim (`held`), just hold it for the block and
    release afterwards -- the ordinary case now that most candidates are
    tried non-blockingly. If every candidate was busy, fall through to
    `swarm.node_claim`'s existing blocking wait on the one candidate
    `claim_first_free_role` picked as best, unchanged from before this
    existed.
    """
    if held:
        try:
            yield True
        finally:
            state.release_node(node.name)
    else:
        with swarm.node_claim(state, node, model, on_wait=on_wait) as got:
            yield got


# Room for the planner's answer. A plan is short, structured and capped at
# five components, so this is a bound on emission rather than a quality dial
# -- nothing is charged for room that goes unused, and the window is sized
# for the ceiling up front so growing it cannot trigger a reload.
#
# Starting tight was copied from `codegen`, where growth-on-proof stops a
# repair loop writing ever longer files. The trade is backwards for planning:
# a cut costs a whole second round trip of about 50s, against nothing for a
# ceiling that is never reached. Measured after raising it, on a request that
# wants one file: two components, so a loose cap does not invent work.
PLAN_TOKENS = 5120
PLAN_TOKENS_MAX = 8192

AUDIT_PROMPT = """Review this file for real bugs: logic errors, incorrect
assumptions, unsafe concurrency, resource leaks, wrong error handling.

Do not report style, naming, formatting, or missing type hints. Do not report
anything you are not confident is an actual defect. Reporting nothing is a
perfectly good answer and is much better than reporting something plausible
that turns out to be fine.

Every claim you make will be checked against the real source, including the
definitions of functions in other files. A claim that a call is unsafe will be
tested against what that function actually does, so name it.

FILE: {path}

{source}

{format}"""


def numbered_source(path: str, max_chars: int = 24000) -> str:
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        lines = fh.readlines()
    out = "".join("%6d| %s" % (i, t) for i, t in enumerate(lines, 1))
    if len(out) > max_chars:
        out = out[:max_chars] + "\n... (file truncated for review)"
    return out


def audit_file(node: swarm.Node, model: str, path: str, root: str,
               cfg: swarm.Config, state: swarm.State) -> Dict[str, Any]:
    """Ask one model for structured claims about one file."""
    rel = os.path.relpath(path, root)
    prompt = AUDIT_PROMPT.format(path=rel, source=numbered_source(path),
                                 format=evidence.CLAIM_FORMAT)
    t0 = time.monotonic()
    try:
        messages = [{"role": "user", "content": prompt}]
        ptoks = swarm.est_tokens(prompt)
        with swarm.node_claim(state, node, model):
            r = swarm.chat_complete(
                node, model, messages,
                num_ctx=swarm.pick_num_ctx(cfg, node, model, ptoks, 1400,
                                           reasoning=False),
                answer_tokens=900, headroom=1.6, think=False,
                temperature=0.0, timeout=1800)
        state.record_perf(node.name, model, r["sample"])
        state.mark_resident(node.name, model)
        return {"file": rel, "target": "%s/%s" % (node.name, model),
                "raw": r["text"], "seconds": round(time.monotonic() - t0, 1)}
    except swarm.OllamaError as exc:
        return {"file": rel, "target": "%s/%s" % (node.name, model),
                "raw": "", "error": str(exc),
                "seconds": round(time.monotonic() - t0, 1)}


def adjudicate(claim: evidence.Claim, node: swarm.Node, model: str,
               cfg: swarm.Config, state: swarm.State,
               rebut: bool = False) -> Tuple[str, str, float]:
    """Judge one claim against gathered evidence.

    With `rebut`, the framing is inverted: argue the claim is wrong. Used for
    the confirmation pass when no second capable box is available, since a
    model re-asked the same question tends to repeat itself, while a model
    asked to attack its own conclusion actually re-examines the evidence.
    """
    brief = evidence.evidence_brief(claim)
    template = evidence.REBUT_PROMPT if rebut else evidence.ADJUDICATE_PROMPT
    prompt = template.format(brief=brief)
    t0 = time.monotonic()
    try:
        with swarm.node_claim(state, node, model):
            r = swarm.chat_complete(
                node, model, [{"role": "user", "content": prompt}],
                num_ctx=swarm.pick_num_ctx(cfg, node, model,
                                           swarm.est_tokens(prompt), 700,
                                           reasoning=False),
                answer_tokens=280, headroom=1.8, think=False,
                temperature=0.0, timeout=1800)
        state.record_perf(node.name, model, r["sample"])
        state.mark_resident(node.name, model)
        v, why = evidence.parse_adjudication(r["text"])
        return v, why, round(time.monotonic() - t0, 1)
    except swarm.OllamaError as exc:
        return "UNPROVEN", "adjudicator failed: %s" % exc, round(time.monotonic() - t0, 1)


def cmd_audit(args, cfg: swarm.Config, state: swarm.State) -> int:
    """Find real bugs, by checking every finding against the actual source.

    A reviewer reading one file in isolation produces claims that are textually
    accurate and still wrong -- the motivating case was a "race condition" on a
    call whose callee locks internally, in another file the reviewer never saw.
    Asking a second model to re-read the same draft does not fix that; it has
    the same blind spot.

    So findings are not opinions here, they are claims with citations, and
    every citation is resolved against disk before anyone judges it. Whatever
    can be settled mechanically -- file missing, line past EOF, symbol that
    exists nowhere -- is settled with no model at all. The remainder goes to
    the most capable model with the cited source and the definitions of every
    symbol involved attached, and anything it confirms is put to a second
    independent judge, because a confirmed bug is the expensive kind to be
    wrong about.
    """
    root = project_root()
    paths: List[str] = []
    for p in args.paths:
        if os.path.isdir(p):
            for dirpath, dirnames, filenames in os.walk(p):
                dirnames[:] = [d for d in dirnames if d not in evidence.SKIP_DIRS]
                paths.extend(os.path.join(dirpath, f) for f in sorted(filenames)
                             if f.endswith(".py"))
        elif os.path.isfile(p):
            paths.append(p)
    if not paths:
        print("no files to audit", file=sys.stderr)
        return 2

    started = time.monotonic()

    # Stage 1: deterministic. No model can disagree with the parser.
    print("== parse check ==")
    broken = []
    for path in paths:
        res = evidence.compile_check(path)
        if not res["parses"]:
            broken.append(res)
            print("  FAIL  %s: %s" % (os.path.relpath(path, root), res["error"]))
    if not broken:
        print("  all %d file(s) parse" % len(paths))
    if broken and not args.keep_going:
        print("\nfix the syntax errors first.")
        return 1

    # Stage 1b: everything decidable from the syntax tree, decided here.
    #
    # This exists because recall is set by whoever raises claims, not by
    # whoever judges them. A judge cannot confirm a bug nobody mentioned, so
    # every hour spent choosing a judge bought precision and nothing else. The
    # probe's dict-mutated-while-iterated crash was missed by the 12b and the
    # 26b alike, and one of them called it an efficiency concern that the
    # rebuttal then dismissed as "functionally correct". A detector finds it
    # every time and cannot be argued out of it.
    static_claims: List[evidence.Claim] = []
    for raw in patterns.scan_all(paths, root):
        c = evidence.Claim(raw)
        c.verdict = "CONFIRMED"
        c.reason = raw["why"]
        c.evidence["reviewer"] = "static analysis"
        c.evidence["mechanical"] = True
        static_claims.append(c)
    if static_claims:
        print("\n== mechanical findings (no model consulted) ==")
        for c in static_claims:
            print("  %s:%s  %s" % (c.file, c.lines, c.text))

    # Stage 2: fan out reviews across the network, one file per node at a time.
    targets = pick_solvers(cfg, state, args.floor, count=args.n,
                           family=cfg.data.get("team", {}).get("restrict_to_family"))
    if not targets:
        print("no eligible reviewers at floor %d" % args.floor, file=sys.stderr)
        return 1
    print("\n== review ==")
    print("  reviewers: %s" % ", ".join("%s/%s" % (n.name, m) for n, m in targets))

    reports: List[Dict[str, Any]] = [None] * len(paths)  # type: ignore[list-item]
    lock = threading.Lock()
    queue = list(enumerate(paths))

    def worker(node: swarm.Node, model: str) -> None:
        while True:
            with lock:
                if not queue:
                    return
                i, path = queue.pop(0)
            reports[i] = audit_file(node, model, path, root, cfg, state)

    threads = [threading.Thread(target=worker, args=(n, m), daemon=True)
               for n, m in targets]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    index = evidence.SymbolIndex(root)
    claims: List[evidence.Claim] = []
    for rep in reports:
        if not rep:
            continue
        if rep.get("error"):
            print("  %-22s error: %s" % (rep["file"], rep["error"]))
            continue
        found = evidence.parse_claims(rep["raw"])
        for c in found:
            if not c.file:
                c.file = rep["file"]
            c.evidence["reviewer"] = rep["target"]
            claims.append(c)
        print("  %-22s %-18s %5.1fs  %d claim(s)"
              % (rep["file"], rep["target"], rep["seconds"], len(found)))

    if not claims and not static_claims:
        print("\nno claims raised. %d file(s) parse clean." % len(paths))
        return 0

    # Stage 3: resolve against disk. Some claims die here for free.
    print("\n== evidence ==")
    for c in claims:
        evidence.resolve(c, index, root)
    mechanical = [c for c in claims if c.verdict == "REFUTED"]
    for c in mechanical:
        print("  refuted (no model needed): %s" % c.reason)
    live = [c for c in claims if c.verdict == "NEEDS_JUDGEMENT"]
    print("  %d claim(s) need judgement, %d dismissed mechanically"
          % (len(live), len(mechanical)))
    # Facts join the report but not the argument. Sending a decided claim to a
    # model can only turn a right answer into a wrong one, which is exactly
    # what happened when a reviewer's rebuttal called crashing eviction code
    # "functionally correct".
    claims.extend(static_claims)

    # Stage 4: adjudicate with evidence, on the model the evals actually
    # vouch for -- not on whichever node happens to be free.
    judge_floor = int(cfg.data.get("team", {}).get("judge_floor", 4))
    # Writing and judging are not the same job and no longer share a model.
    # Measured on a probe with two real crashes and one tempting non-bug: the
    # 26b confirmed the ZeroDivisionError and held that verdict when asked to
    # argue against itself, while the 12b ruled it unproven -- claiming the
    # initial values of hits and total were not shown, when they are set in
    # __init__ in the file it was given -- and dismissed genuinely crashing
    # eviction code as "functionally correct". A wrong verdict is the output
    # here, with nothing downstream to catch it, so this is worth 3m42s over
    # 23.6s.
    judge = judging_model(cfg, state, judge_floor)
    if judge is None:
        print("no judge at floor %d; reporting unadjudicated" % judge_floor)
        live_out = live
    else:
        jnode, jmodel = judge
        print("\n== adjudication (%s/%s) ==" % (jnode.name, jmodel))
        for c in live:
            v, why, secs = adjudicate(c, jnode, jmodel, cfg, state)
            c.verdict, c.reason = v, why
            c.evidence["judge"] = "%s/%s" % (jnode.name, jmodel)
            print("  %-9s %5.1fs  %s" % (v, secs, c.text[:70]))
        live_out = live

    # Stage 5: a confirmed bug is the expensive kind to be wrong about, so
    # pass it to a second judge on a different box before reporting it.
    confirmed = [c for c in live_out if c.verdict == "CONFIRMED"]
    if confirmed and judge is not None and not args.no_second:
        others = [t for t in pick_solvers(cfg, state, max(2, judge_floor - 1), count=4,
                                          family=cfg.data.get("team", {}).get(
                                              "restrict_to_family"))
                  if t[0].name != judge[0].name]
        if others:
            snode, smodel, rebut = others[0][0], others[0][1], False
            print("\n== confirmation (%s/%s) ==" % (snode.name, smodel))
        else:
            # No second box is capable enough to be worth asking -- the evals
            # show the smaller models raise false alarms, and a false alarm
            # here would undo the work of the whole pipeline. Re-ask the judge
            # we trust, from the opposite side.
            snode, smodel, rebut = judge[0], judge[1], True
            print("\n== confirmation (%s/%s, arguing the other side) =="
                  % (snode.name, smodel))
        for c in confirmed:
            v, why, secs = adjudicate(c, snode, smodel, cfg, state, rebut=rebut)
            c.evidence["second"] = {"judge": "%s/%s" % (snode.name, smodel),
                                    "rebuttal": rebut, "verdict": v, "reason": why}
            agree = "holds up" if v == "CONFIRMED" else "disputed (%s)" % v
            print("  %-16s %5.1fs  %s" % (agree, secs, c.text[:60]))
            if v != "CONFIRMED":
                c.verdict = "DISPUTED"
                c.reason += "  [second pass: %s -- %s]" % (v, why)

    # Report.
    elapsed = time.monotonic() - started
    print("\n" + "=" * 66)
    order = {"CONFIRMED": 0, "DISPUTED": 1, "UNPROVEN": 2, "REFUTED": 3}
    final = sorted(claims, key=lambda c: order.get(c.verdict, 9))
    for c in final:
        if c.verdict == "REFUTED" and not args.verbose:
            continue
        print("\n[%s] %s" % (c.verdict, c.text))
        print("  %s:%s" % (c.file, c.lines))
        if c.reason:
            print("  %s" % c.reason)

    n_conf = sum(1 for c in claims if c.verdict == "CONFIRMED")
    n_disp = sum(1 for c in claims if c.verdict == "DISPUTED")
    n_ref = sum(1 for c in claims if c.verdict == "REFUTED")
    n_unp = sum(1 for c in claims if c.verdict == "UNPROVEN")
    print("\n%d confirmed, %d disputed, %d unproven, %d refuted  (%s)"
          % (n_conf, n_disp, n_unp, n_ref, swarm.human(elapsed)))

    if args.json:
        os.makedirs(BUNDLE_DIR, exist_ok=True)
        out = os.path.join(BUNDLE_DIR, "audit-%d.json" % int(time.time()))
        with open(out, "w", encoding="utf-8") as fh:
            json.dump({"files": [os.path.relpath(p, root) for p in paths],
                       "parse_failures": broken,
                       "claims": [c.to_dict() for c in claims],
                       "seconds": round(elapsed, 1)}, fh, indent=2)
        print("bundle: %s" % out)
    return 0


PLAN_RETRIES = 3

# How long an initial attempt is given to finish on its own before this
# project starts looking for other capacity to race it against. Every
# existing race (a restart, a timed-out node) only ever checks for idle
# nodes *after* `_write_component` has already given up entirely, which
# can be several minutes deep into `repair` attempts on a single box.
# Measured live: several components queued onto one busy node in turn
# while two other boxes sat completely idle for the whole run, because
# nothing ever asked whether the fleet had spare capacity while the
# first attempt was merely slow rather than finished. Three minutes is
# comfortably longer than the median first-attempt time recorded across
# this project's own measurements (under two minutes on every box that
# is not actively swapping models), so this essentially never fires on
# an attempt that was always going to finish promptly.
HEDGE_AFTER_SECONDS = 180.0

# The idle-capacity check used to run exactly once, at the HEDGE_AFTER_
# SECONDS mark: if nothing was idle *at that instant*, the wait fell back
# to an untimed `queue.Queue.get()` for the rest of this component's run
# and never looked again -- so a box that freed up ten seconds later
# (another component finishing, a short unrelated request completing) was
# never noticed, and an operator watching two genuinely-stuck-with-nothing-
# idle-yet components saw no output at all past 180s, indistinguishable
# from the mechanism having silently broken. Re-checking every 60s, and
# saying so the first time nothing is idle, turns both of those into
# something the operator can actually read off the log rather than guess
# at.
HEDGE_POLL_SECONDS = 60.0


_DEF_RE = re.compile(
    r"(?:function|def|class)\s+([A-Za-z_][A-Za-z0-9_]*)|"
    r"(?:const|let|var)\s+([A-Za-z_][A-Za-z0-9_]*)\s*=")


def collapse_repeat_lines(text: str) -> str:
    """One line plus a count, where the same line was printed over and over.

    A check that reports one failure per input fills the next planner's window
    with forty copies of one sentence, and the single different line at the
    end is what gets cut. The count keeps the fact; the copies do not.
    """
    def shape(line: str) -> str:
        # generateLevel(0) and generateLevel(39) are one failure, not forty.
        return re.sub(r"\d+", "#", line)

    out: List[str] = []
    lines = text.splitlines()
    i = 0
    while i < len(lines):
        j = i + 1
        while j < len(lines) and shape(lines[j]) == shape(lines[i]):
            j += 1
        if j - i > 1:
            out.append("%s  (same failure on %d inputs)" % (lines[i], j - i))
        else:
            out.append(lines[i])
        i = j
    return "\n".join(out)


def check_verdict(text: str) -> str:
    """The check's own failures, without whatever the program printed.

    A generator that logged its whole level on every seed made the next plan
    a pile of maps, and the real failure was the line that got cut. The
    verdict is the lines the check itself prints. If it printed none, the
    raw text is all there is to go on.
    """
    lines = [ln for ln in text.splitlines()
             if "CHECK FAILED" in ln or "CHECK PASSED" in ln]
    return collapse_repeat_lines("\n".join(lines) if lines else text)


def files_named_by(root: str, text: str, skip: Optional[Sequence[str]] = None
                   ) -> List[str]:
    """Project files a check failure is about.

    A filename in the output counts. So does a function or class the output
    names, when exactly one project file defines it: `generateLevel(...)`
    failed is `level.js`'s failure even though the message never says
    `level.js`. A name defined in several files is left unmatched, because
    guessing which one would rewrite the wrong file.
    """
    if not text:
        return []
    skipped = set(skip or ())
    try:
        present = sorted(os.listdir(root))
    except OSError:
        return []
    # A call, not a bare word. "each step lands" is English; `step(` is
    # physics.js. Matching every word blamed every file that had a function
    # with an ordinary name.
    called = set(re.findall(r"\b([A-Za-z_][A-Za-z0-9_]{2,})\s*\(", text))
    defined: Dict[str, List[str]] = {}
    assigned: Dict[str, List[str]] = {}
    named: List[str] = []
    for name in present:
        ext = os.path.splitext(name)[1].lower()
        full = os.path.join(root, name)
        if (ext not in intent.WRITABLE or not os.path.isfile(full)
                or intent.is_race_scratch_name(name) or name in skipped):
            continue
        if name in text:
            named.append(name)
        try:
            with open(full, encoding="utf-8", errors="replace") as fh:
                body = fh.read(200_000)
        except OSError:
            continue
        for match in _DEF_RE.finditer(body):
            symbol = match.group(1) or match.group(2)
            if not symbol or symbol not in called:
                continue
            # `function generateLevel` owns the name. `const generateLevel =
            # levelMod.generateLevel` in the check is an alias, and treating
            # it as a second owner made the failure match nothing.
            (defined if match.group(1) else assigned).setdefault(symbol, []).append(name)
    for symbol in set(defined) | set(assigned):
        files = defined.get(symbol) or assigned.get(symbol) or []
        owners = list(dict.fromkeys(files))
        if len(owners) == 1 and owners[0] not in named:
            named.append(owners[0])
    return named


def _swarm_check(root: str) -> str:
    try:
        with open(os.path.join(root, ".swarm-check"),
                  encoding="utf-8", errors="replace") as fh:
            return fh.read().strip()
    except OSError:
        return ""


def files_loaded_by(root: str, command: str) -> List[str]:
    """Project files a check script loads, not the script itself.

    A check that never returns names no file. The hang is in something that
    script loaded. A page the check never executes is not a candidate.
    """
    if not root or not command:
        return []
    root_real = os.path.realpath(root)
    scripts: List[str] = []
    for token in command.split():
        token = token.strip("'\"")
        if not token or token.startswith("-"):
            continue
        full = token if os.path.isabs(token) else os.path.join(root, token)
        if os.path.isfile(full):
            scripts.append(os.path.realpath(full))
    loaded: List[str] = []
    rel_re = re.compile(
        r"""(?:require\s*\(\s*|import\s*\(\s*|from\s+)['"](\.[^'"]+)['"]""")
    py_re = re.compile(r"^\s*(?:import|from)\s+([A-Za-z_][\w.]*)", re.M)
    for script in scripts:
        try:
            with open(script, encoding="utf-8", errors="replace") as fh:
                body = fh.read(200_000)
        except OSError:
            continue
        refs = rel_re.findall(body)
        for mod in py_re.findall(body):
            refs.append("./" + mod.split(".")[0])
        script_dir = os.path.dirname(script)
        for ref in refs:
            name = ref[2:] if ref.startswith("./") else ref
            stems = [name]
            if not os.path.splitext(name)[1]:
                stems += [name + ext for ext in (".js", ".mjs", ".cjs", ".py")]
            for stem in stems:
                full = os.path.realpath(os.path.join(script_dir, stem))
                if full == script or not full.startswith(root_real + os.sep):
                    continue
                if os.path.isfile(full):
                    rel = os.path.relpath(full, root_real)
                    if rel not in loaded:
                        loaded.append(rel)
                    break
    return loaded


def calls_from_check(root: str, text: str, command: str = "") -> str:
    """The calls the check makes to a function the failure names.

    A thrown `reading 'NaN'` does not say the check called `generateLevel(seed)`
    while the file requires `width` and `height`. The call is the contract.
    """
    command = command or _swarm_check(root)
    called = set(re.findall(r"\b([A-Za-z_][A-Za-z0-9_]{2,})\s*\(", text or ""))
    if not command or not called:
        return ""
    lines: List[str] = []
    for token in command.split():
        token = token.strip("'\"")
        if not token or token.startswith("-"):
            continue
        full = token if os.path.isabs(token) else os.path.join(root, token)
        if not os.path.isfile(full):
            continue
        try:
            with open(full, encoding="utf-8", errors="replace") as fh:
                body = fh.read(200_000)
        except OSError:
            continue
        for raw in body.splitlines():
            stripped = raw.strip()
            if not stripped or stripped.startswith(("//", "*", "/*")):
                continue
            for name in called:
                for match in re.finditer(
                        r"\b%s\s*\(([^)]*)\)" % re.escape(name), stripped):
                    if '"' in match.group(1) or "'" in match.group(1):
                        continue
                    expr = match.group(0)
                    if expr not in lines:
                        lines.append(expr)
    if not lines:
        return ""
    return ("The check calls:\n" + "\n".join(lines[:12]) +
            "\nA parameter with no default is required. A call that omits it "
            "leaves it undefined.")


_CALL_SKIP = {
    "fail", "if", "for", "while", "switch", "catch", "function", "return",
    "Math", "Object", "JSON", "Array", "console", "require", "Set", "Map",
    "parseInt", "parseFloat", "isFinite", "isNaN", "Number", "String",
    "Boolean", "Error", "TypeError", "RegExp",
}


def _check_script_paths(root: str, command: str) -> List[str]:
    paths: List[str] = []
    for token in (command or "").split():
        token = token.strip("'\"")
        if not token or token.startswith("-"):
            continue
        full = token if os.path.isabs(token) else os.path.join(root, token)
        if os.path.isfile(full):
            paths.append(full)
    return paths


def _code_only(line: str) -> str:
    """Calls inside a quoted message are English, not calls."""
    return re.sub(r"""(['"])(?:\\.|(?!\1).)*\1""", "''", line)


def _call_names(line: str) -> List[str]:
    return [n for n in re.findall(r"\b([A-Za-z_][A-Za-z0-9_]*)\s*\(", _code_only(line))
            if n not in _CALL_SKIP]


def _function_body(lines: List[str], name: str) -> str:
    """The body of `function name` in this check script, signature excluded."""
    start = None
    for i, raw in enumerate(lines):
        if re.match(r"\s*function\s+%s\s*\(" % re.escape(name), raw):
            start = i
            break
    if start is None:
        return ""
    depth = 0
    seen = False
    body: List[str] = []
    for raw in lines[start:]:
        if seen:
            body.append(raw)
        depth += raw.count("{") - raw.count("}")
        if raw.count("{") or raw.count("}"):
            seen = True
        if seen and depth <= 0:
            break
    return "\n".join(body)


def _stack_text(root: str, text: str, skip: Sequence[str]) -> str:
    """Stack frames that name a project file. The check script's own frame is not one."""
    try:
        present = os.listdir(root)
    except OSError:
        return ""
    skipped = set(skip)
    kept: List[str] = []
    for raw in (text or "").splitlines():
        if "node:internal" in raw or "node_modules" in raw:
            continue
        for name in present:
            if name in skipped:
                continue
            if re.search(r"\b%s:\d+" % re.escape(name), raw):
                kept.append(raw.strip())
                break
    return "\n".join(kept)


def _assigned_calls(lines: List[str]) -> Dict[str, List[str]]:
    """A variable's assignment, when the right-hand side calls something."""
    found: Dict[str, List[str]] = {}
    for raw in lines:
        match = re.search(
            r"\b(?:const|let|var)\s+([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([^;]+)", raw)
        if match:
            calls = _call_names(match.group(2))
            if calls:
                found[match.group(1)] = calls
            continue
        # `lv = generateLevel(seed)` has no const. `==` is not an assignment.
        bare = re.search(
            r"(?<![!=<>])\b([A-Za-z_][A-Za-z0-9_]*)\s*=(?!=)\s*([^;]+)", raw)
        if not bare or bare.group(1) in found:
            continue
        calls = _call_names(bare.group(2))
        if calls:
            found[bare.group(1)] = calls
    return found


def _function_span(lines: List[str], name: str) -> Optional[Tuple[int, int]]:
    """Inclusive line indexes of `function name`, or None."""
    start = None
    for i, raw in enumerate(lines):
        if re.match(r"\s*function\s+%s\s*\(" % re.escape(name), raw):
            start = i
            break
    if start is None:
        return None
    depth = 0
    seen = False
    for j in range(start, len(lines)):
        depth += lines[j].count("{") - lines[j].count("}")
        if lines[j].count("{") or lines[j].count("}"):
            seen = True
        if seen and depth <= 0:
            return start, j
    return None


def _enclosing_function(lines: List[str], idx: int) -> str:
    """The function whose body contains this line, or "" at the top level."""
    found = ""
    for raw in lines:
        match = re.match(r"\s*function\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(", raw)
        if not match:
            continue
        span = _function_span(lines, match.group(1))
        if span and span[0] < idx <= span[1]:
            found = match.group(1)
    return found


def _fail_arg(raw: str) -> Optional[str]:
    """The argument of a fail() call. The function that defines fail is not one."""
    if re.match(r"\s*function\s+fail\s*\(", raw):
        return None
    stripped = raw.strip()
    if not stripped or stripped.startswith(("//", "*", "/*")):
        return None
    # The call is not always the end of the line: `fail(...); return null`.
    stmt = raw.split(";", 1)[0]
    match = re.search(r"\bfail\s*\((.*)\)\s*$", stmt)
    return match.group(1) if match else None


def _fail_literals(arg: str) -> List[str]:
    parts = [m.group(2) for m in re.finditer(
        r"""(['"])((?:\\.|(?!\1).)*)\1""", arg)]
    return [p for p in parts if len(p.strip()) >= 4]


def _arg_idents(line: str, name: str) -> List[str]:
    found: List[str] = []
    code = _code_only(line)
    for match in re.finditer(r"\b%s\s*\(([^)]*)\)" % re.escape(name), code):
        found.extend(re.findall(r"\b([A-Za-z_][A-Za-z0-9_]*)\b", match.group(1)))
    return found


def _fail_site(lines: List[str], idx: int, assigned: Dict[str, List[str]]
               ) -> Optional[Tuple[List[str], List[str], str]]:
    """Calls around one fail() line, plus what its callers passed in.

    A fail() inside `assertSolid(lv)` never mentions `generateLevel`. The
    caller `assertSolid(generateLevel(seed))` does. Callers that disagree
    about which function produced the argument are ignored: blaming both
    would rewrite a file the failure is not about.
    """
    stmt = lines[idx].split(";", 1)[0]
    cond = re.sub(r"\bfail\s*\(.*\)\s*$", "", stmt).strip()
    cond = re.sub(r"^if\s*\(", "", cond).strip()
    cond = re.sub(r"\)\s*$", "", cond).strip()
    site: List[str] = []
    for earlier in range(idx, max(-1, idx - 80), -1):
        if earlier != idx and not lines[earlier].strip():
            break
        site.append(lines[earlier])
    consumers: List[str] = []
    producers: List[str] = []
    expanded: List[str] = list(site)
    for line in site:
        for name in _call_names(line):
            body = _function_body(lines, name)
            if body:
                expanded.append(body)
                for arg in _arg_idents(line, name):
                    producers.extend(assigned.get(arg, []))
            else:
                consumers.append(name)
    for line in expanded:
        for name in _call_names(line):
            if _function_body(lines, name):
                continue
            if name not in consumers:
                consumers.append(name)
            for arg in _arg_idents(line, name):
                producers.extend(
                    c for c in assigned.get(arg, [])
                    if not _function_body(lines, c))
    enclosing = _enclosing_function(lines, idx)
    span = _function_span(lines, enclosing) if enclosing else None
    agreed: Optional[List[str]] = None
    saw_caller = False
    if enclosing and span:
        for i, line in enumerate(lines):
            if span[0] <= i <= span[1]:
                continue
            if enclosing not in _call_names(line):
                continue
            here: List[str] = []
            code = _code_only(line)
            for match in re.finditer(
                    r"\b%s\s*\(([^)]*)\)" % re.escape(enclosing), code):
                here.extend(c for c in _call_names(match.group(1))
                            if not _function_body(lines, c))
                for ident in re.findall(r"\b([A-Za-z_][A-Za-z0-9_]*)\b", match.group(1)):
                    here.extend(c for c in assigned.get(ident, [])
                                if not _function_body(lines, c))
            here = list(dict.fromkeys(here))
            if not here:
                continue
            saw_caller = True
            if agreed is None:
                agreed = here
            elif set(agreed) != set(here):
                agreed = []
                break
    if saw_caller and agreed:
        producers.extend(agreed)
    return consumers, producers, cond


def fail_site_files(root: str, text: str, command: str = ""
                    ) -> Tuple[List[str], str]:
    """The project file the failing line is actually about.

    The call on the line is not always that file. `holding jump did not lift
    the player` is reached through `step`, and `step` is only reading the
    level `generateLevel` produced. The producer is the file to repair, unless
    the failure names the function that reads it. A stack frame still wins
    over this, and a check that never returns still falls through to the
    files it loads.
    """
    verdict = check_verdict(text)
    if not verdict.strip():
        return [], ""
    command = command or _swarm_check(root)
    scripts = _check_script_paths(root, command)
    best: Optional[Tuple[int, List[str], List[str], str]] = None
    for script in scripts:
        try:
            with open(script, encoding="utf-8", errors="replace") as fh:
                lines = fh.read(200_000).splitlines()
        except OSError:
            continue
        assigned = _assigned_calls(lines)
        bare: List[int] = []
        for idx, raw in enumerate(lines):
            arg = _fail_arg(raw)
            if arg is None:
                continue
            parts = _fail_literals(arg)
            if sum(len(p) for p in parts) < 8:
                bare.append(idx)
                continue
            if not all(p in verdict for p in parts):
                continue
            score = sum(len(p) for p in parts)
            site_hit = _fail_site(lines, idx, assigned)
            if site_hit and (best is None or score > best[0]):
                best = (score,) + site_hit
        # No quoted text matched. One bare fail() is that line. Two bare
        # fail() calls could be either line, and picking one would rewrite
        # the wrong file.
        if best is None and len(bare) == 1:
            site_hit = _fail_site(lines, bare[0], assigned)
            if site_hit:
                best = (1,) + site_hit
    if best is None:
        return [], ""
    skip = [os.path.basename(p) for p in scripts]
    consumers = list(dict.fromkeys(best[1]))
    producers = list(dict.fromkeys(c for c in best[2] if c not in consumers))
    cond = best[3]

    def owned(names: List[str]) -> List[str]:
        if not names:
            return []
        return files_named_by(
            root, "\n".join("%s()" % n for n in names), skip=skip)

    cons_files = owned(consumers)
    prod_files = [f for f in owned(producers) if f not in cons_files]
    names_reader = any(re.search(r"\b%s\b" % re.escape(n), verdict) for n in consumers)
    def through(names: List[str]) -> str:
        owned_names = [n for n in names if owned([n])]
        text = ", ".join("%s()" % n for n in owned_names[:6])
        if cond and text:
            return "fails when %s. through %s" % (cond, text)
        if cond:
            return "fails when %s" % cond
        return text

    if prod_files and not names_reader:
        readers = [n for n in consumers if owned([n])]
        shown = ("the value comes from " + ", ".join("%s()" % n for n in producers[:6])
                 + ". " + ", ".join("%s()" % n for n in readers[:6]) + " only reads it")
        if cond:
            shown += ". fails when " + cond
        return prod_files, shown
    found = cons_files or owned(producers)
    shown = through([n for n in consumers if owned([n])] or producers)
    return found, shown


def blame_for_check(root: str, text: str, command: str = ""
                    ) -> Tuple[List[str], str]:
    """Files a failed check is about, and how that was decided.

    `named` means the output or a stack frame says so. `called` means the
    output names neither a file nor a call, and the check's own `fail` line
    does. `loaded` is only a check that never returns: the hang is inside
    something that script loaded, and no `fail` line matches.
    """
    command = command or _swarm_check(root)
    skip = [os.path.basename(p) for p in _check_script_paths(root, command)]
    named = files_named_by(root, check_verdict(text), skip=skip)
    if named:
        return named, "named"
    stack = _stack_text(root, text, skip)
    named = files_named_by(root, stack, skip=skip) if stack else []
    if named:
        return named, "named"
    called, shown = fail_site_files(root, text, command)
    if called:
        return called, "produced" if shown.startswith("the value comes from") else "called"
    if "did not return" in (text or "") or "CHECK FAILED" not in (text or ""):
        loaded = [os.path.basename(p) for p in files_loaded_by(root, command)]
        if loaded:
            return loaded, "loaded"
    return [], "none"


def failures_for_file(root: str, text: str, command: str, path: str) -> str:
    """The check lines that blame this file, and no other file's lines.

    A package check fails for every file at once. Handing that whole output
    to the writer of one file makes it rewrite a good file to chase a
    failure that lives in another one. A line is kept only when blaming
    that line alone names this file.
    """
    own = os.path.basename(path)
    kept: List[str] = []
    for raw in (text or "").splitlines():
        if "CHECK FAILED" not in raw:
            continue
        blamed, _how = blame_for_check(root, raw, command)
        if own in blamed and raw.strip() not in kept:
            kept.append(raw.strip())
    return "\n".join(kept)


def scoped_check_command(command: str, path: str) -> str:
    """A check that fails only when `path` is still to blame.

    Exit 0 when the real check passes, and also when it fails entirely in
    some other file. The writer then stops, and the integration repair can
    name the file that is actually still wrong.
    """
    code = (
        "import os,subprocess,sys,team\n"
        "cmd,path=sys.argv[1],sys.argv[2]\n"
        "proc=subprocess.run(cmd,shell=True,stdout=subprocess.PIPE,"
        "stderr=subprocess.STDOUT,text=True)\n"
        "out=proc.stdout or ''\n"
        "if proc.returncode==0:\n"
        "    sys.exit(0)\n"
        "kept=team.failures_for_file(os.getcwd(),out,cmd,path)\n"
        "if not kept:\n"
        "    sys.exit(0)\n"
        "sys.stderr.write(kept+'\\n')\n"
        "sys.exit(1)\n"
    )
    here = os.path.dirname(os.path.abspath(__file__))
    return ("PYTHONPATH=%s${PYTHONPATH:+:$PYTHONPATH} python3 -c %s %s %s"
            % (shlex.quote(here), shlex.quote(code), shlex.quote(command),
               shlex.quote(path)))


def check_focus(root: str, command: str = "") -> str:
    """What `.ralph/last-check.txt` says is still wrong, or "" if there is none.

    The Ralph loop repeats one request until a check passes, so the request
    itself never changes and never names the failure. Without this the next
    plan is another full build, and every file that already exists gets
    rewritten. The check output is the state; it lives in the project, and
    the planner is told to touch only the existing files that output names.
    """
    path = os.path.join(root, ".ralph", "last-check.txt")
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            text = fh.read().strip()
    except OSError:
        return ""
    if not text:
        return ""
    named, how = blame_for_check(root, text, command)
    if how == "loaded":
        scope = ("no file is named in the output; the check loads %s, and a "
                 "check that never returns is inside one of those"
                 % ", ".join(named))
    elif named:
        scope = ", ".join(named)
    else:
        scope = "no existing file is named, so the plan is not narrowed"
    verdict = check_verdict(text)
    calls = calls_from_check(root, verdict, command)
    _files, shown = fail_site_files(root, text, command) if how in ("called", "produced") else ([], "")
    if shown and how == "produced":
        calls = (calls + "\n" if calls else "") + (
            "The failure measures an input. " + shown
            + ". Repair the file that produces the input.")
    elif shown:
        calls = (calls + "\n" if calls else "") + (
            "The check reaches this failure through: " + shown)
    stack = _stack_text(root, text, [
        os.path.basename(p) for p in _check_script_paths(root, command or _swarm_check(root))])
    body = verdict[-4000:]
    if stack:
        body += "\n" + stack
    if calls:
        body += "\n\n" + calls
    return ("The check for this project last failed. This is a fix, not a new "
            "build. Plan a component only for an existing file the output "
            "below names (%s). Leave every other existing file out of the "
            "plan; it already stands. The behavior the output describes is "
            "wrong; do not keep it just because the current file does it. "
            "A signature or comment that disagrees with the call the check "
            "makes is part of the failure.\n\n%s"
            % (scope, body))


def _opening_failures(part: str) -> List[str]:
    """The check lines that opened a Ralph round, before the plan ran.

    Lines written later in the same round are the repair's own integration
    check. Mixing them in makes a round look like a different failure from
    the one the next round actually inherited.
    """
    lines: List[str] = []
    for raw in part.splitlines():
        stripped = raw.strip()
        if (stripped.startswith("planning on") or stripped.startswith("read as:")
                or "component(s) passed" in stripped):
            break
        if "CHECK FAILED" not in raw:
            continue
        line = raw.split("/Users/")[0].split("SyntaxWarning")[0]
        line = re.sub(r"\s*\(same failure on \d+ inputs\)", "", line)
        line = re.sub(r"-?\d+", "#", line)
        line = re.sub(r"\s+", " ", line).strip()
        if line.startswith("CHECK FAILED:") and line not in lines:
            lines.append(line)
    return lines


def ralph_round_kinds(root: str) -> List[List[str]]:
    """One list of normalized failure lines per Ralph round in `ralph.log`."""
    try:
        with open(os.path.join(root, "ralph.log"), encoding="utf-8",
                  errors="replace") as fh:
            log = fh.read()
    except OSError:
        return []
    rounds = []
    for part in re.split(r"(?m)^== ralph round \d+ ==\s*", log)[1:]:
        lines = _opening_failures(part)
        if lines:
            rounds.append(lines)
    return rounds


def failure_build_note(root: str, path: str, failed_text: str,
                       command: str) -> str:
    """What a rewrite of this file has to be told about the current check.

    The quoted condition and a saved approach are only useful if the write
    that sees the failure also sees them. The integration repair used to
    build its own prompt and include neither, so the one rewrite that ran
    after the real check had less context than the write that had just
    failed it.
    """
    if not (failed_text or "").strip():
        return ""
    parts = []
    fact_files, fact = fail_site_files(root, failed_text, command)
    if fact and os.path.basename(path) in fact_files:
        parts.append("The check decides the failure like this, quoted from "
                     "the check:\n" + fact)
    approach = approach_for(root, path)
    if approach:
        parts.append("The same failure class survived the last repair. Build "
                     "this file this way. Every failure line still has to be "
                     "met:\n" + approach)
    parts.append("Every CHECK FAILED line has to be true at the same time. "
                 "Clearing one line by bringing another back is a failed "
                 "repair.")
    return "\n\n".join(parts)


def approach_for(root: str, path: str) -> str:
    """The different build proposed for this file, or ""."""
    try:
        with open(os.path.join(root, ".ralph", "approach.txt"),
                  encoding="utf-8", errors="replace") as fh:
            text = fh.read()
    except OSError:
        return ""
    own = os.path.basename(path)
    blocks = re.split(r"(?m)^FILE:\s*", text)
    for block in blocks[1:]:
        name, _, body = block.partition("\n")
        if os.path.basename(name.strip()) == own and body.strip():
            return body.strip()
    return ""


def recurring_failures(rounds: List[List[str]]) -> List[tuple]:
    """Failure lines of the latest round that also appeared in any earlier one.

    Each item is `(line, earlier_round_numbers)`. A line that skipped the
    round immediately before still counts: the class came back.
    """
    if len(rounds) < 2:
        return []
    found = []
    for line in rounds[-1]:
        earlier = [i + 1 for i, kinds in enumerate(rounds[:-1]) if line in kinds]
        if earlier:
            found.append((line, earlier))
    return found


STORED_DONE = "stored-outputs-pass"


def _expires_epoch(value: object) -> Optional[float]:
    """`/api/ps` expires_at as a unix time, or None when it is not a time."""
    if not isinstance(value, str) or not value.strip():
        return None
    text = value.strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    match = re.match(r"^(.*\.\d{6})\d+(.*)$", text)
    if match:
        text = match.group(1) + match.group(2)
    try:
        return datetime.datetime.fromisoformat(text).timestamp()
    except ValueError:
        return None


# A box whose /api/chat failed. /api/ps keeps answering for a pinned model
# (expires_at in 2319) while chat hangs, so the poll cannot see this and the
# next call would wait it out again.
_CHAT_DOWN: Set[str] = set()


def _box_availability(state: swarm.State, node: swarm.Node) -> Optional[str]:
    """Why this box should not be asked, or None when it is free.

    One short `/api/ps`, after the local lease check. A model whose
    expires_at sits on the current clock is generating. A pinned idle model
    expires centuries out, and a chat that already failed is skipped without
    another poll.
    """
    if node.name in _CHAT_DOWN:
        return "chat failed"
    busy, _queue_s = _node_load(state, node)
    if busy:
        return "mid-flight"
    try:
        resp = swarm._request(node.url + "/api/ps", None, 2.0)
        payload = json.loads(resp.read().decode("utf-8"))
    except swarm.OllamaError as exc:
        return "unreachable: %s" % exc
    except json.JSONDecodeError:
        return "unreachable: bad /api/ps"
    now_s = time.time()
    for entry in payload.get("models") or []:
        exp = _expires_epoch(entry.get("expires_at"))
        if exp is not None and abs(exp - now_s) <= 60:
            return "mid-flight"
    return None


def _small_reply(cfg: swarm.Config, state: swarm.State, prompt: str,
                 answer_tokens: int = 400) -> str:
    """One classification from the smallest models, never the writer.

    The triage call is the pattern: a fixed reply shape, temperature 0,
    reasoning off. The boxes are polled, not called together. The first
    one that is up and not already generating gets the single request, and
    that request is given one hour. A chat that does not answer is not polled
    again this run. A lease is held while the request is out so the next
    caller sees it in flight. The ceiling stays on the small tier so this
    does not take the machine that will write the outputs.
    """
    restrict = cfg.data.get("team", {}).get("restrict_to_family")
    target = pick_solvers(cfg, state, 2, count=3, max_over=0, family=restrict)
    if not target:
        return ""
    for node, model in target:
        reason = _box_availability(state, node)
        if reason:
            sys.stderr.write("  shape call skipping %s: %s\n" % (node.name, reason))
            continue
        lease = state.acquire_lease(node.name, model, 3600)
        try:
            reply = swarm.chat_complete(
                node, model, [{"role": "user", "content": prompt}],
                num_ctx=swarm.pick_num_ctx(
                    cfg, node, model, swarm.est_tokens(prompt),
                    answer_tokens, reasoning=False),
                answer_tokens=answer_tokens, headroom=1.6, think=False,
                temperature=0.0, timeout=3600)
        except swarm.OllamaError as exc:
            _CHAT_DOWN.add(node.name)
            sys.stderr.write("  shape call failed on %s: %s\n" % (node.name, exc))
            continue
        finally:
            state.release_lease(lease)
        text = reply.get("text") or ""
        if not text:
            sys.stderr.write("  shape call on %s returned nothing\n" % node.name)
            continue
        state.record_perf(node.name, model, reply["sample"])
        state.mark_resident(node.name, model)
        sys.stderr.write("  shape call answered by %s\n" % node.name)
        return text
    return ""


# A starting ceiling for one value, several times above a typical one (a
# 20x60 level is about a thousand tokens). It exists to end a reply that loops
# inside its own answer, which with no ceiling runs until the window fills
# (measured: over five minutes). A reply that is cut off doubles the ceiling
# for the next try until it reaches what the pinned window leaves after the
# prompt, so a genuinely large value is not blocked. The request stays inside
# the pinned window, so the cache is not reloaded.
STORED_VALUE_TOKENS = 4096


def _floor4_exchange(cfg: swarm.Config, state: swarm.State, prompt: str,
                     answer_tokens: int = 1500, temperature: float = 0.1,
                     think: bool = False, sampled: bool = False,
                     meta: Optional[Dict[str, Any]] = None,
                     fit_window: bool = False) -> Tuple[str, str]:
    """The answer, and the reasoning when thinking was on.

    The answer is what gets pasted. The reasoning is returned so the caller
    can keep it. A call with thinking off has no reasoning.
    """
    node, model, held = claim_first_free_role(cfg, state, [4])
    if node is None:
        sys.stderr.write("  no floor-4 model free to store an output\n")
        return "", ""
    headroom = 1.5
    if fit_window:
        # The reply may use whatever the pinned window leaves after the
        # prompt. A grid tokenizes worse than len//4, so the prompt counts
        # double. Going past the window reloads the model.
        window = node.pin_ctx(model) or node.max_ctx(model)
        slack = int(cfg.routing["ctx_slack_tokens"])
        room = window - 2 * swarm.est_tokens(prompt) - slack
        answer_tokens = max(256, min(answer_tokens, room))
        headroom = 1.0
        if meta is not None:
            meta["ceiling"] = answer_tokens
    try:
        with hold_or_wait(state, node, model, held):
            reply = swarm.chat_complete(
                node, model, [{"role": "user", "content": prompt}],
                num_ctx=swarm.pick_num_ctx(
                    cfg, node, model, swarm.est_tokens(prompt), answer_tokens,
                    reasoning=False),
                answer_tokens=answer_tokens, headroom=headroom, think=think,
                temperature=temperature, timeout=600, sampled=sampled)
        state.record_perf(node.name, model, reply["sample"])
        if meta is not None:
            meta["cut"] = (reply.get("raw") or {}).get("done_reason") == "length"
        return reply.get("text") or "", reply.get("thinking") or ""
    except swarm.OllamaError as exc:
        sys.stderr.write("  stored output call failed: %s\n" % exc)
        return "", ""


def _floor4_reply(cfg: swarm.Config, state: swarm.State, prompt: str,
                  answer_tokens: int = 1500, temperature: float = 0.1,
                  think: bool = False) -> str:
    text, _thinking = _floor4_exchange(
        cfg, state, prompt, answer_tokens, temperature, think)
    return text


CHECK_REFERENCE_CHARS = 24000
WRITER_BEGIN = "WRITER-CONTEXT-BEGIN"
WRITER_END = "WRITER-CONTEXT-END"


def _writer_regions(check_text: str) -> str:
    """The parts of a check a check's author marked for the writer.

    Lines holding WRITER-CONTEXT-BEGIN and WRITER-CONTEXT-END (in any comment
    style) bound a region. With no markers the whole check is shown. A check
    holds more than the rules for one value (a simulation, a page, a scoring
    routine), and a writer cannot use those.
    """
    regions: List[str] = []
    current: Optional[List[str]] = None
    for line in check_text.splitlines():
        if WRITER_BEGIN in line:
            current = []
        elif WRITER_END in line:
            if current is not None:
                regions.append("\n".join(current))
            current = None
        elif current is not None:
            current.append(line)
    if current:
        regions.append("\n".join(current))
    if not regions:
        return check_text
    return "\n// ...\n".join(regions)



def _check_reference(check_text: str) -> str:
    """The check itself, shown to the writer as the guidelines.

    A writer told only which line failed learns the rules one rejection at
    a time, and a rule it never trips over (a minimum share, a shape the
    check measures) stays unknown. The check is the spec, so it is shown
    whole. A check too long to fit is cut at the end, and the cut is said.
    """
    text = _writer_regions(check_text or "").strip()
    if not text:
        return ""
    cut = ""
    if len(text) > CHECK_REFERENCE_CHARS:
        text = text[:CHECK_REFERENCE_CHARS]
        cut = "\n(The check continues past this point; the rest is not shown.)"
    return (
        "Here is the whole check that judges the value. Every CHECK FAILED "
        "line comes from it. Read the rules it tests for one value, and "
        "write a value that passes all of them, not only the line that "
        "failed last.\n=== CHECK ===\n%s%s\n=== END CHECK ===\n"
        % (text, cut))


def _check_text(root: str, command: str) -> str:
    parts = []
    for path in _check_script_paths(root, command):
        try:
            with open(path, encoding="utf-8", errors="replace") as fh:
                parts.append(fh.read())
        except OSError:
            continue
    return "\n".join(parts)


def ask_item_count(root: str, command: str, cfg: swarm.Config,
                   state: swarm.State) -> int:
    """How many members the check walks, answered by the small model.

    The check text is whatever the orchestrator supplied. The question asks
    for runs of the collection loop, so a width, a file count, or one array
    is not the answer.
    """
    parts = []
    for path in _check_script_paths(root, command):
        try:
            with open(path, encoding="utf-8", errors="replace") as fh:
                parts.append(fh.read())
        except OSError:
            continue
    check = "\n".join(parts).strip()
    if not check:
        return 0
    reply = _small_reply(cfg, state, intent.ITEMS_PROMPT.format(check=check), 20)
    count = intent.parse_items(reply)
    if count < 2:
        sys.stderr.write("  collection size: unreadable (%s)\n"
                         % (reply or "").strip().splitlines()[:1])
        return 0
    sys.stderr.write("  collection size: %d\n" % count)
    return count


def ask_build_shape(root: str, command: str, request: str, failures: str,
                    cfg: swarm.Config, state: swarm.State, again: bool = False
                    ) -> Tuple[str, str, int]:
    """Ask a floor-4 model whether this is a stored set or a procedure.

    The fast small model called this request a script. The reply is parsed.
    A stored file the check does not load is rejected, because a classifier
    inventing a path is worse than building a script. The count is a second
    reply, from a small model: how many times the check walks the collection.
    """
    loaded = {os.path.basename(p) for p in files_loaded_by(root, command)}
    prompt = intent.SHAPE_PROMPT.format(
        request=request or "(none)",
        files=", ".join(sorted(loaded)) or "NONE")
    if again:
        prompt += ("\n\nThe same failures have already come back across "
                   "rounds of building this as a procedure. Decide again.\n")
    text = _floor4_reply(cfg, state, prompt, 200)
    if not text:
        return "script", "", 0
    shape, filename, _ignored = intent.parse_shape(text)
    if shape != "stored":
        sys.stderr.write("  build shape: script\n")
        return "script", "", 0
    if filename not in loaded and not os.path.isfile(os.path.join(root, filename)):
        sys.stderr.write("  shape named %s, which the check does not load\n"
                         % filename)
        return "script", "", 0
    count = ask_item_count(root, command, cfg, state)
    if count < 2:
        count = _saved_count(root, filename)
    if count < 2:
        sys.stderr.write("  stored shape but the collection size was not a "
                         "single count\n")
        return "script", "", 0
    sys.stderr.write("  build shape: stored %s x %d\n" % (filename, count))
    return "stored", filename, count


def _classify_lines(lines: Sequence[str], cfg: swarm.Config,
                    state: swarm.State) -> Dict[str, str]:
    """item: one output is invalid. set: the relationship between outputs.

    Deciding which failures belong to one stored output is floor-4 work.
    The small models stay on the shape question and the collection size.
    """
    shown: List[str] = []
    for line in lines:
        if line not in shown:
            shown.append(line)
        if len(shown) >= 40:
            break
    if not shown:
        return {}
    prompt = (
        "Each line is a failure from a check that runs one function on many "
        "inputs. For every line reply with LINE and KIND, and nothing else.\n"
        "KIND item: this one output is invalid by itself.\n"
        "KIND set: the outputs may each be valid, and the failure is the "
        "relationship between them, such as order, sameness, or variety.\n\n"
        + "\n".join(shown)
        + "\n\nLINE: <the failure>\nKIND: <item|set>\n")
    text = _floor4_reply(cfg, state, prompt, 800)
    found: Dict[str, str] = {}
    current = None
    for raw in (text or "").splitlines():
        stripped = raw.strip()
        if stripped.lower().startswith("line:"):
            current = stripped.split(":", 1)[1].strip()
        elif stripped.lower().startswith("kind:") and current:
            kind = stripped.split(":", 1)[1].strip().lower()
            found[current] = "set" if "set" in kind else "item"
            current = None
    kinds: Dict[str, str] = {}
    for line in shown:
        kind = "item"
        for key, value in found.items():
            if key == line or (key and (key in line or line in key)):
                kind = value
                break
        kinds[line] = kind
    return kinds


def _failure_lines(output: str) -> List[str]:
    """Every line of a check that already failed.

    The wording is the check's. A line that does not say CHECK FAILED is
    still a failure.
    """
    # The check runs in a scratch copy whose directory name is new every
    # call. Left in, the same crash reads as a different line each time and
    # the model is shown a path it cannot act on.
    text = re.sub(r"(?:/private)?/var/folders/\S*?/proj/", "", output or "")
    lines = [raw.strip() for raw in text.splitlines() if raw.strip()]
    return lines or ["check failed"]


def _code_reply(text: str) -> str:
    blocks = re.findall(r"```[a-zA-Z]*\s*([\s\S]*?)```", text or "")
    if blocks:
        return max(blocks, key=len).strip()
    return (text or "").strip()


def _check_source(root: str, command: str, relpath: str, source: str
                  ) -> Tuple[bool, str]:
    parent = tempfile.mkdtemp(prefix="stored-")
    dest = os.path.join(parent, "proj")
    try:
        shutil.copytree(root, dest, ignore=shutil.ignore_patterns(
            ".git", ".ralph", "ralph.log", "node_modules"))
        target = os.path.join(dest, relpath)
        os.makedirs(os.path.dirname(target) or dest, exist_ok=True)
        with open(target, "w", encoding="utf-8") as fh:
            fh.write(source)
        # The scratch copy is deleted after every run. A check that keeps
        # anything between runs (judge.py's cache) keeps it under the real root.
        os.environ["BLOSSOM_ROOT"] = root
        ok, out = codegen.run_command(command, dest, timeout=120)
        return ok, out
    finally:
        shutil.rmtree(parent, ignore_errors=True)


def _saved_count(root: str, filename: str) -> int:
    """The count already stored for this file, when the counter does not answer."""
    try:
        with open(_stored_path(root), encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, json.JSONDecodeError):
        return 0
    if data.get("file") != filename:
        return 0
    try:
        count = int(data.get("count") or 0)
    except (TypeError, ValueError):
        return 0
    if count >= 2:
        sys.stderr.write("  collection size: using the saved count %d\n" % count)
    return count if count >= 2 else 0


def _stored_path(root: str) -> str:
    return os.path.join(root, ".ralph", "stored.json")


def _keep_thought(root: str, slot: int, stalled: int, thinking: str) -> None:
    """Append one annotator reasoning trace. The value itself is not this file.

    The trace is not fed back into the next ask. It is the reasoning already
    paid for, kept beside the stored values.
    """
    thinking = (thinking or "").strip()
    if not thinking:
        return
    os.makedirs(os.path.join(root, ".ralph"), exist_ok=True)
    record = {"slot": slot, "stalled": stalled, "thinking": thinking}
    with open(os.path.join(root, ".ralph", "thoughts.jsonl"), "a",
              encoding="utf-8") as fh:
        fh.write(json.dumps(record, ensure_ascii=False) + "\n")
    sys.stderr.write("  kept thinking (%d chars)\n" % len(thinking))


def _keep_attempt(root: str, slot: int, stalled: int, why: str,
                  reply: str, lines: Sequence[str], ask: str = "") -> None:
    """Keep a reply the check did not accept, in full, beside the stored values.

    The next ask does not read this file. The log prints it so a miss can be
    read without opening the file.
    """
    reply = reply or ""
    os.makedirs(os.path.join(root, ".ralph"), exist_ok=True)
    record = {"slot": slot, "stalled": stalled, "why": why,
              "check": [line for line in lines if line],
              "reply": reply, "ask": ask}
    with open(os.path.join(root, ".ralph", "attempts.jsonl"), "a",
              encoding="utf-8") as fh:
        fh.write(json.dumps(record, ensure_ascii=False) + "\n")
    shown = "\n".join(record["check"])
    sys.stderr.write("  failed reply (%s):\n%s%s\n" % (
        why, shown + "\n" if shown else "", reply))


def _stored_active(root: str) -> bool:
    """A saved lookup is already the build. A new approach would replace it."""
    try:
        with open(_stored_path(root), encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, json.JSONDecodeError):
        return False
    return bool(data.get("template"))


def _stored_marker(template: str) -> str:
    if "const STORED = [" in template:
        return "const STORED = ["
    if "STORED = [" in template:
        return "STORED = ["
    return ""


def _template_returns_slot(template: str, index_at: int = 0,
                           filename: str = "") -> bool:
    """The check's function returns the stored element, rather than building one.

    A generator that also declares the list and never reads it makes every
    later element invisible. A sentinel in slot 0 has to come back from the
    argument the check uses to select an element.
    """
    if "STORED[" not in template and "/*STORED-START*/" not in template:
        return False
    if not _stored_marker(template) and "/*STORED-START*/" not in template:
        return False
    sentinel = "__STORED_SLOT__"
    source = _splice_stored(template, [json.dumps(sentinel)])
    parent = tempfile.mkdtemp(prefix="stored-slot-")
    python = "STORED = [" in source and "const STORED = [" not in source
    try:
        if python and "STORED = [" in source:
            with open(os.path.join(parent, "mod.py"), "w", encoding="utf-8") as fh:
                fh.write(source)
            with open(os.path.join(parent, "probe.py"), "w", encoding="utf-8") as fh:
                fh.write(
                    "import importlib.util\n"
                    "spec = importlib.util.spec_from_file_location('storedmod', 'mod.py')\n"
                    "mod = importlib.util.module_from_spec(spec)\n"
                    "spec.loader.exec_module(mod)\n"
                    "fns = [v for k, v in vars(mod).items() if callable(v) and not k.startswith('_')]\n"
                    "if not fns:\n"
                    "    raise SystemExit(2)\n"
                    "args = [None] * %d\n"
                    "args[%d] = 0\n"
                    "try:\n"
                    "    got = fns[0](*args)\n"
                    "except Exception:\n"
                    "    raise SystemExit(3)\n"
                    "raise SystemExit(0 if got == %s else 4)\n"
                    % (index_at + 1, index_at, json.dumps(sentinel)))
            proc = subprocess.run(
                ["python3", "probe.py"], cwd=parent, capture_output=True,
                text=True, timeout=30)
            return proc.returncode == 0
        if "function " in source or "const STORED = [" in source:
            with open(os.path.join(parent, "mod.js"), "w", encoding="utf-8") as fh:
                fh.write(source)
            with open(os.path.join(parent, "probe.js"), "w", encoding="utf-8") as fh:
                fh.write(
                    "const m = require('./mod.js');\n"
                    "const fn = typeof m === 'function' ? m : "
                    "Object.values(m).find((v) => typeof v === 'function');\n"
                    "if (typeof fn !== 'function') process.exit(2);\n"
                    "const args = Array(%d).fill(null);\n"
                    "args[%d] = 0;\n"
                    "let got;\n"
                    "try { got = fn.apply(null, args); } catch (e) { process.exit(3); }\n"
                    "if (got !== %s) process.exit(4);\n"
                    % (index_at + 1, index_at, json.dumps(sentinel)))
            proc = subprocess.run(
                ["node", "probe.js"], cwd=parent, capture_output=True, text=True,
                timeout=30)
            return proc.returncode == 0
        runner = _lookup_runner_for(filename)
        if not runner:
            return False
        ext = os.path.splitext(filename)[1] or ".txt"
        path = os.path.join(parent, "mod" + ext)
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(source)
        env = dict(os.environ)
        env["STORED_PROBE"] = "0"
        proc = subprocess.run(
            [runner, path], cwd=parent, capture_output=True, text=True,
            timeout=30, env=env)
        got = (proc.stdout or "").strip().strip('"').strip("'")
        return proc.returncode == 0 and got == sentinel
    except (OSError, subprocess.TimeoutExpired):
        return False
    finally:
        shutil.rmtree(parent, ignore_errors=True)


def _stored_export_name(root: str, command: str, filename: str) -> str:
    """The name the check calls on this file. Empty when the check never does."""
    base = os.path.basename(filename)
    stem = os.path.splitext(base)[0]
    wanted = {base, stem}
    names: List[str] = []
    for path in _check_script_paths(root, command):
        try:
            with open(path, encoding="utf-8", errors="replace") as fh:
                text = fh.read()
        except OSError:
            continue
        for match in re.finditer(
                r"""([A-Za-z_]\w*)\s*=\s*require\(\s*['"](\.[^'"]+)['"]\s*\)""",
                text):
            ref = os.path.basename(match.group(2))
            if ref not in wanted and os.path.splitext(ref)[0] not in wanted:
                continue
            binder = match.group(1)
            names.extend(re.findall(
                r"\b%s\.([A-Za-z_]\w*)" % re.escape(binder), text))
        for match in re.finditer(
                r"""\{\s*([^}]+)\}\s*=\s*require\(\s*['"](\.[^'"]+)['"]\s*\)""",
                text):
            ref = os.path.basename(match.group(2))
            if ref not in wanted and os.path.splitext(ref)[0] not in wanted:
                continue
            for part in match.group(1).split(","):
                part = part.strip()
                if part:
                    names.append(part.split(":")[0].strip().split()[-1])
        for match in re.finditer(
                r"from\s+([A-Za-z_]\w*)\s+import\s+\(?([A-Za-z_][\w,\s]*)\)?",
                text):
            if match.group(1) != stem:
                continue
            for part in match.group(2).split(","):
                part = part.strip()
                if part:
                    names.append(part.split()[0])
        if not names:
            continue
        called = [name for name in names if name not in _CALL_SKIP and re.search(
            r"\b%s\s*\(" % re.escape(name), text)]
        pool = called or [name for name in names if name not in _CALL_SKIP]
        if pool:
            return max(pool, key=lambda name: len(re.findall(
                r"\b%s\s*\(" % re.escape(name), text)))
    return ""


def _lookup_language(filename: str) -> str:
    ext = os.path.splitext(filename)[1].lower()
    return {
        ".py": "Python",
        ".js": "JavaScript", ".mjs": "JavaScript", ".cjs": "JavaScript",
        ".jsx": "JavaScript", ".ts": "JavaScript",
        ".rb": "Ruby", ".php": "PHP", ".lua": "Lua", ".pl": "Perl",
        ".go": "Go", ".rs": "Rust",
    }.get(ext, "the language of this file")


def _lookup_runner_for(filename: str) -> str:
    cmd = {
        ".py": "python3", ".js": "node", ".mjs": "node", ".cjs": "node",
        ".rb": "ruby", ".php": "php", ".lua": "lua", ".pl": "perl",
    }.get(os.path.splitext(filename)[1].lower(), "")
    return cmd if cmd and shutil.which(cmd) else ""


def _missing_literal(filename: str, missing: str) -> str:
    """The empty value, in the file's language. Never a made-up valid output."""
    js = not filename.endswith(".py")
    text = (missing or "").strip()
    if not text or "\n" in text or len(text) > 80 or "STORED" in text:
        return "null" if js else "None"
    if js and text == "None":
        return "null"
    if filename.endswith(".py") and text == "null":
        return "None"
    return text


def _ask_binding(root: str, command: str, filename: str,
                 cfg: swarm.Config, state: swarm.State) -> Tuple[int, str]:
    """Which argument selects an element, and what to return when it is absent."""
    reply = _small_reply(cfg, state, intent.LOOKUP_PROMPT.format(
        language=_lookup_language(filename),
        check=_check_text(root, command)[:4000]), 60)
    index, missing = intent.parse_lookup(reply)
    if index is None:
        index = 0
    missing = _missing_literal(filename, missing)
    sys.stderr.write("  lookup index %d, missing %s\n" % (index, missing))
    return index, missing


def _ask_ingest_script(root: str, command: str, filename: str,
                       cfg: swarm.Config, state: swarm.State) -> Tuple[str, int]:
    """The lookup file. The model is not asked for a Python or JavaScript one.

    The model's job is the next stored value. This file only returns that
    value. The argument and the empty value come from the check. Another
    language is one file, accepted only when the sentinel comes back out.
    """
    name = _stored_export_name(root, command, filename)
    index, missing = _ask_binding(root, command, filename, cfg, state)
    script = _lookup_script(filename, name, index, missing)
    if script and _template_returns_slot(script, index, filename):
        sys.stderr.write("  lookup for %s returns the stored element\n" % name)
        return script, index
    script = _foreign_lookup(filename, name, index, missing, cfg, state)
    if script:
        return script, index
    sys.stderr.write("  no lookup; the check does not name a function in %s\n"
                     % filename)
    return "", 0


def _foreign_lookup(filename: str, name: str, index: int, missing: str,
                    cfg: swarm.Config, state: swarm.State) -> str:
    """One lookup file in a language this process does not template."""
    if not name or not name.isidentifier() or not _lookup_runner_for(filename):
        return ""
    if filename.endswith(".py") or os.path.splitext(filename)[1].lower() in (
            ".js", ".mjs", ".cjs", ".jsx", ".ts"):
        return ""
    code = _code_reply(_floor4_reply(cfg, state, (
        "Write %s. This file only returns stored data. It does not create it.\n"
        "The dataset is a JSON array between the exact markers /*STORED-START*/ "
        "and /*STORED-END*/, written as /*STORED-START*/[]/*STORED-END*/.\n"
        "Function %s returns the element selected by argument %d, counting from 0.\n"
        "An integer selects by position. A string selects the element equal to "
        "it, or the element that contains that string.\n"
        "When nothing matches, return %s.\n"
        "When the environment variable STORED_PROBE is set to an index, print "
        "the element at that index and exit 0. Print the text of a string "
        "with no extra quotes.\n"
        "Do not generate an element. Reply with the file only.\n"
        % (filename, name, index, missing)), 1500))
    if "/*STORED-START*/" not in code or "/*STORED-END*/" not in code:
        sys.stderr.write("  lookup for %s had no stored list\n" % filename)
        return ""
    if _template_returns_slot(code, index, filename):
        sys.stderr.write("  lookup for %s returns the stored element\n" % name)
        return code
    sys.stderr.write("  lookup for %s did not return the stored element\n" % filename)
    return ""


def _lookup_script(filename: str, name: str, index: int, missing: str) -> str:
    """A file that returns the stored element and does nothing else.

    The pipeline writes this for Python and JavaScript. The function name
    comes from the check. The body does not know what an element is.
    """
    if not name or not name.isidentifier():
        return ""
    ext = os.path.splitext(filename)[1].lower()
    if ext == ".py":
        return (
            "STORED = [\n];\n"
            "def %s(*args):\n"
            "    def pick(key):\n"
            "        if isinstance(key, int) and not isinstance(key, bool) and key >= 0:\n"
            "            if key < len(STORED):\n"
            "                return STORED[key], True\n"
            "            return [], True\n"
            "        if isinstance(key, str):\n"
            "            for el in STORED:\n"
            "                if el == key:\n"
            "                    return el, True\n"
            "                if isinstance(el, dict) and key in el.values():\n"
            "                    return el, True\n"
            "                if isinstance(el, (list, tuple)) and key in el:\n"
            "                    return el, True\n"
            "        return None, False\n"
            "    keys = []\n"
            "    if len(args) > %d:\n"
            "        keys.append(args[%d])\n"
            "    keys.extend(args)\n"
            "    for key in keys:\n"
            "        found, ok = pick(key)\n"
            "        if ok:\n"
            "            return found\n"
            "    return %s\n" % (name, index, index, missing))
    if ext not in ("", ".js", ".mjs", ".cjs", ".jsx", ".ts"):
        return ""
    return (
        "const STORED = [\n];\n"
        "function %s() {\n"
        "  function pick(key) {\n"
        "    if (typeof key === \"number\" && Number.isInteger(key) && key >= 0) return key < STORED.length ? STORED[key] : [];\n"
        "    if (typeof key === \"string\") {\n"
        "      for (const el of STORED) {\n"
        "        if (el === key) return el;\n"
        "        if (el && typeof el === \"object\") {\n"
        "          const vals = Array.isArray(el) ? el : Object.values(el);\n"
        "          if (vals.indexOf(key) >= 0) return el;\n"
        "        }\n"
        "      }\n"
        "    }\n"
        "  }\n"
        "  const keys = [];\n"
        "  if (arguments.length > %d) keys.push(arguments[%d]);\n"
        "  for (const arg of arguments) keys.push(arg);\n"
        "  for (const key of keys) {\n"
        "    const found = pick(key);\n"
        "    if (found !== undefined) return found;\n"
        "  }\n"
        "  return %s;\n"
        "}\n"
        "if (typeof module !== \"undefined\") module.exports = { %s };\n"
        % (name, index, index, missing, name))


def _literal_failure(element: str, filename: str) -> str:
    """Why this text cannot be pasted as one value, or empty when it can.

    The lookup writes the reply straight into the source file. A function is
    a script. A quote that does not close does not parse, so the check
    never sees it.
    """
    parent = tempfile.mkdtemp(prefix="stored-lit-")
    try:
        if filename.endswith(".py"):
            path = os.path.join(parent, "probe.py")
            with open(path, "w", encoding="utf-8") as fh:
                fh.write("import ast\nast.literal_eval(%s)\n" % json.dumps(element))
            proc = subprocess.run(
                ["python3", path], cwd=parent, capture_output=True, text=True,
                timeout=15)
        else:
            with open(os.path.join(parent, "probe.js"), "w", encoding="utf-8") as fh:
                fh.write(
                    "const v = (%s);\n"
                    "if (v === undefined || typeof v === \"function\") process.exit(2);\n"
                    % element)
            proc = subprocess.run(
                ["node", "probe.js"], cwd=parent, capture_output=True, text=True,
                timeout=15)
        if proc.returncode == 0:
            return ""
        err = [line.strip() for line in (proc.stderr or proc.stdout or "").splitlines()
               if line.strip() and not re.match(r"Node\.js v", line.strip())]
        picked = ""
        for line in err:
            if re.search(r"SyntaxError|ReferenceError|Error:", line):
                picked = line
                break
        return (picked or (err[-1] if err else "does not parse"))[:200]
    except (OSError, subprocess.TimeoutExpired) as exc:
        return str(exc)[:200]
    finally:
        shutil.rmtree(parent, ignore_errors=True)


def _literal_parts(element: str, filename: str) -> List[str]:
    """The string parts of one stored value, or nothing when it is not that shape."""
    parent = tempfile.mkdtemp(prefix="stored-size-")
    try:
        if filename.endswith(".py"):
            path = os.path.join(parent, "probe.py")
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(
                    "import ast, json\n"
                    "v = ast.literal_eval(%s)\n"
                    "if isinstance(v, str):\n"
                    "    print(json.dumps([v]))\n"
                    "elif isinstance(v, list) and all(isinstance(p, str) for p in v):\n"
                    "    print(json.dumps(v))\n" % json.dumps(element))
            proc = subprocess.run(
                ["python3", path], cwd=parent, capture_output=True, text=True,
                timeout=15)
        else:
            with open(os.path.join(parent, "probe.js"), "w", encoding="utf-8") as fh:
                fh.write(
                    "const v = (%s);\n"
                    "let s = null;\n"
                    "if (typeof v === \"string\") s = [v];\n"
                    "else if (Array.isArray(v) && v.every(p => typeof p === \"string\")) s = v;\n"
                    "if (s) console.log(JSON.stringify(s));\n" % element)
            proc = subprocess.run(
                ["node", "probe.js"], cwd=parent, capture_output=True, text=True,
                timeout=15)
        if proc.returncode != 0:
            return []
        parts = json.loads(proc.stdout.strip() or "[]")
    except (OSError, subprocess.TimeoutExpired, json.JSONDecodeError, ValueError):
        return []
    finally:
        shutil.rmtree(parent, ignore_errors=True)
    if not isinstance(parts, list) or any(not isinstance(p, str) for p in parts):
        return []
    return parts


def _json_list(element: str, filename: str):
    """The value as a list, when it is one. Strings stay strings.

    A list of records and a list of strings are the same shape to the edit.
    A value that is not a list is left for a whole-literal reply.
    """
    parts = _literal_parts(element, filename)
    if parts:
        return parts
    try:
        value = json.loads(element)
    except json.JSONDecodeError:
        return None
    return value if isinstance(value, list) else None


def _apply_part_edits(element: str, filename: str, reply: str) -> str:
    """Replace the parts the reply names. The reply writes each new part.

    REPLACE <index> <json value> changes that one part and leaves the others.
    The index is a position in the list. The value is whatever the model wrote.
    """
    matches = re.findall(r"(?im)^REPLACE\s+(\d+)\s+(\S.*)$", reply or "")
    if not matches:
        return ""
    items = _json_list(element, filename)
    if items is None:
        return ""
    applied = 0
    for index_s, raw in matches:
        index = int(index_s)
        if index >= len(items):
            continue
        try:
            value = json.loads(raw.strip())
        except json.JSONDecodeError:
            continue
        if items[index] != value:
            items[index] = value
            applied += 1
    if not applied:
        return ""
    return json.dumps(items, ensure_ascii=False)


def _mismatch_distance(lines: Sequence[str]):
    """How far the check's own numbers are from the numbers it required.

    A line "3, not 5" contributes 2. A line "3, shorter than 5" contributes
    the shortfall, 2. A larger measurement is not a shortfall. A failure
    that names no such pair contributes nothing, and the caller uses the
    text of the failure instead.
    """
    total = 0
    found = False
    for line in lines:
        for wrong, required in re.findall(
                r"(\d+)\s*,\s*(?:not|shorter than)\s+(\d+)", line):
            found = True
            got, need = int(wrong), int(required)
            total += abs(got - need) if "not" in line else max(0, need - got)
    return total if found else None


def _failure_skeleton(lines: Sequence[str]) -> Tuple[str, ...]:
    """The failure with measurements blanked out.

    "column 63 row 17" and "column 59 row 17" are the same fact. A new
    number is not a new failure.
    """
    return tuple(re.sub(r"\d+", "#", line) for line in lines)


def _gate_at(line: str, check_text: str):
    """Where this failure is printed in the check, or None.

    The check lists its gates in the order a value has to pass them. A line
    that quotes a later part of the check is a later gate. Numbers are the
    measurement, not the gate.
    """
    raw = re.sub(r"^CHECK FAILED:\s*", "", line or "", flags=re.I)
    words = [w for w in re.sub(r"\d+", " ", raw).split() if w]
    if not check_text or len(words) < 3:
        return None
    for length in range(min(len(words), 14), 2, -1):
        for start in range(0, len(words) - length + 1):
            phrase = " ".join(words[start:start + length])
            pos = check_text.find(phrase)
            if pos >= 0:
                return pos
    return None


def _stuck_at(lines: Sequence[str], check_text: str):
    """The earliest gate still failing. No lines means the value has passed."""
    if not lines:
        return None
    found = [_gate_at(line, check_text) for line in lines]
    return min(pos if pos is not None else -1 for pos in found)


def _earliest_line(lines: Sequence[str], check_text: str) -> List[str]:
    """The one failure line to repair first: the earliest gate in the check.

    The check lists its gates in the order a value has to pass them. A
    later line often cannot be judged until the earlier one is gone, and a
    reply asked to clear every line at once clears none. The rest are asked
    for after this one is gone.
    """
    if len(lines) <= 1:
        return list(lines)
    best, best_at = None, None
    for line in lines:
        at = _gate_at(line, check_text)
        at = -1 if at is None else at
        if best_at is None or at < best_at:
            best, best_at = line, at
    return [best]


def _later_note(lines: Sequence[str], shown: Sequence[str]) -> str:
    rest = len(lines) - len(shown)
    if rest <= 0:
        return ""
    return ("\n(%d more line%s for this value will be asked for after this one "
            "is gone.)" % (rest, "" if rest == 1 else "s"))


def _further(old_lines: Sequence[str], new_lines: Sequence[str],
             check_text: str) -> bool:
    """The new report is further through the check than the one already held.

    A later gate is further. The same gate is further only when its measured
    gap shrank. A different sentence at the same gate is not further.
    """
    if not new_lines:
        return True
    if not old_lines:
        return False
    old_at = _stuck_at(old_lines, check_text)
    new_at = _stuck_at(new_lines, check_text)
    if new_at is None:
        return True
    if old_at is None or new_at < old_at:
        return False
    if new_at > old_at:
        return True
    if _failure_skeleton(old_lines) == _failure_skeleton(new_lines):
        old_distance = _mismatch_distance(old_lines)
        new_distance = _mismatch_distance(new_lines)
        return (old_distance is not None and new_distance is not None
                and new_distance < old_distance)
    return len(new_lines) < len(old_lines)


def _improved(old_lines: Sequence[str], new_lines: Sequence[str]) -> bool:
    """The check's report moved. The same report is not progress.

    When the check gives two numbers around "not", closer is progress.
    The same sentence with different numbers is not. A different fact is.
    """
    if _failure_skeleton(old_lines) == _failure_skeleton(new_lines):
        old_distance = _mismatch_distance(old_lines)
        new_distance = _mismatch_distance(new_lines)
        if old_distance is None or new_distance is None:
            return False
        return new_distance < old_distance
    old_distance = _mismatch_distance(old_lines)
    new_distance = _mismatch_distance(new_lines)
    if old_distance is not None or new_distance is not None:
        old_n = old_distance or 0
        new_n = new_distance or 0
        if new_n < old_n:
            return True
        return new_n == old_n and set(new_lines) != set(old_lines)
    return True


def _isolated_part(element: str, filename: str, lines: Sequence[str]):
    """The one part whose size is the number the check says was wrong.

    The model rewrites that part. Nothing here shortens it or fills it.
    Zero hits, or more than one, means the check did not point at one part.
    """
    items = _json_list(element, filename)
    if not items:
        return None
    for line in lines:
        match = re.search(r"(\d+)\s*,\s*not\s+(\d+)", line)
        if not match:
            continue
        wrong = int(match.group(1))
        sized = [i for i, part in enumerate(items)
                 if isinstance(part, str) and len(part) == wrong]
        if len(sized) == 1:
            return sized[0], line.strip(), items[sized[0]]
        # The index nearest the measurement, ignoring the two sizes themselves.
        # An earlier number in the line is some other counter.
        nearest = None
        for found in re.finditer(r"(?<!\d)\d+(?!\d)", line[:match.start()]):
            index = int(found.group())
            if index in sized and index != wrong:
                nearest = index
        if nearest is not None:
            return nearest, line.strip(), items[nearest]
    return None


def _named_part(element: str, filename: str, lines: Sequence[str], slot: int):
    """The one part a failure line names, when exactly one index remains.

    The first number inside parentheses selects an input, not a part. A
    number in a size pair is a measurement. The slot being written is not a
    part of this value. One remaining in-range index is the part to change.
    """
    items = _json_list(element, filename)
    if not items:
        return None
    hits = []
    for line in lines:
        selectors = set()
        for group in re.findall(r"\(([^)]*)\)", line):
            nums = re.findall(r"\d+", group)
            if nums:
                selectors.add(int(nums[0]))
        measured = set()
        for wrong, required in re.findall(
                r"(\d+)\s*,\s*(?:not|shorter than)\s+(\d+)", line):
            measured.add(int(wrong))
            measured.add(int(required))
        for found in re.findall(
                r"(?:than|not|returned|most|least)\s+(\d+)", line, re.I):
            measured.add(int(found))
        for found in re.findall(r"(?<!\d)\d+(?!\d)", line):
            index = int(found)
            if index == slot or index in selectors or index in measured:
                continue
            if 0 <= index < len(items) and index not in hits:
                hits.append(index)
    if len(hits) != 1:
        return None
    index = hits[0]
    naming = next(
        (line.strip() for line in lines
         if re.search(r"(?<!\d)%d(?!\d)" % index, line)), "")
    part = items[index]
    return index, naming, part if isinstance(part, str) else json.dumps(part)


def _remember_failed(tried: List[List[Any]], reply: str,
                     lines: Sequence[str]) -> None:
    """Keep the replies this value already got rejected for, newest last.

    The same text again is counted, and moved to the end. A reply far longer
    than a value is a runaway, and is left out so it does not crowd the ask.
    """
    if not reply or len(reply) > 6000:
        return
    for entry in tried:
        if entry[0] == reply:
            entry[1] = list(lines)
            entry[2] += 1
            tried.remove(entry)
            tried.append(entry)
            return
    tried.append([reply, list(lines), 1])
    del tried[:-3]


def _describe_change(base: Sequence[str], new: Sequence[str]) -> str:
    """How a reply differs from the value held, in parts and lengths.

    The reply is described, not repeated. A full copy of a near-identical
    value is one more reason for the next reply to be the same copy.
    """
    if list(new) == list(base):
        return "identical to the held value"
    bits = []
    changed = [i for i in range(min(len(base), len(new))) if base[i] != new[i]]
    for i in changed[:6]:
        bits.append("part %d changed (length %d to %d)" % (i, len(base[i]), len(new[i])))
    if len(changed) > 6:
        bits.append("%d more parts changed" % (len(changed) - 6))
    if len(new) != len(base):
        bits.append("it has %d parts, the held value has %d" % (len(new), len(base)))
    kept = min(len(base), len(new)) - len(changed)
    if kept:
        bits.append("%d parts are the same as the held value" % kept)
    return "; ".join(bits)


def _tried_block(tried: Sequence[Sequence[Any]], draft: str,
                 filename: str) -> str:
    """The replies already tried for this value, each with what the check said."""
    if not tried:
        return ""
    base = _literal_parts(draft, filename) if draft else []
    chunks = []
    for number, (reply, lines, times) in enumerate(tried, 1):
        said = "\n".join(
            line if len(line) <= 200 else line[:200] + " ..."
            for line in lines[:4]) or "(the check printed nothing new)"
        often = "" if times == 1 else " It has come back %d times." % times
        parts = _literal_parts(reply, filename) if base else []
        if base and parts:
            how = _describe_change(base, parts)
            chunks.append(
                "Reply %d was tried and not saved.%s Compared with the held "
                "value: %s.\nThe check said:\n%s" % (number, often, how, said))
        else:
            chunks.append(
                "Reply %d, tried and not saved.%s\n%s\nThe check said:\n%s"
                % (number, often, reply, said))
    return (
        "\n".join(chunks) + "\n"
        "Each of those was rejected. The next reply has to differ from all of "
        "them, and change what the check said was wrong.\n")


def _accepted_shape(elements: Sequence[str], filename: str) -> str:
    """The measured shape of the values the check already accepted.

    A paraphrase of the check can drop its numbers. The accepted values
    cannot. Only counts and lengths are read, so any collection of strings
    reports the same way. Nothing here sets a size for the next value.
    """
    counts, uniform, spread = [], [], []
    seen = 0
    for element in list(elements)[-3:]:
        parts = _literal_parts(element, filename)
        if not parts:
            continue
        seen += 1
        counts.append(len(parts))
        sizes = [len(part) for part in parts]
        if min(sizes) == max(sizes):
            uniform.append(sizes[0])
        else:
            spread.append((min(sizes), max(sizes)))
    if not seen:
        return ""
    def span(values):
        low, high = min(values), max(values)
        return str(low) if low == high else "%d to %d" % (low, high)
    text = "Of the values the check accepted, the last %d had %s parts." % (
        seen, span(counts))
    if uniform and not spread:
        text += " In each of them every part was %s characters long." % span(uniform)
    elif spread:
        low = min([s[0] for s in spread] + uniform)
        high = max([s[1] for s in spread] + uniform)
        text += " Their parts were %d to %d characters long." % (low, high)
    return text + "\n"


def _accepted_context(elements: Sequence[str], lines: Sequence[str],
                      slot: int) -> str:
    """Kept values a failure line compares this slot to.

    The first number inside parentheses is the input. A value is shown only
    when a failure line compares this slot to it (same as, easier than).
    Shown unprompted, a passed value is a template, and the writer copies it.
    """
    wanted = []
    for line in lines:
        for group in re.findall(r"\(([^)]*)\)", line):
            nums = re.findall(r"\d+", group)
            if not nums:
                continue
            index = int(nums[0])
            if index == slot or not (0 <= index < len(elements)):
                continue
            if index not in wanted:
                wanted.append(index)
    chunks = []
    for index in wanted[:2]:
        value = elements[index]
        if len(value) > 8000:
            continue
        chunks.append(
            "Input %d already passed the check. Do not return this value "
            "unchanged:\n%s" % (index, value))
    if not chunks:
        return ""
    return (
        "\n".join(chunks) + "\n"
        "The value being written has to pass the same check. Where a rejected "
        "line compares it to one of these inputs, satisfy that comparison.\n")


def _part_count_gap(element: str, filename: str, lines: Sequence[str]) -> str:
    """The check's count line, when it matches how many parts this value has.

    A part replacement cannot add or remove a part. The caller asks for the
    whole value. Nothing here writes the missing parts.
    """
    items = _json_list(element, filename)
    if not items:
        return ""
    for line in lines:
        match = re.search(r"returned\s+(\d+)\b.*\bnot\s+(\d+)", line, re.I)
        if not match:
            continue
        got, need = int(match.group(1)), int(match.group(2))
        if got == len(items) and need != got and need > 0:
            return (
                "The check says: %s This value has %d parts. Write the whole "
                "value with at least %d parts. Keep a part that already "
                "satisfies the check. Do not copy one part to fill the rest. "
                "A longer value is fine."
                % (line.strip(), got, need))
    return ""


def _repeat_repair(element: str, filename: str) -> str:
    """Name a value whose every part is one copy of the same text.

    Copying one part to fill the collection is a synthetic value. A repeated
    character inside a part is the model's text, and is left alone.
    """
    parts = _literal_parts(element, filename)
    if not parts or len(parts) < 2 or len(set(parts)) != 1:
        return ""
    return (
        "The array has %d parts and every part is the same text. "
        "Copying that part again is not a repair." % len(parts))


def _slot_lines(lines: Sequence[str], slot: int) -> List[str]:
    """The failures of the value being written.

    A line that names another input belongs to another slot. Showing those
    asks one reply to satisfy every input, and the reply comes back as a stub.
    """
    own = [line for line in lines if re.search(r"(?<!\d)%d(?!\d)" % slot, line)]
    return own or lines[:1]


def _explain_missing_slot(text: str) -> str:
    """A missing stored slot is null. The check reports null as object."""
    lines = [line for line in (text or "").splitlines() if line.strip()]
    if not lines:
        return text
    kept = [line for line in lines if not re.search(r"returned object\b", line, re.I)]
    if len(kept) == len(lines):
        return text
    kept.insert(
        0,
        "This slot has no stored value yet. A missing value is null, and "
        "the check reports null as object. Write the value.")
    return "\n".join(kept)


def _repair_sample(element: str, filename: str) -> str:
    """One copy of a repeated part, so the repair is not asked to reprint the run."""
    parts = _literal_parts(element, filename)
    if parts and len(parts) > 1 and len(set(parts)) == 1:
        return ("One part, repeated %d times:\n%s"
                % (len(parts), json.dumps(parts[0], ensure_ascii=False)))
    return element


def _data_literal(element: str, filename: str) -> bool:
    """One value. A function, even one that returns data, is a script."""
    return _literal_failure(element, filename) == ""


def _load_stored(root: str, filename: str, count: int) -> Tuple[str, List[str], int]:
    try:
        with open(_stored_path(root), encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, json.JSONDecodeError):
        return "", [], 0
    if data.get("file") != filename or data.get("count") != count:
        return "", [], 0
    template = _repair_lookup_template(data.get("template") or "")
    elements = data.get("elements") or []
    try:
        index_at = int(data.get("index") or 0)
    except (TypeError, ValueError):
        index_at = 0
    if ("const STORED = [" not in template and "STORED = [" not in template
            and "/*STORED-START*/" not in template) or not isinstance(elements, list):
        return "", [], 0
    if not _template_returns_slot(template, index_at, filename):
        sys.stderr.write("  stored template does not return its elements\n")
        return "", [], 0
    return template, [e for e in elements if isinstance(e, str) and e.strip()], index_at


def _is_relation(line: str) -> bool:
    """A line that names two or more inputs describes how they sit together."""
    return len(set(re.findall(r"\((\d+)\)", line))) >= 2


def _place_by_check(root: str, command: str, filename: str, template: str,
                    elements: Sequence[str], element: str,
                    baseline_lines: Sequence[str]) -> Optional[int]:
    """Where in the kept values this one goes so the check stops objecting.

    A value that is valid but sits in the wrong place (an order the check
    describes between inputs) is moved, not rejected. The check is the
    ranker: each position from the end backwards is tried, and the first
    one that adds no line wins. Returns None when no position helps, as for
    a duplicate, which no order can fix.
    """
    for at in range(len(elements), -1, -1):
        trial = list(elements)
        trial.insert(at, element)
        ok, out = _check_source(
            root, command, filename, _splice_stored(template, trial))
        if ok:
            return at
        introduced, _resolved = _changed_lines(baseline_lines, _failure_lines(out))
        if not introduced:
            return at
    return None


def _keep_removed(root: str, prior: Any, elements: Sequence[str]) -> None:
    """A kept value that leaves the set is written down first.

    Every drop (a rewind, a rejected tail, a changed check) is a decision
    the pipeline made about work that cost real time. The values go to
    `.ralph/removed.jsonl` with the time, never pruned, so a wrong decision
    can be undone from the file instead of regenerated.
    """
    if not isinstance(prior, dict) or not isinstance(prior.get("elements"), list):
        return
    old, new = prior["elements"], list(elements)
    gone = [(i, v) for i, v in enumerate(old) if v not in new]
    if not gone:
        return
    try:
        with open(os.path.join(root, ".ralph", "removed.jsonl"), "a",
                  encoding="utf-8") as fh:
            fh.write(json.dumps({
                "at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "kept_before": len(old), "kept_after": len(new),
                "removed": [{"slot": i, "value": v} for i, v in gone]}) + "\n")
    except OSError:
        pass


def _save_stored(root: str, filename: str, count: int, template: str,
                 elements: Sequence[str], index_at: int = 0, draft: str = "",
                 element: Optional[str] = None,
                 briefs: Optional[Dict[str, str]] = None) -> None:
    prior_element = ""
    prior_briefs: Dict[str, str] = {}
    try:
        with open(_stored_path(root), encoding="utf-8") as fh:
            prior = json.load(fh)
        _keep_removed(root, prior, elements)
        if isinstance(prior, dict) and isinstance(prior.get("element"), str):
            prior_element = prior["element"]
        if isinstance(prior, dict) and isinstance(prior.get("briefs"), dict):
            prior_briefs = prior["briefs"]
    except (OSError, json.JSONDecodeError):
        prior_element = ""
    if element is None:
        element = prior_element
    if briefs is None:
        briefs = prior_briefs
    payload = {"file": filename, "count": count, "index": index_at,
               "template": template, "elements": list(elements),
               "draft": draft}
    if element:
        payload["element"] = element
    if briefs:
        payload["briefs"] = briefs
    os.makedirs(os.path.join(root, ".ralph"), exist_ok=True)
    with open(_stored_path(root), "w", encoding="utf-8") as fh:
        json.dump(payload, fh)


def _stored_draft(root: str, filename: str) -> str:
    try:
        with open(_stored_path(root), encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, json.JSONDecodeError):
        return ""
    if data.get("file") != filename:
        return ""
    draft = data.get("draft") or ""
    return draft if isinstance(draft, str) else ""


def _repair_lookup_template(template: str) -> str:
    """An index past the filled list is an empty array, not null.

    The check reports null as object, so an unfilled index looked like a value
    of the wrong type. An integer index returns [] until a value is kept.
    A resize that repeats a character to change the shape is not part of the lookup.
    """
    old = ("typeof key === \"number\" && Number.isInteger(key) && key >= 0 "
           "&& key < STORED.length) return STORED[key];")
    new = ("typeof key === \"number\" && Number.isInteger(key) && key >= 0) "
           "return key < STORED.length ? STORED[key] : [];")
    template = template.replace(old, new)
    if "function fit(" in template and "const STORED = [" in template:
        match = re.search(r"function\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(", template)
        if match and match.group(1) != "fit":
            fresh = _lookup_script(match.group(1) + ".js", match.group(1), 0, "null")
            if fresh:
                return fresh
    return template


def _splice_stored(template: str, elements: Sequence[str]) -> str:
    start_mark = "/*STORED-START*/"
    end_mark = "/*STORED-END*/"
    if start_mark in template and end_mark in template:
        start = template.find(start_mark) + len(start_mark)
        end = template.find(end_mark, start)
        if end < 0:
            return template
        body = "[" + ",".join(elements) + "]"
        return template[:start] + body + template[end:]
    marker = "const STORED = [" if "const STORED = [" in template else "STORED = ["
    start = template.find(marker)
    end = template.find("];", start)
    if start < 0 or end < 0:
        return template
    body = ",\n".join(elements)
    return template[:start] + marker + "\n" + body + "\n" + template[end:]


def _stored_value_blank(element: str, filename: str) -> bool:
    """An empty value. A record, a string, or a number is present.

    A value that still fails a later rule stays. Dropping it made the next
    round rewrite a slot the file already had.
    """
    del filename
    try:
        value = json.loads(element)
    except json.JSONDecodeError:
        return True
    if value is None or value == "" or value == [] or value == {}:
        return True
    return False


def _installed_elements(root: str, filename: str) -> List[str]:
    """Real values already in the project file, in order, stopping at a blank."""
    path = os.path.join(root, filename)
    if not os.path.isfile(path):
        return []
    parent = tempfile.mkdtemp(prefix="stored-installed-")
    try:
        with open(os.path.join(parent, "probe.js"), "w", encoding="utf-8") as fh:
            fh.write(
                "const fs = require('fs');\n"
                "const vm = require('vm');\n"
                "const src = fs.readFileSync(process.argv[2], 'utf8')"
                ".replace('const STORED', 'var STORED');\n"
                "const sandbox = {module: {exports: {}}, exports: {}, require, console};\n"
                "try { vm.runInNewContext(src, sandbox); } catch (e) { process.exit(0); }\n"
                "const arr = sandbox.STORED;\n"
                "if (!Array.isArray(arr)) process.exit(0);\n"
                "const out = [];\n"
                "for (const el of arr) {\n"
                "  const blank = el == null || el === '' ||\n"
                "    (Array.isArray(el) && el.length === 0) ||\n"
                "    (typeof el === 'object' && !Array.isArray(el) && Object.keys(el).length === 0);\n"
                "  if (blank) break;\n"
                "  out.push(el);\n"
                "}\n"
                "console.log(JSON.stringify(out));\n")
        proc = subprocess.run(
            ["node", "probe.js", os.path.abspath(path)], cwd=parent,
            capture_output=True, text=True, timeout=15)
        if proc.returncode != 0:
            return []
        arr = json.loads(proc.stdout.strip() or "[]")
    except (OSError, subprocess.TimeoutExpired, json.JSONDecodeError, ValueError):
        return []
    finally:
        shutil.rmtree(parent, ignore_errors=True)
    if not isinstance(arr, list):
        return []
    return [json.dumps(el, ensure_ascii=False) for el in arr]


def _drop_failed_slots(root: str, command: str, filename: str, template: str,
                      elements: List[str], count: int) -> List[str]:
    """Drop a blank stored value, and everything after it.

    Indexes have to stay aligned. An empty value that was kept by mistake
    fills the set. A real value the check still rejects is handled by
    `_reopen_rejected_tail`, which sends it back to the draft.
    """
    del root, command, template, count
    for i, element in enumerate(elements):
        if _stored_value_blank(element, filename):
            sys.stderr.write("  dropping stored values from %d; that one is empty\n" % i)
            return elements[:i]
    return elements


def _first_rejected_kept(lines: Sequence[str], kept: int) -> Optional[int]:
    """The earliest kept value that a failure line is about.

    The first number inside parentheses is the input the line is about, the
    same reading `_accepted_context` uses. A line about an input that was
    already kept means the check rejects that value now, whatever it
    passed when it was kept. Lines about later, empty inputs are left out.
    """
    owners = []
    for line in lines:
        match = re.search(r"\(([^)]*)\)", line)
        if not match:
            continue
        nums = re.findall(r"\d+", match.group(1))
        if nums and int(nums[0]) < kept:
            owners.append(int(nums[0]))
    return min(owners) if owners else None


def _reopen_rejected_tail(root: str, command: str, filename: str, template: str,
                          elements: List[str], draft: str) -> Tuple[List[str], str]:
    """Give a kept value back to the draft when the check still rejects it.

    The writer only appends. A value kept while it still added a failure
    line would sit there forever, and every later round would edit the
    next slot. The value is not rewritten here. Lines present without it
    are about the set or about another value.
    """
    while elements:
        before = []
        if len(elements) > 1:
            _before_ok, before_out = _check_source(
                root, command, filename,
                _splice_stored(template, elements[:-1]))
            before = _failure_lines(before_out)
        _after_ok, after_out = _check_source(
            root, command, filename, _splice_stored(template, elements))
        introduced, _resolved = _changed_lines(before, _failure_lines(after_out))
        if not introduced:
            break
        draft = elements.pop()
        sys.stderr.write(
            "  last stored value still fails the check; it goes back to the draft "
            "(%d kept)\n" % len(elements))
    return elements, draft


def _fact_key(line: str) -> str:
    """A line's identity: who it names and what it says, not how far.

    The first number inside the first parentheses names the input the line
    is about, so it stays. Every other number is a measurement, and a
    measurement moving between two runs ("5 different levels", "column 60")
    is the same line, not a new one.
    """
    match = re.search(r"\((\d+)\)", line)
    if not match:
        return re.sub(r"\d+", "#", line)
    head, tail = line[:match.start()], line[match.end():]
    return (re.sub(r"\d+", "#", head) + "(" + match.group(1) + ")"
            + re.sub(r"\d+", "#", tail))


def _changed_lines(before: Sequence[str], after: Sequence[str]
                   ) -> Tuple[List[str], List[str]]:
    """Lines the new value introduced, and lines it cleared.

    A line present in both runs is about some other value or about the set.
    The check's wording decides which line is which. No number is assumed
    to be an index.
    """
    before_set = {_fact_key(line) for line in before}
    after_set = {_fact_key(line) for line in after}
    introduced = [line for line in after if _fact_key(line) not in before_set]
    resolved = [line for line in before if _fact_key(line) not in after_set]
    return introduced, resolved


def _compose_command(root: str) -> str:
    """The project's compose command, or "".

    `compose.json` in the project root holds {"command": "..."}. A value that
    is easier to specify than to draw (coordinates instead of a character
    grid) is written by the model as a spec, and this command turns the spec
    into the value literal. `<command> --describe` prints what the model is
    told about the spec. The spec on stdin, the literal on stdout, a non-zero
    exit with the reason on stdout/stderr when the spec cannot be drawn.
    """
    try:
        with open(os.path.join(root, "compose.json"), encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, json.JSONDecodeError):
        return ""
    command = data.get("command") if isinstance(data, dict) else ""
    return command.strip() if isinstance(command, str) else ""


def _compose_run(root: str, command: str, stdin: str = "",
                 extra: Sequence[str] = ()) -> Tuple[int, str]:
    try:
        proc = subprocess.run(
            shlex.split(command) + list(extra), input=stdin, cwd=root,
            capture_output=True, text=True, timeout=30)
    except (OSError, subprocess.TimeoutExpired, ValueError) as exc:
        return 1, "compose command did not run: %s" % exc
    out = proc.stdout if proc.returncode == 0 else (proc.stdout + proc.stderr)
    return proc.returncode, out.strip()


def _compose_render(root: str, command: str, spec: str) -> Tuple[str, str]:
    """(value literal, reason). The reason is empty when the spec was drawn."""
    code, out = _compose_run(root, command, spec)
    if code != 0 or not out:
        return "", (out or "the compose command printed nothing")[:400]
    return out, ""


def _load_specs(root: str) -> Dict[str, str]:
    try:
        with open(os.path.join(root, ".ralph", "specs.json"), encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, json.JSONDecodeError):
        return {}
    return {k: v for k, v in data.items() if isinstance(k, str) and isinstance(v, str)} \
        if isinstance(data, dict) else {}


def _save_specs(root: str, specs: Dict[str, str]) -> None:
    """The spec each drawn value came from, so a repair shows the spec that
    made the value it is repairing, not the latest reply's."""
    while len(specs) > 24:
        specs.pop(next(iter(specs)))
    try:
        os.makedirs(os.path.join(root, ".ralph"), exist_ok=True)
        with open(os.path.join(root, ".ralph", "specs.json"), "w", encoding="utf-8") as fh:
            json.dump(specs, fh)
    except OSError:
        pass


def _compose_ask(root: str, command: str, direction: str, closing: str,
                 revision: str, shown_fail: str, last_spec: str,
                 draft: str, filename: str, spec_error: str = "") -> str:
    """The ask when the model writes a spec and a program draws the value."""
    code, described = _compose_run(root, command, "", ["--describe"])
    if code != 0 or not described:
        described = "Reply with the spec and nothing else."
    parts = [described + "\n", direction]
    if spec_error:
        parts.append("The last reply could not be drawn: %s\nReply with a "
                     "spec that can be drawn.\n" % spec_error)
    if draft:
        parts.append(
            "The value drawn from the last spec was rejected by the check:\n%s\n"
            % (shown_fail or "(no change to the report)"))
        if last_spec:
            parts.append("The spec you wrote:\n%s\n" % last_spec[:6000])
        parts.append("What the program drew from it:\n%s\n"
                     % _repair_sample(draft, filename))
        parts.append(
            "Reply with a corrected spec that clears that line. Change the "
            "spec, not the drawing. A spec identical to the last one is "
            "rejected.\n")
    elif revision:
        parts.append(revision + "\n")
    parts.append(closing)
    return "".join(parts)


def _store_outputs(root: str, command: str, request: str, filename: str,
                   count: int, cfg: swarm.Config, state: swarm.State) -> str:
    """Produce outputs one at a time, keep those the check accepts, then order them.

    The kept elements live in `.ralph/stored.json`, so a later round continues
    the set instead of starting a new procedure. The project file is replaced
    only when the check exits 0.
    """
    template, elements, index_at = _load_stored(root, filename, count)
    draft = _stored_draft(root, filename)
    installed = _installed_elements(root, filename)
    if template and len(installed) > len(elements):
        extra = installed[len(elements):]
        if not (draft and extra == [draft]):
            elements = installed
            draft = ""
            _save_stored(root, filename, count, template, elements, index_at, draft)
            sys.stderr.write("  restored %d stored value(s) from %s\n"
                             % (len(elements), filename))
    target = os.path.join(root, filename)
    if template and os.path.isfile(target):
        try:
            with open(target, encoding="utf-8") as fh:
                current = fh.read()
        except OSError:
            current = ""
        if "function fit(" in current and "function fit(" not in template:
            _install_stored(root, filename, _splice_stored(template, elements))
            sys.stderr.write("  lookup returns each stored value unchanged\n")
    if template and elements:
        elements = _drop_failed_slots(
            root, command, filename, template, elements, count)
        kept_before = len(elements)
        elements, draft = _reopen_rejected_tail(
            root, command, filename, template, elements, draft)
        if len(elements) < kept_before:
            _install_stored(root, filename, _splice_stored(template, elements))
            sys.stderr.write(
                "  lookup serves only the values the check did not reject\n")
        _held_ok, held_out = _check_source(
            root, command, filename, _splice_stored(template, elements))
        rejected_at = _first_rejected_kept(_failure_lines(held_out), len(elements))
        if rejected_at is not None:
            draft = elements[rejected_at]
            sys.stderr.write(
                "  kept value %d is rejected by the check now; it goes back to "
                "the draft, and the %d values after it are dropped\n"
                % (rejected_at, len(elements) - rejected_at - 1))
            elements = elements[:rejected_at]
            _install_stored(root, filename, _splice_stored(template, elements))
            _save_stored(root, filename, count, template, elements, index_at, draft)
        if len(elements) != count:
            _save_stored(root, filename, count, template, elements, index_at, draft)
    if not template:
        sys.stderr.write("  writing the lookup, then asking for one stored value\n")
        template, index_at = _ask_ingest_script(root, command, filename, cfg, state)
        if not template:
            return _stored_directive(filename, count, 0)
        _save_stored(root, filename, count, template, [], index_at)
        draft = ""
    _shown_ok, shown_out = _check_source(
        root, command, filename, _splice_stored(template, elements))
    failures = "\n".join(_failure_lines(shown_out)) or "(none)"
    described = _stored_element(root, filename)
    check_text = _check_text(root, command)
    if described and "symbols" in described.lower() and "; rules " not in described:
        sys.stderr.write(
            "  stored description did not carry the check's rules; asking again\n")
        described = ""
    if not described:
        for _ in range(3):
            described = intent.parse_element(_floor4_reply(
                cfg, state, intent.ELEMENT_PROMPT.format(
                    check=check_text, failures=failures),
                400))
            if described:
                break
            sys.stderr.write("  stored value description omitted a size; asking again\n")
        if described:
            _save_stored(
                root, filename, count, template, elements, index_at, draft,
                described)
    if described:
        sys.stderr.write("  stored value is: %s\n" % described[:200])
    briefs = _stored_briefs(root)
    compose = _compose_command(root)
    brief_basis = check_text
    if compose:
        _code, composed = _compose_run(root, compose, "", ["--describe"])
        if composed:
            brief_basis = composed
            # Optional: how the check measures difficulty. It is read when the
            # set is planned, never shown to the writer as a rule.
            dcode, measured = _compose_run(root, compose, "", ["--difficulty"])
            if dcode == 0 and measured:
                brief_basis += "\n\nHOW DIFFICULTY IS MEASURED:\n" + measured
    sig_path = os.path.join(root, ".ralph", "briefs-basis.txt")
    try:
        with open(sig_path, encoding="utf-8") as fh:
            known_basis = fh.read()
    except OSError:
        known_basis = ""
    if briefs and known_basis != brief_basis and compose:
        # Briefs written before the rules changed point at values the rules
        # now reject. They are rewritten against the rules the writer reads.
        sys.stderr.write("  the writer's rules changed since the briefs were written; "
                         "writing them again\n")
        briefs = {}
    if len(briefs) < count // 2:
        briefs = _write_briefs(cfg, state, brief_basis, count, root)
        if briefs:
            try:
                os.makedirs(os.path.dirname(sig_path), exist_ok=True)
                with open(sig_path, "w", encoding="utf-8") as fh:
                    fh.write(brief_basis)
            except OSError:
                pass
            _save_stored(root, filename, count, template, elements, index_at,
                         draft, None, briefs)
            sys.stderr.write("  wrote %d briefs, one per input\n" % len(briefs))
        else:
            sys.stderr.write("  no briefs came back; asking without them\n")
    stalled = 0
    cuts = 0
    tried: List[List[Any]] = []
    same_report = 0
    retired = False
    force_whole = False
    seen_fail = set()
    prior = ""
    copies = 0
    edit_base = False
    specs = _load_specs(root)
    spec_error = ""
    if compose:
        sys.stderr.write("  values are written as a spec and drawn by: %s\n" % compose)
    while len(elements) < count and stalled < 8:
        _base_ok, base_out = _check_source(
            root, command, filename, _splice_stored(template, elements))
        baseline_lines = _failure_lines(base_out)
        if isinstance(prior, list):
            first = _earliest_line(prior, check_text)
            shown_fail = "\n".join(first) + _later_note(prior, first)
        elif prior:
            shown_fail = prior
        else:
            own = _slot_lines(baseline_lines, len(elements))
            first = _earliest_line(own, check_text)
            shown_fail = "\n".join(first) + _later_note(own, first)
        revision = ""
        draft_lines = []
        gap = ""
        isolated = None
        focus = None
        if draft:
            _draft_ok, draft_out = _check_source(
                root, command, filename,
                _splice_stored(template, list(elements) + [draft]))
            draft_lines, _resolved = _changed_lines(
                baseline_lines, _failure_lines(draft_out))
            now_lines = _earliest_line(draft_lines, check_text)
            shown_fail = ("\n".join(now_lines) + _later_note(draft_lines, now_lines)
                          if now_lines else
                          "This value did not change the check report.")
            if draft_lines and all(_is_relation(line) for line in draft_lines):
                where = _place_by_check(root, command, filename, template,
                                        elements, draft, baseline_lines)
                if where is not None:
                    elements.insert(where, draft)
                    _save_stored(root, filename, count, template, elements, index_at)
                    _install_stored(root, filename,
                                    _splice_stored(template, elements))
                    sys.stderr.write(
                        "  held value is valid but not in order (%s); placed at "
                        "position %d (%d kept)\n"
                        % (draft_lines[0][:120], where, len(elements)))
                    draft, prior, stalled = "", "", 0
                    tried.clear()
                    continue
            if draft_lines:
                seen_fail.add(_failure_skeleton(draft_lines))
            repeat = _repeat_repair(draft, filename)
            gap = _part_count_gap(draft, filename, now_lines)
            isolated = _isolated_part(draft, filename, now_lines)
            if gap:
                sys.stderr.write("  stored count repair: %s\n" % gap.splitlines()[0][:160])
                revision = gap + "\nReply with the whole value and nothing else.\n"
            elif isolated:
                index, line, part = isolated
                focus = index
                sys.stderr.write("  stored part repair: %s\n" % line[:160])
                revision = (
                    "The check says: %s\n"
                    "That measurement is one part, at index %d. Reply with that "
                    "one part, as one JSON string, and nothing else. The other "
                    "parts stay. A part shorter than the check is incomplete.\n"
                    % (line, index))
            else:
                named = _named_part(draft, filename, now_lines, len(elements))
                if named:
                    index, line, part = named
                    focus = index
                    sys.stderr.write(
                        "  stored part named by the check: %s\n" % line[:160])
                    revision = (
                        "The check names part %d of this value:\n%s\n"
                        "Reply with that one part, as one JSON string, and "
                        "nothing else. The other parts stay as they are.\n"
                        % (index, line))
                else:
                    note = repeat or "Reply with the whole value and nothing else."
                    sys.stderr.write(
                        "  stored value repair: %s\n" % note.splitlines()[0][:160])
                    revision = (
                        "Reply with the whole value and nothing else. No function and "
                        "no assignment. Do not return the current value unchanged.\n"
                        "%s\n" % note)
        else:
            gap = ""
        if force_whole and draft and not gap:
            revision = (
                "The last reply began with words, so it did not parse and "
                "the check never saw it. The first character of the reply "
                "is the start of the value.\n")
            sys.stderr.write(
                "  last reply was not a value; asking for the whole value\n")
        force_whole = False
        if not draft and isinstance(prior, str) and prior.startswith("The last reply"):
            revision = prior
        if stalled and focus is not None:
            # One part was tried and did not get past the line. A line that
            # names a part can still need a change somewhere else (a row
            # added, a neighbour moved), so the next ask is the whole value.
            sys.stderr.write(
                "  part %d alone did not clear the line; asking for the whole value\n"
                % focus)
            focus = None
        if stalled and draft_lines:
            missed = "\n".join(_earliest_line(draft_lines, check_text))
            if focus is not None:
                revision = (
                    "The previous reply did not get past the line above, so it "
                    "was not saved. Reply with part %d only, as one JSON string. "
                    "Nothing before it. The other parts stay. That line has to "
                    "be gone.\n" % focus)
            else:
                revision = (
                    "The previous reply did not get past the line above, so it "
                    "was not saved. Reply with the whole value and nothing "
                    "before it. That line has to be gone.\n")
            sys.stderr.write("  asking again past the same failure\n")
        rejected = ""
        if draft:
            if focus is not None:
                parts = _literal_parts(draft, filename)
                shown = (json.dumps(parts[focus], ensure_ascii=False)
                         if parts and focus < len(parts) else draft)
                rejected = (
                    "Rejected part %d, already seen by the check:\n%s\n"
                    % (focus, shown))
            else:
                rejected = (
                    "Rejected attempt, already seen by the check:\n%s\n"
                    % _repair_sample(draft, filename))
        accepted = _accepted_context(
            elements, shown_fail.splitlines(), len(elements))
        if edit_base and elements and brief_for_edit(briefs, len(elements)):
            base_at = len(elements) - 1
            if len(elements[base_at]) <= 8000:
                accepted = (
                    "Start from this value. It already passes the check "
                    "(input %d):\n%s\n"
                    "Edit it so the value for input %d shows: %s\n"
                    "Change what that calls for and keep what already works. "
                    "A reply identical to it is rejected.\n"
                    % (base_at, elements[base_at], len(elements),
                       brief_for_edit(briefs, len(elements))))
                rejected = ""
        held_dup = _duplicate_of(draft, elements) if draft else None
        if held_dup is not None:
            rejected = (
                "The value held for this input is the same value as input %d. "
                "The check rejects it for that, so it is not shown. Write a "
                "different value.\n" % held_dup)
        direction = ""
        closing = ""
        brief = briefs.get(str(len(elements)))
        if brief:
            direction = (
                "You are writing the value for input %d. What it has to show: "
                "%s\n"
                "Show that as plainly as the check allows. The check decides "
                "what is valid, and the value has to differ from the others. "
                "Attempts below that failed are not a starting point; write "
                "the value this input calls for.\n" % (len(elements), brief))
            if focus is None:
                closing = (
                    "Now reply with the value for input %d, showing: %s\n"
                    "The reply is the value and nothing else.\n"
                    % (len(elements), brief))
        shape = _accepted_shape(elements, filename)
        if not shape and described:
            shape = (
                "Minimum shape only, not the requirement: %s\n"
                "The rejected lines are the requirement. A shape line does not "
                "replace one of them. A size there is a minimum.\n" % described)
        ask = (
            "The reply is one source literal and nothing before it. No "
            "function, no loop, no assignment, and no script. It is pasted "
            "into the file, so it has to parse as one value. There is no "
            "maximum length.\n"
            "%s"
            "The check rejected the value being written:\n%s\n"
            "%s"
            "%s"
            "%s"
            "%s"
            "%s"
            "%s"
            "%s"
            % (direction,
               _explain_missing_slot(shown_fail) or "(none)",
               revision + "\n" if revision else "",
               accepted,
               rejected,
               _tried_block(tried, draft, filename),
               shape,
               _check_reference(check_text),
               closing))
        if compose:
            focus = None
            ask = _compose_ask(
                root, compose, direction,
                closing or "Reply with the spec for input %d and nothing else.\n"
                % len(elements),
                revision, shown_fail, specs.get(draft, "") if draft else "",
                draft, filename, spec_error)
        spec_error = ""
        reply_meta: Dict[str, Any] = {}
        text, thinking = _floor4_exchange(
            cfg, state, ask, STORED_VALUE_TOKENS * (2 ** min(cuts, 10)),
            temperature=min(0.9, 0.1 + 0.2 * stalled), think=False,
            sampled=True, meta=reply_meta, fit_window=True)
        if reply_meta.get("cut"):
            cuts += 1
            sys.stderr.write(
                "  reply was cut off at %s tokens; the next one may be longer "
                "(up to what the window leaves)\n" % reply_meta.get("ceiling", "?"))
        _keep_thought(root, len(elements), stalled, thinking)
        edited = ""
        if focus is not None and draft:
            raw = _code_reply(text or "").strip()
            if raw.endswith(";"):
                raw = raw[:-1].strip()
            try:
                replacement = json.loads(raw)
            except json.JSONDecodeError:
                replacement = None
            items = _json_list(draft, filename)
            if (isinstance(replacement, str) and items is not None
                    and focus < len(items)):
                items[focus] = replacement
                edited = json.dumps(items, ensure_ascii=False)
                sys.stderr.write("  replaced the part the check named\n")
        if edited:
            element = edited
            sys.stderr.write("  applied part edits to the current value\n")
        else:
            if compose:
                spec_text = _code_reply(text or "").strip()
                element, reason = _compose_render(root, compose, spec_text)
                if not reason:
                    reason = _literal_failure(element, filename)
                if not reason:
                    specs[element] = spec_text
                    _save_specs(root, specs)
                text = spec_text if reason else text
                spec_error = reason if (reason and compose) else ""
            else:
                element = _code_reply(text).strip()
                if element.endswith(";"):
                    element = element[:-1].strip()
                reason = _literal_failure(element, filename) if element else "empty"
            if reason:
                stalled += 1
                _keep_attempt(root, len(elements), stalled, reason, text or element, [], ask)
                if draft and focus is not None:
                    prior = draft_lines
                    sys.stderr.write(
                        "  reply was not the one part (%s); the previous value stays (%d kept)\n"
                        % (reason, len(elements)))
                elif draft:
                    prior = draft_lines
                    force_whole = True
                    sys.stderr.write(
                        "  edit was not a value (%s); writing the whole value (%d kept)\n"
                        % (reason, len(elements)))
                else:
                    prior = "The last reply did not parse as one value: %s" % reason
                    sys.stderr.write("  stored element was not a literal: %s (%d kept)\n"
                                     % (reason, len(elements)))
                continue
        dup = _duplicate_of(element, elements)
        if dup is not None:
            stalled += 1
            note = ("The reply is exactly the value already kept for input %d. "
                    "Input %d must return a different value."
                    % (dup, len(elements)))
            varied = _vary_brief(cfg, state, check_text, briefs, len(elements), dup)
            if varied:
                briefs[str(len(elements))] = varied
                _save_stored(root, filename, count, template, elements, index_at,
                             draft, briefs=briefs)
            _keep_attempt(root, len(elements), stalled,
                          "duplicate of input %d" % dup, element, [note], ask)
            _remember_failed(tried, element, [note])
            prior = draft_lines if draft else note
            sys.stderr.write(
                "  reply equals input %d; this input's brief now reads: %s\n"
                % (dup, (varied or "(unchanged)")[:140]))
            copies += 1
            if copies % 3 == 0:
                # A writer handed a held value and a passed one copies them.
                # Three copies in a row: nothing that anchors it stays.
                draft, prior = "", ""
                edit_base = True
                tried.clear()
                _save_stored(root, filename, count, template, elements,
                             index_at, "", briefs=briefs)
                sys.stderr.write(
                    "  %d copies in a row; the held value and the tried "
                    "replies are dropped; this input is now an edit of the "
                    "last kept value\n" % copies)
            continue
        source = _splice_stored(template, list(elements) + [element])
        ok, out = _check_source(root, command, filename, source)
        if ok:
            elements.append(element)
            _save_stored(root, filename, count, template, elements, index_at)
            _install_stored(root, filename, source)
            sys.stderr.write("  stored outputs pass the check\n")
            return STORED_DONE
        current, resolved = _changed_lines(baseline_lines, _failure_lines(out))
        insert_at = len(elements)
        if current and all(_is_relation(line) for line in current):
            where = _place_by_check(root, command, filename, template,
                                    elements, element, baseline_lines)
            if where is not None:
                insert_at = where
                sys.stderr.write(
                    "  valid, but not in order (%s); placed at position %d\n"
                    % (current[0][:120], where))
                trial = list(elements)
                trial.insert(where, element)
                source = _splice_stored(template, trial)
                current = []
        held = draft_lines or _slot_lines(baseline_lines, len(elements))
        if (not ok and _repeat_repair(element, filename)
                and not _further(held, current, check_text)):
            stalled += 1
            prior = (
                "The last reply used one part for every position. "
                "That did not clear the check. Write a value whose parts "
                "are not all the same text.\n%s" % "\n".join(current or draft_lines))
            _keep_attempt(root, len(elements), stalled, "repeated one part",
                          element, current, ask)
            _remember_failed(tried, element, current)
            sys.stderr.write(
                "  reply repeated one part; the best value stays (%d kept)\n"
                % len(elements))
            continue
        if not current:
            elements.insert(insert_at, element)
            copies = 0
            edit_base = False
            _save_stored(root, filename, count, template, elements, index_at)
            _install_stored(root, filename, source)
            stalled = 0
            same_report = 0
            prior = ""
            draft = ""
            tried.clear()
            sys.stderr.write("  kept an output (%d of %d); %d failures of this "
                             "output remain\n" % (len(elements), count, len(current)))
        elif draft and _further(draft_lines, current, check_text):
            draft = element
            _save_stored(root, filename, count, template, elements, index_at, draft)
            _install_stored(root, filename, source)
            stalled = 0
            same_report = 0
            tried.clear()
            prior = current
            shown = (current or ["unchanged"])[0][:160]
            sys.stderr.write(
                "  closer value stays in the file: %s (%d kept)\n"
                % (shown, len(elements)))
        elif draft:
            stalled += 1
            prior = draft_lines
            _keep_attempt(root, len(elements), stalled, "not further", element, current, ask)
            _remember_failed(tried, element, current)
            sys.stderr.write(
                "  reply is not further; the best value stays (%d kept)\n"
                % len(elements))
        elif _further(held, current, check_text):
            draft = element
            _save_stored(root, filename, count, template, elements, index_at, draft)
            _install_stored(root, filename, source)
            stalled = 0
            prior = current
            shown = (current or ["unchanged"])[0][:160]
            sys.stderr.write(
                "  closer value stays in the file: %s (%d kept)\n"
                % (shown, len(elements)))
        else:
            stalled += 1
            prior = current or baseline
            _keep_attempt(root, len(elements), stalled, "not closer", element, current, ask)
            _remember_failed(tried, element, current)
            shown = (current or baseline or ["unchanged"])[0][:160]
            sys.stderr.write("  reply was not closer: %s (%d kept)\n"
                             % (shown, len(elements)))
    if not elements or len(elements) < 2:
        return _stored_directive(filename, count, len(elements))
    order = list(range(len(elements)))
    for _ in range(6):
        source = _splice_stored(template, [elements[i] for i in order])
        ok, out = _check_source(root, command, filename, source)
        if ok:
            _install_stored(root, filename, source)
            try:
                os.remove(_stored_path(root))
            except OSError:
                pass
            sys.stderr.write("  stored outputs pass the check\n")
            return STORED_DONE
        lines = _failure_lines(out)
        kinds = _classify_lines(lines, cfg, state)
        relationship = [line for line in lines if kinds.get(line) == "set"]
        if not relationship:
            break
        text = _floor4_reply(cfg, state, (
            "These stored outputs pass or fail as a set. Reply with nothing "
            "but ORDER: and the indexes, a permutation of 0..%d, so the "
            "relationship the check describes holds. Do not drop an output.\n"
            "%s\n" % (len(elements) - 1, "\n".join(relationship or lines))),
            300)
        match = re.search(r"ORDER:\s*([0-9,\s]+)", text or "")
        if not match:
            break
        proposed = [int(n) for n in re.findall(r"\d+", match.group(1))]
        if sorted(proposed) != list(range(len(elements))) or proposed == order:
            break
        order = proposed
        sys.stderr.write("  reordering the kept outputs\n")
    return _stored_directive(filename, count, len(elements))


def _install_stored(root: str, filename: str, source: str) -> None:
    target = os.path.join(root, filename)
    os.makedirs(os.path.dirname(target) or root, exist_ok=True)
    tmp = target + ".stored-tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write(source)
    os.replace(tmp, target)


def _stored_directive(filename: str, count: int, kept: int) -> str:
    note = (
        "This request is a stored set of %d outputs in %s, not a procedure "
        "of the input. Produce one output at a time. Keep it when the check "
        "accepts that output on its own. Discard it when that output is "
        "invalid. A good output in the wrong position is kept and moved, "
        "not rebuilt. Do not write a search that derives the output from "
        "the input. %d outputs are already kept."
        % (count, filename, kept))
    return note


def _saved_shape(root: str) -> Tuple[str, int]:
    """The file and count already stored, when a lookup is on disk.

    A later round is the same request. Asking the shape again spends a
    floor-4 call and can flip a stored set back into a procedure.
    """
    try:
        with open(_stored_path(root), encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, json.JSONDecodeError):
        return "", 0
    if not isinstance(data, dict) or not data.get("template"):
        return "", 0
    filename = data.get("file") or ""
    try:
        count = int(data.get("count") or 0)
    except (TypeError, ValueError):
        return "", 0
    if not filename or count < 2:
        return "", 0
    if not os.path.isfile(os.path.join(root, filename)):
        return "", 0
    return filename, count


def _stored_briefs(root: str) -> Dict[str, str]:
    try:
        with open(_stored_path(root), encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, json.JSONDecodeError):
        return {}
    briefs = data.get("briefs") if isinstance(data, dict) else None
    if not isinstance(briefs, dict):
        return {}
    return {str(k): v for k, v in briefs.items() if isinstance(v, str) and v}


def brief_for_edit(briefs: Dict[str, str], slot: int) -> str:
    return briefs.get(str(slot), "")


def _same_value(a: str, b: str) -> bool:
    try:
        return json.loads(a) == json.loads(b)
    except (json.JSONDecodeError, TypeError):
        return (a or "").strip() == (b or "").strip()


def _duplicate_of(element: str, elements: Sequence[str]) -> Optional[int]:
    for index, kept in enumerate(elements):
        if _same_value(element, kept):
            return index
    return None


def _vary_brief(cfg: swarm.Config, state: swarm.State, check_text: str,
                briefs: Dict[str, str], slot: int, other: int) -> str:
    """Rewrite one input's brief after it produced another input's value.

    The two briefs are read side by side and the second is made to name
    something the first does not. The model sees every other brief so the
    new one does not collide with a third.
    """
    second = briefs.get(str(slot), "")
    first = briefs.get(str(other), "")
    others = "\n".join("%s: %s" % (k, v) for k, v in sorted(
        briefs.items(), key=lambda kv: int(kv[0]) if kv[0].isdigit() else 0)
        if k not in (str(slot), str(other))) or "(none)"
    reply, _thinking = _floor4_exchange(
        cfg, state,
        intent.VARIED_BRIEF_PROMPT.format(
            first=other, first_brief=first or "(none written)",
            second=slot, second_brief=second or "(none written)",
            others=others, check=check_text),
        400, temperature=0.8, think=False, sampled=True, fit_window=True)
    line = (reply or "").strip().splitlines()[0] if (reply or "").strip() else ""
    line = re.sub(r"^\W*\d+\s*[:.)\-]\s*", "", line).replace("**", "").strip()
    return line[:400]


def _brief_axes(cfg: swarm.Config, state: swarm.State, basis: str,
                root: Optional[str]) -> Tuple[str, List[Tuple[str, bool, List[str]]]]:
    """The ways values can differ, written once per rules text and kept."""
    path = os.path.join(root, ".ralph", "axes.json") if root else ""
    if path:
        try:
            with open(path, encoding="utf-8") as fh:
                data = json.load(fh)
            if data.get("basis") == basis and data.get("axes"):
                return data.get("theme", ""), [
                    (a[0], bool(a[1]), list(a[2])) for a in data["axes"]]
        except (OSError, json.JSONDecodeError, TypeError, IndexError):
            pass
    for _ in range(2):
        reply, _thinking = _floor4_exchange(
            cfg, state, intent.AXES_PROMPT.format(check=basis), 1500,
            temperature=0.6, think=False, sampled=True, fit_window=True)
        theme, axes = intent.parse_axes(reply)
        if len(axes) >= 3:
            if path:
                try:
                    os.makedirs(os.path.dirname(path), exist_ok=True)
                    with open(path, "w", encoding="utf-8") as fh:
                        json.dump({"basis": basis, "theme": theme,
                                   "axes": [[n, r, v] for n, r, v in axes]}, fh,
                                  ensure_ascii=False, indent=1)
                except OSError:
                    pass
            return theme, axes
    return "", []


def _write_briefs(cfg: swarm.Config, state: swarm.State, check_text: str,
                  count: int, root: Optional[str] = None) -> Dict[str, str]:
    """One short brief per input, written by the model.

    Sampling does not make two near-identical asks differ, so each input
    gets its own sentence. The brief is a direction. The check decides.

    Two steps when the model can list the ways values differ: the axes
    (qualities that climb, qualities that are different kinds), then a
    combination per input compiled without a model so no two are alike, then
    one call that turns each combination into a sentence. A combination the
    model drops is kept as its own qualities, which are still unique.
    """
    theme, axes = _brief_axes(cfg, state, check_text, root)
    if len(axes) >= 3:
        combos = intent.compile_qualities(axes, count)
        listed = "\n".join(
            "%d: %s" % (i, "; ".join("%s = %s" % (n, v) for n, v in combo))
            for i, combo in enumerate(combos))
        reply, _thinking = _floor4_exchange(
            cfg, state,
            intent.BRIEF_FROM_QUALITIES_PROMPT.format(
                theme=theme or "a varied set", check=check_text, lines=listed,
                count=count),
            max(1500, count * 110), temperature=0.5, think=False, sampled=True,
            fit_window=True)
        briefs = intent.parse_briefs(reply, count)
        for i, combo in enumerate(combos):
            if str(i) not in briefs:
                briefs[str(i)] = "; ".join("%s: %s" % (n, v) for n, v in combo)
        sys.stderr.write("  briefs compiled from %d axes (%s)\n"
                         % (len(axes), ", ".join(n for n, _r, _v in axes)))
        return briefs
    reply, _thinking = _floor4_exchange(
        cfg, state,
        intent.BRIEFS_PROMPT.format(count=count, check=check_text),
        max(1200, count * 60), temperature=0.8, think=False, sampled=True,
        fit_window=True)
    return intent.parse_briefs(reply, count)


def _stored_element(root: str, filename: str) -> str:
    """The value description already accepted for this file, or ""."""
    try:
        with open(_stored_path(root), encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, json.JSONDecodeError):
        return ""
    if not isinstance(data, dict) or data.get("file") != filename:
        return ""
    element = data.get("element") or ""
    return element if isinstance(element, str) else ""


def _finish_stored(root: str, filename: str, result: str) -> str:
    if result == STORED_DONE:
        return STORED_DONE
    path = os.path.join(root, ".ralph", "approach.txt")
    try:
        os.makedirs(os.path.join(root, ".ralph"), exist_ok=True)
        with open(path, "w", encoding="utf-8") as fh:
            fh.write("FILE: %s\n%s\n" % (filename, result))
    except OSError as exc:
        sys.stderr.write("  could not save the stored-output note: %s\n" % exc)
    return result


def direct_stored(root: str, command: str, request: str, cfg: swarm.Config,
                  state: swarm.State) -> str:
    """Stored outputs from the first round when the classifier says so.

    A repeated failure asks the same question again, with the failures in
    front of it, so a procedure that is not working can be changed without
    waiting out a long run. The classifier is the small model. Keyword
    matching on the request is not a substitute for it.
    """
    if not command:
        return ""
    filename, count = _saved_shape(root)
    if filename:
        sys.stderr.write("  build shape: stored %s x %d\n" % (filename, count))
        sys.stderr.write("  producing stored outputs in %s, keeping the ones "
                         "the check accepts\n" % filename)
        return _finish_stored(
            root, filename,
            _store_outputs(root, command, request, filename, count, cfg, state))
    try:
        with open(os.path.join(root, ".ralph", "last-check.txt"),
                  encoding="utf-8", errors="replace") as fh:
            failed = fh.read()
    except OSError:
        failed = ""
    shown = check_verdict(failed)[-2000:] if failed.strip() else "(none yet)"
    shape, filename, count = ask_build_shape(
        root, command, request, shown, cfg, state)
    if shape != "stored" and recurring_failures(ralph_round_kinds(root)):
        sys.stderr.write("  same failure class is back; asking whether the "
                         "build should be stored outputs\n")
        shape, filename, count = ask_build_shape(
            root, command, request, shown, cfg, state, again=True)
    if shape != "stored":
        return ""
    sys.stderr.write("  producing stored outputs in %s, keeping the ones "
                     "the check accepts\n" % filename)
    return _finish_stored(
        root, filename,
        _store_outputs(root, command, request, filename, count, cfg, state))


def _class_key(shared: Sequence[tuple]) -> str:
    return "\n".join(sorted({line for line, _earlier in shared}))


def _saved_round_note(root: str, key: str) -> str:
    """The note already written for this failure class, or ""."""
    try:
        with open(os.path.join(root, ".ralph", "approach.txt"),
                  encoding="utf-8", errors="replace") as fh:
            text = fh.read()
    except OSError:
        return ""
    if not text.startswith("CLASS:\n") or not key.strip():
        return ""
    saved, _, rest = text[len("CLASS:\n"):].partition("\nFILE:")
    if saved.strip() != key.strip() or not rest.strip():
        return ""
    return ("The last repair left the same failure class. Build the file "
            "this way instead. Every failure line still has to be met:\n\n"
            "FILE:" + rest.strip())


def stuck_approach(root: str, command: str, cfg: swarm.Config,
                   state: swarm.State) -> str:
    """When a Ralph round repeats a failure from any earlier round, ask
    floor 4 for a different way to build the file.

    A stored set is not a build. Asking for a new procedure here spends the
    floor-4 box and the note is not what the next stored value is written from.
    """
    if _stored_active(root):
        sys.stderr.write("  stored set stays stored; not asking for a new approach\n")
        return ""
    path = os.path.join(root, ".ralph", "approach.txt")
    tried_path = os.path.join(root, ".ralph", "approach-tried.txt")
    shared = recurring_failures(ralph_round_kinds(root))
    if not shared:
        for stale in (path, tried_path):
            try:
                os.remove(stale)
            except OSError:
                pass
        return ""
    saved = _saved_round_note(root, _class_key(shared))
    if saved:
        sys.stderr.write("  using the note written between rounds\n")
        return saved
    try:
        with open(os.path.join(root, ".ralph", "last-check.txt"),
                  encoding="utf-8", errors="replace") as fh:
            failed = fh.read()
    except OSError:
        return ""
    blamed, _how = blame_for_check(root, failed, command)
    if not blamed:
        return ""
    _files, shown = fail_site_files(root, failed, command)
    sources = []
    for name in blamed:
        try:
            with open(os.path.join(root, name), encoding="utf-8",
                      errors="replace") as fh:
                body = fh.read(12000)
        except OSError:
            body = ""
        sources.append("--- %s ---\n%s" % (name, body or "(missing)"))
    verdict = check_verdict(failed)[-4000:]
    history = "\n".join(
        "%s (also round %s)" % (line, ", ".join(str(n) for n in earlier))
        for line, earlier in shared)
    try:
        with open(tried_path, encoding="utf-8", errors="replace") as fh:
            tried = fh.read().strip()
    except OSError:
        tried = ""
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            prior = fh.read().strip()
    except OSError:
        prior = ""
    if prior and prior not in tried:
        tried = (tried + "\n\n" + prior).strip()
    tried_note = ""
    if tried:
        tried_note = (
            "Approaches already given to the writer, after which the same "
            "failures came back:\n%s\n\nRead the current file. If it does "
            "not follow one of these, the next build should follow it. If "
            "it already follows one and the check still fails, do not give "
            "that build again.\n\n" % tried[-4000:])
    prompt = (
        "A repair loop has rewritten the same file and the check still "
        "fails the same class of requirement. These failures from this "
        "round also appeared in an earlier round:\n%s\n\nThis round's "
        "check:\n%s\n\n%s%s"
        "The current file is below. Meeting one line by breaking another "
        "is how the class survived, including when the line skipped a "
        "round and came back. Propose a build so every failure line is "
        "true at the same time. Do not say the check is wrong. Do not "
        "name a file other than: %s. Keep the public names the check "
        "calls.\n\n%s\n\nReply in this shape, once per file you were "
        "given:\nFILE: name\nAPPROACH:\n<the build>\n"
        % (history, verdict, tried_note,
           ("The check decides it like this: %s\n\n" % shown) if shown else "",
           ", ".join(blamed),
           "\n\n".join(sources)))
    sys.stderr.write("  same failure class as an earlier round; asking "
                     "for a different approach\n")
    text = ""
    for attempt in (1, 2):
        node, model, held = claim_first_free_role(cfg, state, [4])
        if node is None:
            sys.stderr.write("  no floor-4 model free to reconsider the "
                             "approach\n")
            return ""
        try:
            with hold_or_wait(state, node, model, held):
                window = swarm.pick_num_ctx(
                    cfg, node, model, swarm.est_tokens(prompt), 1200,
                    reasoning=False)
                reply = swarm.chat_complete(
                    node, model, [{"role": "user", "content": prompt}],
                    num_ctx=window, answer_tokens=1200, headroom=1.5,
                    think=False, temperature=0.1, timeout=600)
            state.record_perf(node.name, model, reply["sample"])
            text = reply.get("text") or ""
            break
        except swarm.OllamaError as exc:
            sys.stderr.write("  approach call failed: %s\n" % exc)
            if attempt == 2:
                return ""
            sys.stderr.write("  asking for the approach once more\n")
    allowed = set(blamed)
    found: Dict[str, str] = {}
    current = None
    buf: List[str] = []

    def flush() -> None:
        nonlocal current
        body = "\n".join(buf).strip()
        body = re.sub(r"^APPROACH:\s*", "", body).strip()
        if (current and len(body) >= 40
                and not re.search(r"ignore the check|check is wrong|"
                                  r"check is incorrect|disregard the check",
                                  body, re.I)):
            found[current] = body
        current = None

    for line in text.splitlines():
        match = re.match(r"FILE:\s*(\S+)", line.strip())
        if match:
            flush()
            name = os.path.basename(match.group(1))
            current = name if name in allowed else None
            buf = []
            continue
        if current is not None:
            buf.append(line)
    flush()
    if not found:
        sys.stderr.write("  approach reply was unusable; repairing from "
                         "the check alone\n")
        return ""
    out = "CLASS:\n%s\n\n%s" % (
        _class_key(shared),
        "\n\n".join("FILE: %s\n%s" % (name, body) for name, body in found.items()))
    try:
        os.makedirs(os.path.join(root, ".ralph"), exist_ok=True)
        if tried:
            with open(tried_path, "w", encoding="utf-8") as fh:
                fh.write(tried)
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(out)
    except OSError as exc:
        sys.stderr.write("  could not save the approach: %s\n" % exc)
        return ""
    for name in found:
        sys.stderr.write("  approach for %s\n" % name)
    return ("The last repair left the same failure class. Build the file "
            "this way instead. Every failure line still has to be met:\n\n"
            + out)


def cmd_between(args, cfg: swarm.Config, state: swarm.State) -> int:
    """One floor-4 note after a round, while no writer is holding the box."""
    root = os.path.abspath(getattr(args, "dir", None) or ".")
    stuck_approach(root, getattr(args, "check", None) or "", cfg, state)
    return 0


def narrow_to_check(components: List[intent.Component], root: str,
                    command: str = "") -> List[intent.Component]:
    """Drop components the last check failure does not name.

    A failure that names nothing falls back to the files the check script
    loads. Returns the original list when that is also empty, or when
    narrowing would leave no component at all. Dependencies on a dropped
    component are removed so the kept file is not left waiting on work that
    will not run.
    """
    try:
        with open(os.path.join(root, ".ralph", "last-check.txt"),
                  encoding="utf-8", errors="replace") as fh:
            raw = fh.read()
    except OSError:
        return components
    if not raw.strip() or not components:
        return components
    named = set(blame_for_check(root, raw, command)[0])
    if not named:
        return components
    kept = [c for c in components if os.path.basename(c.path) in named]
    if not kept:
        return components
    alive = {c.name for c in kept} | {c.path for c in kept}
    for c in kept:
        c.deps = [d for d in c.deps if d in alive]
    return kept


def build_components(request: str, cfg: swarm.Config, state: swarm.State,
                     context: str = "", verbose: bool = True,
                     root: str = "",
                     reconsider_api: Optional[Callable[[], Optional[str]]] = None
                     ) -> List[intent.Component]:
    """Ask a capable model to split a programming task into parallel files.

    A component that fails gets a rich ladder below (repair attempts, a
    whole-loop restart, model escalation, a CONTRACT replan) -- planning
    itself, until now, got exactly one roll: a busy node timing out, or a
    reply that never parsed into a single usable component, fell straight
    through to "could not decompose; falling back to a single file" with
    nothing tried again. Measured live: a planner call landed on a
    demoted floor-2 model (the `claim_first_free_role` regression
    documented elsewhere in this file) and failed to decompose outright,
    with no second attempt at any point.

    So this is `_decompose_once` retried up to `PLAN_RETRIES` times, only
    while it keeps coming back empty. Each retry re-runs
    `claim_first_free_role` from scratch rather than reusing whatever node
    the failed attempt held, so a node that was busy or wedged on attempt 1
    is not necessarily the one attempt 2 lands on -- the same reasoning
    `pick_role_candidates` already uses to spread parallel planners across
    the fleet. Stops as soon as one attempt returns something usable;
    three straight empty attempts is treated the same as before (the
    caller's own "could not decompose" fallback), just no longer on the
    strength of a single roll.

    That reasoning alone was not enough for a node that is not merely busy
    but genuinely unreachable, which is a fact this loop used to forget
    between attempts. Measured live, across two separate chain steps in
    the same batch: `g26b` was down (`cannot reach
    http://10.0.0.190:11434/api/chat: [Errno 60] Operation timed out`), and
    because it is the fleet's highest-quality floor-4 candidate,
    `pick_role_candidates` ranked it first on every one of 3 straight
    attempts -- each one claimed it (the claim succeeds; only the network
    call fails), timed out after ~60s, released the claim on the way out,
    and the *next* attempt saw the identical "free, highest quality" node
    and picked it again. ~180s spent proving the same fact three times,
    for a request with no `--api` that then failed outright with "give
    --out for a single-file build" once decomposition gave up. So a node
    that raises `swarm.OllamaError` mid-attempt is added to `exclude_nodes`
    and never offered again for the rest of *this* `build_components`
    call -- `mac` and `e4b-linux` are both genuine floor-4 candidates too,
    and never got a turn until this existed.

    `reconsider_api`, when given, is called between failed attempts (never
    after a success, and never on the last attempt -- there is no further
    roll left to spend it on). It owns the decision of whether the API
    slice looked starved or bloated and, if so, returns a replacement
    `context` string to use for the next attempt; `None` means leave
    `context` alone. Kept as a caller-supplied callback rather than
    `openapi` logic living here, so this function stays ignorant of
    `--api` entirely, the same boundary `cmd_do` already draws everywhere
    else the slice is built and consumed.
    """
    components: List[intent.Component] = []
    exclude_nodes: Set[str] = set()
    for attempt in range(1, PLAN_RETRIES + 1):
        components = _decompose_once(request, cfg, state, context, verbose,
                                     root, exclude_nodes=exclude_nodes)
        if components:
            return components
        if attempt < PLAN_RETRIES:
            if verbose:
                sys.stderr.write(
                    "  planning attempt %d produced nothing usable -- "
                    "retrying (%d of %d)\n" % (attempt, attempt + 1, PLAN_RETRIES))
            if reconsider_api is not None:
                new_context = reconsider_api()
                if new_context is not None:
                    context = new_context
    return components


def _decompose_once(request: str, cfg: swarm.Config, state: swarm.State,
                    context: str = "", verbose: bool = True,
                    root: str = "",
                    exclude_nodes: Optional[Set[str]] = None,
                    ) -> List[intent.Component]:
    """One planning attempt. See `build_components` for the retry wrapper.

    The planner is told how many machines are waiting, because the shape of
    the plan decides utilisation and it cannot know the pool size otherwise.
    Left unsaid, it produced a four-deep chain for an expression evaluator
    and three of four boxes never ran a single task.

    `root` is only needed for `intent.parse_components` to recognise a
    dependency naming a file already on disk rather than another component
    in this same plan -- passed through here, not used directly.

    `exclude_nodes`, when given, is both read and written: nodes named in
    it are skipped by `claim_first_free_role` below, and a node that turns
    out to be genuinely unreachable this attempt (a raw `swarm.OllamaError`,
    as opposed to an ordinary busy/queued wait) is added to it before
    returning, so `build_components`'s retry loop never lands on it again.
    See that function's own docstring for the live failure this exists for.
    """
    # Floor 4 only. A dropped P40 chat used to fall through to the 4B, and
    # that model then owned the plan. A retry below asks the same floor
    # again rather than a weaker one.
    node, model, held = claim_first_free_role(cfg, state, [4],
                                              exclude_nodes=exclude_nodes)
    if node is None:
        return []
    # `claim_first_free_role` may have already claimed the node above (the
    # ordinary case now). Everything below, up to the `with hold_or_wait`
    # block that owns the release, has to run inside a try/except that
    # releases on the way out -- otherwise an exception in here (pick_solvers,
    # a bad prompt format) would leak the claim for the rest of this
    # process's life, since nothing else would ever call release_node for it.
    try:
        restrict = cfg.data.get("team", {}).get("restrict_to_family")
        strong_pool = pick_solvers(cfg, state, 4, count=4, family=restrict)
        all_pool = pick_solvers(cfg, state, 1, count=6, family=restrict)
        strong = max(1, len(strong_pool))
        workers = max(strong, len(all_pool))
        # The planner decides the shape of everything downstream, so it is
        # the one call where project conventions are most worth the tokens.
        context = (context or "") + project_context(request)
        prompt = intent.DECOMPOSE_PROMPT.format(
            request=request, context=context, workers=workers, strong=strong,
            light=max(1, workers - strong), idle=max(1, workers - 1),
            is_are="is" if strong == 1 else "are")
        if verbose:
            sys.stderr.write("planning on %s/%s...\n" % (node.name, model))
    except Exception:
        if held:
            state.release_node(node.name)
        raise

    # The same growth rule `codegen` uses, for the same reason and against a
    # worse failure. A plan cut off mid-emission does not look broken: the
    # components before the cut parse perfectly and the run proceeds on a
    # fraction of the work, so a request for a page and a script came back
    # as one client module and nobody was told why. Ollama reports the cut,
    # so this is a fact rather than a guess.
    #
    # The window is sized for the ceiling up front, since growing the answer
    # cap inside a window that has to change would cost a model reload.
    # A plan is short, structured and capped at five components, so the cap
    # is not a quality dial here the way it is for a writer -- it is only a
    # bound on emission, and nothing is charged for room that goes unused.
    # Starting tight was copied from `codegen`, where growth-on-proof stops
    # a repair loop writing ever longer files, and the trade is backwards
    # for planning: a cut costs a whole second round trip of ~50s against
    # nothing at all for a ceiling that is never reached.
    try:
        budget, ceiling = PLAN_TOKENS, PLAN_TOKENS_MAX
        window = swarm.pick_num_ctx(cfg, node, model, swarm.est_tokens(prompt),
                                    ceiling, reasoning=False)
    except Exception:
        if held:
            state.release_node(node.name)
        raise
    text = ""
    # Claimed for the whole retry loop, not per request. This used to be the
    # only thing protecting concurrent planners at all, back when
    # `pick_role_model(4)` had exactly one possible answer (`g26b` was the
    # only capability-4 node) -- every parallel `team do` process resolved
    # to the same node deterministically, so without a claim they would
    # fire concurrent HTTP requests at it with no coordination. That is
    # still true and still the reason this claim exists; what changed is
    # that `pick_role_model` can now return *different* nodes to different
    # callers (busy-then-quality-then-latency, see its docstring), so this
    # claim's job is no longer "the only line stopping every process from
    # colliding on one node" -- it is "stop two requests that did resolve
    # to the same node from swapping its model out from under each other,"
    # which is the ordinary reason `node_claim` exists everywhere else it
    # is used.
    #
    # `state.acquire_lease`/`release_lease` around the actual request below
    # is the other half of that fix: `pick_role_model`'s busy check reads
    # `state.load_for`, which only reflects a real in-flight request if
    # something registered one. Nothing did for `do`/`code`'s planner or
    # writer calls before this -- `load_for` reported 0 in-flight for every
    # node regardless of how many concurrent processes were actually
    # hammering it, which is exactly how six parallel processes all judged
    # the same warm node "free" at once.
    def _on_wait(name: str, _model: str) -> None:
        if verbose:
            # This message used to hardcode "the one node every team do
            # process shares for planning" from when `g26b` really was
            # the only floor-4 candidate in the whole fleet -- true then,
            # false the moment a second floor-4 node exists, and stale
            # prose asserting the opposite of what the live config says
            # is exactly the failure this project has fixed by reading
            # the fact off the config directly more than once already
            # (see `other_floor4_nodes`). Recomputed here rather than
            # cached, since the fleet's shape (which nodes are enabled,
            # which models are floor-4) can change between calls.
            others = len(pick_role_candidates(
                cfg, state, 4, restrict, exclude_nodes=exclude_nodes)) - 1
            if others > 0:
                extra = (" -- %d other floor-4 node(s) exist and were "
                        "tried first; every one of them happened to be "
                        "busy at the same instant" % others)
            else:
                extra = (" -- this is the only floor-4 node in the "
                        "fleet right now, so every parallel invocation "
                        "queues here")
            sys.stderr.write(
                "  %s is planning something else right now; waiting "
                "for it%s...\n" % (name, extra))

    with hold_or_wait(state, node, model, held, on_wait=_on_wait):
        planner_retried = False
        while True:
            _pf, _decode, _cold = rates(cfg, state, node, model)
            lease = state.acquire_lease(
                node.name, model, _cold + budget / max(_decode, 1.0))
            try:
                r = swarm.chat_complete(
                    node, model, [{"role": "user", "content": prompt}],
                    num_ctx=window,
                    # Reasoning off: this emits a fixed structured form, not
                    # an argument. The same switch took audit adjudication
                    # from 63.9s to 3.5s with identical verdicts, and a
                    # planner that costs four minutes before any code is
                    # written defeats the purpose.
                    # This used to be 300s on the theory that planning is a
                    # short structured emission, so anything longer meant the
                    # node was wedged and failing fast beat stalling the run.
                    # That reasoning missed a real case: `node_claim` above
                    # only serializes *planning* requests against each other
                    # across parallel `do` processes -- it has no visibility
                    # into g26b being legitimately busy generating a real
                    # floor-4 component for a write phase that now runs
                    # several `team do` steps in parallel (see LOCAL.md).
                    # Measured live: a hard-tier component with repairs can
                    # run well past five minutes, so a planner call queued
                    # behind one was failing the *entire* request outright
                    # ("could not decompose; falling back to a single file")
                    # rather than degrading gracefully the way the
                    # best-effort ground/decompose_actions calls do -- there
                    # is no fallback here worth having, only a hard abort.
                    # Raised to match: a genuinely wedged node (no runner
                    # progress, expires_at not advancing, checkable with
                    # `curl .../api/ps`) is still detectable by the operator
                    # directly; this client-side timeout no longer needs to
                    # be the only thing standing in for that check.
                    answer_tokens=budget, headroom=1.8, think=False,
                    temperature=0.1, timeout=3600)
                state.record_perf(node.name, model, r["sample"])
                state.mark_resident(node.name, model)
            except swarm.OllamaError as exc:
                # Errno 57 on the first chat of a round is a dropped socket,
                # and the retry already in the caller then succeeds. Returning
                # here printed "restart Ollama" for a call the next attempt
                # completed. One retry stays on this claim; the second failure
                # is the one worth telling the operator about.
                if not planner_retried:
                    planner_retried = True
                    sys.stderr.write("  planner call dropped (%s); trying "
                                     "once more\n" % exc)
                    continue
                sys.stderr.write(
                    "planner failed: %s\n"
                    "  %s answered /api/tags but not /api/chat, which usually\n"
                    "  means its runner is still working through an earlier\n"
                    "  request. Check with: curl -s %s/api/ps\n"
                    "  If expires_at tracks the current clock, it is busy;\n"
                    "  restart Ollama on that box to clear it.\n"
                    % (exc, node.name, node.url))
                return []
            finally:
                state.release_lease(lease)
            text = r["text"]
            cut = (r.get("raw") or {}).get("done_reason") == "length"
            if not cut or budget >= ceiling:
                break
            budget = min(budget * 2, ceiling)
            if verbose:
                sys.stderr.write("  the plan was cut off; retrying with room "
                                 "for %d tokens\n" % budget)

    components = intent.parse_components(text, root)
    orphans = intent.unbuilt_contract_files(text, components)
    if orphans and verbose:
        # Decidable from the two halves of the planner's own reply, so it is
        # decided here rather than discovered when the run finishes short.
        sys.stderr.write(
            "  warning: the contract names %s, which no component writes.\n"
            "  The plan is probably incomplete -- re-run, or name the files\n"
            "  you want in the request.\n" % ", ".join(orphans))

    output_helpers = intent.output_only_components(components)
    if output_helpers and verbose:
        # A dedicated output-saving file has no literal "output.json" in
        # its own source when written the natural, reusable way -- see
        # `output_only_components`'s own doc for the live failure this
        # names ahead of time instead of after 3 rungs of repair.
        sys.stderr.write(
            "  warning: %s is planned as a dedicated output.json helper.\n"
            "  This shape almost always fails gate_missing_own_output_write\n"
            "  no matter how many times it is rewritten -- fold the write\n"
            "  into whichever component produces the value instead.\n"
            % ", ".join(output_helpers))

    unrequested = intent.unrequested_client_split(components, request)
    if unrequested and verbose:
        # Named from the file, not the spec: see `unrequested_client_
        # split`'s own doc for the live shape (project_api_client.py,
        # task_api_client.py planned against a request that only ever
        # said "create an applet"). Advisory, not blocking -- a domain
        # word phrased differently in the request than in the filename
        # is a real possibility this check cannot tell apart from actual
        # scope creep, so it says so and lets the operator decide.
        sys.stderr.write(
            "  warning: %s %s named after a resource (%s) this request "
            "never mentions.\n"
            "  This is the exact shape of building one client per tag "
            "heading in the endpoint\n"
            "  index instead of only what the task asks for -- check "
            "before spending pool time on it.\n"
            % (", ".join(n for n, _ in unrequested),
               "is" if len(unrequested) == 1 else "are",
               ", ".join(sorted({w for _, w in unrequested}))))

    # An orphaned name is sometimes not a truncated plan but a stale one: a
    # `.py` clause left over from a draft that named a Python generator,
    # after the plan itself moved to a different, non-Python asset for that
    # same file. Prose warning the operator about it did not stop a writer
    # from acting on the stale clause -- measured live, `main.py` followed
    # a CONTRACT saying `applet.py owns generate_applet_html()`, hit an
    # ImportError against a file that was never going to exist, and shipped
    # a hardcoded fallback instead of the real `applet.html` it was also
    # correctly told (by `dependency_context`) to read from disk. So this
    # is corrected mechanically before any writer's prompt is built, not
    # merely reported.
    if components:
        fixed_contract = intent.reconcile_contract_assets(
            components[0].contract, components)
        if fixed_contract != components[0].contract:
            if verbose:
                sys.stderr.write(
                    "  contract named a .py module for a file actually "
                    "planned as a different type; corrected before writers "
                    "see it.\n")
            for c in components:
                c.contract = fixed_contract

        # A self-less function nested under a class's `with` clause is a
        # coin flip -- one writer implements it as a bound method, the
        # dependent calls it as a module-level name, and the mismatch is
        # invisible until the dependent's own gate fails. Asking the
        # planner not to do this (DECOMPOSE_PROMPT) has already been tried
        # and ignored on the exact request that motivated the ask, so this
        # is corrected mechanically, the same way a stale asset clause is.
        hoisted_contract = intent.hoist_selfless_members(
            components[0].contract)
        if hoisted_contract != components[0].contract:
            if verbose:
                sys.stderr.write(
                    "  contract nested a self-less function under a "
                    "class's `with` clause; moved it to its own line "
                    "before writers see it.\n")
            for c in components:
                c.contract = hoisted_contract

    doubled = intent.duplicate_entry_points(text, components)
    if doubled and verbose:
        # Costly rather than merely untidy: the extra entry point depends on
        # the other, so it runs alone at the tail while every other box idles.
        sys.stderr.write(
            "  warning: %s are both entry points, so they cannot run at the\n"
            "  same time. Ask for one, or name the files you want.\n"
            % " and ".join(doubled))

    # An entry point that came back with a totally empty DEPS field, next
    # to a CONTRACT that names other files' owned symbols, silently loses
    # every mechanical check built to catch it: dependency_context hands it
    # no real dependency source, gate_uses/gate_interfaces have nothing to
    # check (an empty deps list makes dep_modules/dep_paths return {}/[],
    # and both gates are skipped on a falsy input), and the writer is free
    # to invent a self-contained fake in place of the real client. See
    # `intent.backfill_entry_point_deps` for the live run that motivated
    # this.
    fixed_entry = intent.backfill_entry_point_deps(components)
    if fixed_entry and verbose:
        entry = next(c for c in components if c.path == fixed_entry)
        sys.stderr.write(
            "  warning: the entry point (%s) came back with no declared "
            "dependencies, even though the CONTRACT names other files' "
            "owned symbols; wiring it to %s so the real files are handed "
            "over instead of reinvented.\n"
            % (fixed_entry, ", ".join(entry.deps)))

    fixed_labels = reinforce_output_labels(components, request)
    if fixed_labels and verbose:
        sys.stderr.write(
            "  the request demonstrated an exact print format (%s) that "
            "the plan's own SPEC did not repeat verbatim; restated it on "
            "%s before writers see it.\n"
            % (" ".join(codegen.output_labels(request)), fixed_labels))

    serial_link = intent.low_parallelism_note(request, components)
    if serial_link and verbose:
        sys.stderr.write(
            "  note: this is a single-component step that reads a sibling\n"
            "  step's output (%s) -- it is one link in a serial chain and\n"
            "  cannot gain anything from running on a pool, whatever the\n"
            "  plan looks like. If nothing else in this same chain can run\n"
            "  at the same time, writing this one file directly (by hand,\n"
            "  or by asking a single model in a tighter loop) will very\n"
            "  likely be faster than the plan/contract/gate cycle below.\n"
            % serial_link)
    return components


def reinforce_output_labels(components: List[intent.Component],
                            request: str) -> Optional[str]:
    """A prompt is not the same thing as a fact the model actually acted on.

    The operator's own request already said, in English, "prints the task
    id like Project Link: Task ID: Project ID" -- and the planner rewrites
    that into its own paraphrase for the entry point's SPEC, which is free
    to drop the exact wording even when it keeps the intent. Measured live:
    the generated file printed four bare UUIDs with no labels at all,
    twice, on a request that could not have been more explicit about
    wanting them. `codegen.gate_smoke` is the actual enforcement (it reads
    these same labels back out of the SPEC and fails the file if the
    printed output does not carry them) -- this is what makes sure the
    literal words survive into the SPEC text that gate reads, regardless of
    what the planner's paraphrase kept.

    The appended sentence has to satisfy `codegen.output_labels` itself,
    not just read correctly to a person: `generate_file` re-derives its own
    `required_labels` from this exact spec text, which only reads a chain
    immediately after the word "like"/"as". An earlier draft of this
    sentence explained the requirement clearly and never used either word,
    so `output_labels` read it back as zero labels -- meaning the one case
    this fixup exists for (the planner's SPEC dropping the operator's
    literal wording) was also the one case where `gate_smoke` never
    actually checked for it. Returns the entry path if it changed
    anything, so a caller can tell the operator, or None.
    """
    labels = codegen.output_labels(request)
    entry_path = intent.plan_entry_point(components)
    if not labels or not entry_path:
        return None
    entry = next((c for c in components if c.path == entry_path), None)
    if entry is None or all(lbl in entry.spec for lbl in labels):
        return None
    entry.spec += (
        "\n\nThe output must print exactly these labels, verbatim, "
        "immediately before the value each one introduces -- print it "
        "like %s" % " ".join(labels))
    return entry_path


def dep_modules(component: intent.Component, done: Dict[str, intent.Component],
                root: str) -> Dict[str, List[str]]:
    """Modules this component was handed, and the names each one actually offers.

    Only dependencies that were actually written count. A component whose
    dependency failed has nothing to import, and demanding it anyway would fail
    a file for someone else's error.
    """
    out: Dict[str, List[str]] = {}
    for dep in component.deps:
        built = done.get(dep)
        if built is None or not getattr(built, "ok", False):
            continue
        name = os.path.basename(built.path)
        if not name.endswith(".py") or name == "__init__.py":
            continue
        out[name[:-3]] = public_names(os.path.join(root, built.path))
    return out


def dep_paths(component: intent.Component,
              done: Dict[str, intent.Component]) -> List[str]:
    """Relative paths of this component's dependencies that actually exist.

    Feeds `codegen.gate_interfaces`, which needs real files on disk to check
    against -- the same restriction `dep_modules` already applies for the
    same reason: a dependency that failed has nothing to be checked against,
    and demanding it anyway would fail this file for someone else's error.
    """
    return [done[dep].path for dep in component.deps
            if done.get(dep) is not None and getattr(done[dep], "ok", False)]


def why(error: str, width: int = 68) -> str:
    """The one line of a failure worth putting in a summary table.

    Truncating the raw text does not work, because a gate reports its headline
    first and the reason underneath: `importing main.py failed:` fills the
    column and the traceback below it -- the only part naming the actual defect
    -- is cut. Every failed component in a night of runs therefore printed a
    colon and nothing else, and each one had to be reproduced by hand to learn
    what went wrong. A traceback's last line is the exception, which is exactly
    the summary wanted.
    """
    lines = [ln.strip() for ln in (error or "").splitlines() if ln.strip()]
    if not lines:
        return "(no reason recorded)"
    head = lines[0].rstrip(":")
    if len(lines) == 1:
        return head[:width]
    tail = next((ln for ln in reversed(lines)
                 if not ln.startswith("File \"") and ln != "^"), lines[-1])
    stage = head.split(":", 1)[0]
    return ("%s: %s" % (stage, tail))[:width]


def public_names(path: str) -> List[str]:
    """The top-level classes, functions and constants a file offers importers."""
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            tree = ast.parse(fh.read())
    except (OSError, SyntaxError):
        return []
    names: List[str] = []
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef,
                             ast.ClassDef)):
            if not node.name.startswith("_") and node.name != "main":
                names.append(node.name)
        elif isinstance(node, ast.Assign):
            for target in node.targets:
                if (isinstance(target, ast.Name) and target.id.isupper()
                        and not target.id.startswith("_")):
                    names.append(target.id)
    return names


def _can_take(worker_floor: int, component_floor: int) -> bool:
    """Whether a worker polling `worker_floor` can ever claim this component.

    Mirrors the claim loop exactly: a worker takes its own floor, and the
    strong pool additionally falls back to routine work when its own tier is
    drained. Anything else it will never see, so it must not be waited for.
    """
    if worker_floor == component_floor:
        return True
    return worker_floor == 4 and component_floor == 2


def resolve_run_target(explicit_file: Optional[str],
                       restored: List[intent.Component]) -> Optional[str]:
    """Which file `--retry --run` should execute when the operator did not
    name one with `--file`.

    Split out from `cmd_do` so the decision -- explicit name wins, else the
    plan's own structural entry point, else give up -- is testable without
    driving the whole CLI (a subprocess, argparse, a saved plan on disk) just
    to check a fallback. Delegates to `intent.plan_entry_point`, the same
    structural reading `ownership_note` already trusts, rather than a second
    guess at what "the entry point" means.
    """
    return explicit_file or intent.plan_entry_point(restored)


def run_and_capture(root: str, target_file: str, timeout: float = 120.0
                    ) -> Tuple[Optional[int], str]:
    """Actually execute `target_file` in `root`, with the operator's real
    environment, and return (exit_code, combined_output).

    This exists so `--run` never asks the operator to paste a traceback at
    all -- the failure this project's own `--error @file` convention was
    already built to make less painful to hand over, one step further: text
    that goes straight from one process's pipe to another's argument never
    passes through a shell, so there is nothing in it -- an embedded `"`,
    a curly quote, a JSON body's own quoting -- for the operator to clean or
    for the shell to mis-parse. Measured live: a real 422 body nested
    `` `urn:uuid:` `` inside a quoted string inside a quoted traceback,
    which is exactly the shape that breaks by hand and never reaches this
    function differently.

    `env=os.environ.copy()` is deliberate and is the opposite instinct from
    every gate in `codegen.py`: those exist to keep generated code away from
    the real service while it is still unproven, but this call only ever
    runs *after* a component passed every one of those gates, and the whole
    point of `--run` is to observe it against the real credentials and the
    real API the same way the operator just did by hand.

    A timeout returns `(None, "")` rather than raising, so a hang (most
    likely code waiting on `input()` that the operator's terminal would
    have supplied) is reported as a timeout instead of surfacing as an
    unhandled exception in the CLI.
    """
    try:
        # stdin is explicitly closed rather than inherited: stdout is
        # captured into a pipe rather than shown live, so a script that
        # printed a prompt and waited on the operator's terminal would
        # look identically hung either way -- closing it turns that into
        # an immediate, reportable `EOFError` instead of a real wait, which
        # is the right failure for the case this exists for (an automation
        # script that is not supposed to be interactive in the first place).
        proc = subprocess.run([sys.executable, target_file], cwd=root,
                              env=os.environ.copy(), stdin=subprocess.DEVNULL,
                              stdout=subprocess.PIPE,
                              stderr=subprocess.STDOUT, text=True,
                              timeout=timeout)
    except subprocess.TimeoutExpired:
        return None, ""
    return proc.returncode, proc.stdout


# `requests.Response.raise_for_status()` always formats a 5xx as
# "{code} Server Error: {reason}" -- this is `requests`' own literal
# wording, not something a writer chooses, so matching on it exactly is
# not a guess about phrasing. Deliberately 502/503/504 only, not the
# wider 5xx range: those three are specifically "the gateway/proxy in
# front of the real service could not get a timely answer", which is
# true regardless of what the request contained, while a bare 500 is
# usually the application itself raising on the request it was actually
# given and is not safe to wave off as "just retry the same bytes".
_TRANSIENT_GATEWAY_RE = re.compile(r"\b50[234] Server Error\b")


def run_with_gateway_retry(root: str, target_file: str,
                          max_retries: int = 3,
                          sleep: Callable[[float], None] = time.sleep
                          ) -> Tuple[Optional[int], str, int]:
    """`run_and_capture`, plus: if the real run failed with a 502/503/504,
    just run the identical script again -- unchanged, no model, no
    repair attempt -- since that status means the platform's own
    gateway/proxy failed to get a timely answer from its origin, which
    says nothing about whether the request was correct. Returns
    (code, output, retries_used) so a caller can report how many extra
    attempts this took.

    `sleep` is injectable so a test can assert the retry actually
    happened without a real process waiting through real backoff.
    """
    code, output = run_and_capture(root, target_file)
    retries = 0
    while (code is not None and code != 0
           and looks_like_transient_gateway_error(output)
           and retries < max_retries):
        retries += 1
        sleep(2 ** retries)
        code, output = run_and_capture(root, target_file)
    return code, output, retries


def looks_like_transient_gateway_error(output: str) -> bool:
    """True if `output` (real captured stdout+stderr from actually
    running a step) shows a 502/503/504 -- CloudFront/a load balancer/a
    proxy failing to get a timely answer from the real origin, not
    anything the request itself did wrong. Measured live:
    `07_update_project` PATCHed a project with exactly the right
    `applet_version_id` payload -- the same shape that succeeded in
    every other run -- and got back a literal CloudFront error page
    ("504 Server Error: Gateway Timeout ... Generated by cloudfront")
    for a request CloudFront never even got a real answer to. Feeding
    that into the model repair loop would have it rewrite code that was
    never wrong; the actual fix is running the exact same script again a
    moment later, no different from what an operator seeing this by hand
    would do.
    """
    return bool(_TRANSIENT_GATEWAY_RE.search(output))


# `AppletVersionCreate.version` (and every field this project's own
# `openapi._VERSION_FIELD_MARKER` already treats specially at generation
# time -- see its docstring) is, by convention, expected to be unique
# per parent. The real platform's own rejection names the exact
# colliding value in its response body: `{"detail":"Version '1.0.0'
# already exists for this applet"}`. That is not a hint to re-read the
# code, it is the fix, sitting in plain text: the literal that collided
# is right there, and generating a fresh one and resending is strictly
# mechanical -- no model needed to notice that a string equal to
# something the server just said already exists should not be sent
# again unchanged.
_VERSION_CONFLICT_RE = re.compile(
    r"[Vv]ersion\s+['\"]([^'\"]+)['\"]\s+already exists")


def looks_like_version_conflict_error(output: str) -> Optional[str]:
    """The exact conflicting literal, if `output` (real captured
    stdout+stderr from actually running a step) shows the real
    platform's own "Version 'X' already exists ..." shape -- `None`
    otherwise.

    Matched on the API's own exact wording, the same way
    `looks_like_transient_gateway_error` matches `requests`' own exact
    "502 Server Error" phrasing rather than guessing at what a timeout
    might look like -- this is a fact read off a real response body, not
    a guess about phrasing.
    """
    m = _VERSION_CONFLICT_RE.search(output)
    return m.group(1) if m else None


def _replace_literal_in_source(source: str, old_value: str,
                                new_value: str) -> Tuple[str, int]:
    """Replace every quoted occurrence of `old_value` as a whole Python
    string literal (single- or double-quoted, the full literal, never a
    substring of a longer one) with `new_value`, quoted the same way.

    Returns the rewritten source and how many occurrences were replaced.
    Zero means the literal could not be safely located as its own quoted
    token -- the value may be built dynamically, split across an
    f-string, or concatenated -- and the caller must not treat that as a
    fix; guessing at a looser edit here risks corrupting a file this
    mechanism has no gate to verify afterwards.
    """
    pattern = re.compile(r'(["\'])%s\1' % re.escape(old_value))
    count = 0

    def _sub(m: "re.Match") -> str:
        nonlocal count
        count += 1
        return m.group(1) + new_value + m.group(1)

    new_source = pattern.sub(_sub, source)
    return new_source, count


def run_with_version_conflict_retry(
        root: str, target_file: str, max_retries: int = 3,
        sleep: Callable[[float], None] = time.sleep,
        new_uuid: Callable[[], str] = lambda: str(uuid.uuid4())
        ) -> Tuple[Optional[int], str, int]:
    """`run_and_capture`, plus: if the real run failed because a
    hardcoded version-like literal collided with one the real platform
    already has, replace that exact literal in the file's own source
    with a freshly generated UUID and run it again -- no model, no
    repair attempt, no regeneration.

    This is deliberately reactive rather than a preemptive static gate:
    a gate that failed the file for containing *any* hardcoded literal
    in a field named `version` would also fail a file whose request
    genuinely specified that exact version on purpose, forcing a
    regeneration for code that was correct. Waiting for the real
    platform to actually reject the value settles the question with no
    guessing at all -- the rejection itself is the proof, and the
    response body already names precisely what to change.

    Unlike `run_with_gateway_retry`, a version conflict is not transient:
    resending the identical bytes fails identically forever, so this
    mutates `target_file` on disk (backed up first, exactly the way
    `generate_file` backs up before every overwrite) rather than merely
    rerunning it unchanged. A fresh `uuid.uuid4()` is used rather than an
    incremented suffix -- collision-free with no need to read what
    versions already exist, and simpler than parsing the old value's
    shape to bump it.

    If the literal cannot be found verbatim as its own quoted token, or a
    second attempt collides again, this stops immediately at whatever
    `max_retries` allows and returns the (still-failing) result unchanged
    -- the existing model repair loop is the fallback for a case this
    mechanism could not safely resolve on its own, and the caller is
    expected to tell that loop exactly what was already tried.
    """
    full_path = os.path.join(root, target_file)
    code, output = run_and_capture(root, target_file)
    retries = 0
    while code is not None and code != 0 and retries < max_retries:
        conflicting = looks_like_version_conflict_error(output)
        if not conflicting:
            break
        try:
            with open(full_path, encoding="utf-8") as fh:
                source = fh.read()
        except OSError:
            break
        new_source, hits = _replace_literal_in_source(
            source, conflicting, new_uuid())
        if hits == 0:
            break
        backup = codegen.backup_path(full_path)
        os.makedirs(os.path.dirname(backup), exist_ok=True)
        shutil.copy2(full_path, backup)
        with open(full_path, "w", encoding="utf-8") as fh:
            fh.write(new_source)
        retries += 1
        sleep(1)
        code, output = run_and_capture(root, target_file)
    return code, output, retries


def cmd_fix_version_conflict(args, cfg: swarm.Config, state: swarm.State
                             ) -> int:
    """CLI entry point for `run_with_version_conflict_retry`, callable
    directly from bash with no `team do` machinery around it.

    This exists because `orchestrate.sh`'s own `run_step()` executes a
    finished component with a bare `python3 main.py` -- never through
    `team.py` -- for both its first real attempt and every retry after a
    `team do --retry --run` self-repair. `run_with_version_conflict_retry`
    only ever runs *inside* `cmd_do`'s own `--run` handling, so a version
    conflict that only manifests on one of `run_step`'s own bare
    invocations (for instance because an earlier, unrelated bug was
    masking the real response body the one time `team do --run` itself
    captured live output) had no way to reach the mechanism that exists
    specifically to fix it. Measured live: a swallowed-exception bug hid
    the true "Version '1.0.0' already exists" response from `team do
    --retry --run`'s own probe, which duly fixed the swallowed exception
    and moved on -- and the *next* bare `python3 main.py`, run straight
    from bash, hit the exact conflict this function exists to resolve,
    with nothing whatsoever watching its output.

    This command is that missing watcher: run the file for real, and if
    the failure is a version-uniqueness conflict, replace the colliding
    literal with a fresh uuid and rerun, up to a few times, exactly as
    `cmd_do --run` already does -- with no model call, so `orchestrate.sh`
    can try this mechanical fix before spending a real repair attempt.
    """
    root = args.dir or os.getcwd()
    target = args.file
    code, output, retries = run_with_version_conflict_retry(root, target)
    if retries:
        print("%s: saw a version-already-exists rejection from the real "
              "API and replaced the colliding literal with a fresh uuid "
              "in the source %d time(s) -- no model or repair attempt "
              "spent" % (target, retries))
    if code == 0:
        print("%s: succeeded" % target)
        return 0
    if retries == 0:
        print("%s: no version-uniqueness conflict was found in the "
              "captured output -- nothing here for this mechanism to "
              "fix" % target)
    else:
        print("%s: still failing after %d mechanical uuid substitution(s)"
              % (target, retries))
    if output:
        sys.stderr.write(output if output.endswith("\n")
                         else output + "\n")
    return 1


def apply_operator_error(restored: List[intent.Component], file_path: str,
                         error_text: str
                         ) -> Tuple[Optional[str], Dict[str, str]]:
    """Force one already-passed component back into a --retry's work.

    A gate only ever proves "the mock accepted this" or "typed input did
    not crash it" -- an operator running the real file against the real
    service, with real input, can fail somewhere a gate structurally
    cannot see, and the saved plan then has nothing recorded to retry
    against, because nothing failed here.

    Matched to the saved plan by path so a made-up filename is caught
    before anything is touched, rather than being silently treated as
    already fixed. The matched component(s) are flipped to `ok = False`
    with `error` set to what the operator saw, which puts them through
    the exact same "a previous attempt failed; write it again avoiding
    that" path an ordinary failed component already goes through.

    The one thing that path does not do on its own is preserve the file:
    a normal retry's leftover is the broken attempt being replaced, so
    nothing carries it forward, but this file passed every gate and nobody
    asked for a rewrite, only a fix. Returned separately rather than
    written into `restored` directly, because that is `existing_code`'s
    job -- the same map an in-place edit already uses to keep everything
    a change does not mention.
    """
    target = os.path.normpath(file_path)
    hit = [c for c in restored if os.path.normpath(c.path) == target]
    if not hit:
        return ("no component in the saved plan writes %s" % file_path, {})
    additions: Dict[str, str] = {}
    for c in hit:
        if c.code:
            additions[os.path.normpath(c.path)] = c.code
        c.ok = False
        c.error = error_text.strip()
    return (None, additions)


def external_dependencies(components: List[intent.Component],
                          carried: List[intent.Component],
                          root: str) -> List[intent.Component]:
    """Stand-ins for on-disk files this plan depends on but is not writing.

    `intent.parse_components` now keeps a dependency naming an existing
    file, but keeping the name is not enough: the scheduler's readiness
    check is `all(d in done for d in c.deps)`, and `done` is only ever
    populated by components this run finishes -- a name that refers to a
    file nobody here is going to finish would never satisfy that, and the
    component depending on it would wait forever. Handing the pool a
    dependency it was told to have and then never letting anything claim
    it is worse than the silent drop this replaces.

    So each such name gets a `Component` that is already `ok`, carrying
    the file's real content read off disk right now -- the same thing
    `dependency_context` already does for a component another worker just
    finished, so a writer cannot tell the difference between a sibling
    file written five minutes ago in this run and one written last week.
    Never scheduled, never rewritten: `run_components` only ever adds
    these to `done`, and `pending` is built from `components` alone.
    """
    known = {c.name for c in components + carried}
    needed = sorted({d for c in components for d in c.deps
                     if d not in known})
    out: List[intent.Component] = []
    for name in needed:
        full = os.path.join(root, name)
        if not os.path.isfile(full):
            continue
        try:
            with open(full, encoding="utf-8", errors="replace") as fh:
                code = fh.read()
        except OSError:
            continue
        stub = intent.Component(name, name, 0, [], "")
        stub.code = code
        stub.ok = True
        out.append(stub)
    return out


MAVEN_APPLET_BOILERPLATE_PATH = os.path.join(
    swarm.CONTEXT_DIR, "maven-applet-boilerplate.html")


def maven_applet_boilerplate() -> str:
    """The reference applet scaffold, read verbatim from disk.

    This is not a scored card. `context/policy-applet-html.md` describes
    the iframe protocol in prose, and prose has already been shown to lose
    to a stale instruction sitting in the same prompt (the CONTRACT clause
    fixed above). A protocol this specific -- exact message field names
    (`unit`, not `unit_data`), the double-submit guard, the rework/QA
    pre-fill gate -- is cheaper to hand over as working code the writer
    edits than to describe and hope it is followed. Stored as a bare
    `.html` file rather than a `.md` card on purpose: `load_cards` only
    reads `.md`, so this never enters relevance scoring or competes with
    other cards for the summary-vs-full cutoff -- it is only ever injected
    by the one call site below that knows exactly when it applies.
    """
    try:
        with open(MAVEN_APPLET_BOILERPLATE_PATH, "r", encoding="utf-8") as fh:
            return fh.read()
    except OSError:
        return ""


def replan_component(request: str, contract: str, component: intent.Component,
                     done: Dict[str, intent.Component], cfg: swarm.Config,
                     state: swarm.State, root: str
                     ) -> Optional[Dict[str, str]]:
    """Ask whether a twice-failed component's CONTRACT or SPEC was the
    problem, not its code.

    A component that fails its own repair budget and then fails again after
    a whole-loop restart from a clean slate has survived two independent
    rolls against the same instructions. `gate_interfaces` already catches
    the shape this was built around -- a call to a method a dependency does
    not define -- fast and cheaply, one AST walk per attempt. What it cannot
    do is fix the plan when the CONTRACT itself never gave that method to
    anyone: measured live, a CONTRACT omitted a version-creating method
    entirely, so the entry point guessed at one and the client class had no
    reason to define it, and twelve attempts across two full passes produced
    twelve variations of the same unsatisfiable call.

    Grounded in the real, current source of every other already-built file
    in the package -- the same reason `dependency_context` hands real code
    rather than a description of it -- so the planner is judging against
    what actually exists, not against its own memory of what it originally
    asked for.

    Best-effort: no planner available, an Ollama error, or a reply that does
    not parse as a real fix all return None, which leaves the component's
    existing FAILED state exactly as it would have been without this.
    """
    node, model, held = claim_first_free_role(cfg, state, [4])
    if node is None:
        return None
    try:
        sources = []
        for c in done.values():
            if not (c.ok and c.name != component.name):
                continue
            try:
                with open(os.path.join(root, c.path), "r",
                         encoding="utf-8") as fh:
                    body = fh.read()
            except OSError:
                continue
            sources.append("--- %s ---\n%s" % (c.path, body[:4000]))
        prompt = intent.REPLAN_PROMPT.format(
            request=request or "(not recorded)", contract=contract or "NONE",
            path=component.path, spec=component.spec,
            history=component.error or "(no error recorded)",
            sources="\n\n".join(sources) or "(none)")
        window = swarm.pick_num_ctx(cfg, node, model, swarm.est_tokens(prompt),
                                    1200, reasoning=False)
    except Exception:
        # Same leak this guards against in `decompose`: an exception before
        # the node is ever handed to `hold_or_wait` would otherwise never
        # be released, since nothing else holds a reference to it.
        if held:
            state.release_node(node.name)
        raise
    try:
        # Same reason as `build_components`'s claim: this resolves to the
        # same single strongest node every time, so a parallel `team do`
        # invocation elsewhere replanning its own failed component would
        # otherwise race this one on the same physical GPU with no
        # coordination. `claim_first_free_role` above already tried every
        # eligible candidate non-blockingly; this only blocks if all of
        # them were genuinely busy.
        with hold_or_wait(state, node, model, held):
            r = swarm.chat_complete(
                node, model, [{"role": "user", "content": prompt}],
                num_ctx=window, answer_tokens=1200, headroom=1.5, think=False,
                temperature=0.1, timeout=180)
        state.record_perf(node.name, model, r["sample"])
    except swarm.OllamaError:
        return None
    return intent.parse_replan(r.get("text") or "", component.path)


def replan_request(request: str, contract: str,
                   components: List[intent.Component], cfg: swarm.Config,
                   state: swarm.State, root: str) -> Optional[str]:
    """Ask whether the REQUEST text itself -- not one component's CONTRACT
    or SPEC -- is the actual defect, after both the per-component ladder
    (`replan_component` included) and one whole-plan restart from the same
    request have already failed to produce a clean run.

    `cmd_do` already restarts decomposition from scratch once, against the
    unchanged request, when components still fail after full per-component
    repair (see the "restarting from planning" branch). That catches a bad
    roll of the decomposition dice -- a genuinely different CONTRACT drawn
    from the same, correct, request. It does not catch a request that is
    itself the problem: measured live, a chain step's own request named
    `output.json` with no path and no promise to write one, and no amount
    of re-decomposing that same sentence was ever going to produce a
    working step, because the sentence never said the one thing a working
    step needed to know. This is the rung above that: it fires only after
    the cheaper, narrower fix (`replan_component`, scoped to one file's
    CONTRACT/SPEC) and the existing whole-plan restart have both already
    been tried and both still left the plan failing.

    Fed the same kind of evidence `replan_component` already trusts more
    than a bare error string -- the real, current source of every
    component that *did* succeed, so a rewritten request cannot propose
    something that contradicts code already written and already relied
    on -- plus, for every component that did not, the full attempt trail
    (`Component.history_trail`) rather than only the last rung's condensed
    line, because "the request was ambiguous" is usually only visible
    across several failed attempts that each guessed a different way
    around the same missing sentence, not in any single one of them.

    Best-effort, on the same terms as `replan_component`: no planner
    available, an Ollama error, or a reply that does not parse as a real
    rewrite all return None, which leaves the plan's existing FAILED state
    exactly as it would have been without this -- reported loud, not
    silently retried a third time.
    """
    node, model, held = claim_first_free_role(cfg, state, [4])
    if node is None:
        return None
    try:
        failing = [c for c in components if not c.ok]
        succeeding = [c for c in components if c.ok]
        failures = []
        for c in failing:
            trail_lines = getattr(c, "history_trail", None)
            trail = "\n".join(trail_lines) if trail_lines else (
                c.error or "(no error recorded)")
            failures.append("--- %s ---\nSPEC: %s\n%s" % (c.path, c.spec, trail))
        sources = []
        for c in succeeding:
            try:
                with open(os.path.join(root, c.path), "r",
                         encoding="utf-8") as fh:
                    body = fh.read()
            except OSError:
                continue
            sources.append("--- %s ---\n%s" % (c.path, body[:4000]))
        prompt = intent.REQUEST_REPLAN_PROMPT.format(
            request=request or "(not recorded)", contract=contract or "NONE",
            failures="\n\n".join(failures) or "(none)",
            sources="\n\n".join(sources) or "(none)")
        window = swarm.pick_num_ctx(cfg, node, model, swarm.est_tokens(prompt),
                                    1500, reasoning=False)
    except Exception:
        # Same leak this guards against in `decompose`/`replan_component`:
        # an exception before the node is handed to `hold_or_wait` would
        # otherwise never be released, since nothing else holds a
        # reference to it.
        if held:
            state.release_node(node.name)
        raise
    try:
        with hold_or_wait(state, node, model, held):
            r = swarm.chat_complete(
                node, model, [{"role": "user", "content": prompt}],
                num_ctx=window, answer_tokens=1500, headroom=1.5, think=False,
                temperature=0.1, timeout=180)
        state.record_perf(node.name, model, r["sample"])
    except swarm.OllamaError:
        return None
    return intent.parse_request_replan(r.get("text") or "")


def _dangling_version_repair_attempt(
        raw: List[Dict[str, Any]], idx: int, consumer_dir: str,
        producer_dir: Optional[str], problem_text: str,
        cfg: swarm.Config, state: swarm.State
        ) -> Optional[List[Dict[str, Any]]]:
    """One network round-trip attempting to fix a single finding from
    `intent.dangling_version_findings`. Returns a validated, corrected
    `raw` on success, or None -- best-effort, on the same terms as
    `replan_component`/`replan_request`: no planner available, an
    Ollama error, an unparseable reply, or a reply that fails validation
    all return None and leave `raw` untouched for the caller to fall
    back to reporting the problem as before.
    """
    steps = [(str(item["dir"]), str(item["request"])) for item in raw]
    chain_block = "\n".join(
        "--- %s ---\nrequest: %s" % (str(item["dir"]), str(item["request"]))
        for item in raw)
    node, model, held = claim_first_free_role(cfg, state, [4])
    if node is None:
        return None
    try:
        prompt = intent.CHAIN_VERSION_REPAIR_PROMPT.format(
            chain_block=chain_block, consumer_dir=consumer_dir,
            problem_text=problem_text)
        window = swarm.pick_num_ctx(cfg, node, model, swarm.est_tokens(prompt),
                                    2000, reasoning=False)
    except Exception:
        if held:
            state.release_node(node.name)
        raise
    try:
        with hold_or_wait(state, node, model, held):
            r = swarm.chat_complete(
                node, model, [{"role": "user", "content": prompt}],
                num_ctx=window, answer_tokens=2000, headroom=1.5,
                think=False, temperature=0.1, timeout=180)
        state.record_perf(node.name, model, r["sample"])
    except swarm.OllamaError:
        return None
    proposed = intent.parse_chain_version_repair(r.get("text") or "")
    if proposed is None:
        return None
    return _validate_dangling_version_fix(
        raw, steps, idx, consumer_dir, producer_dir, proposed)


def _validate_dangling_version_fix(
        raw: List[Dict[str, Any]], steps: List[Tuple[str, str]], idx: int,
        consumer_dir: str, producer_dir: Optional[str],
        proposed: List[Dict[str, str]]
        ) -> Optional[List[Dict[str, Any]]]:
    """The guardrail `parse_chain_version_repair` deliberately leaves to
    its caller: a reply that parses as a well-formed chain is not the
    same claim as a reply that actually fixed the named problem without
    touching anything it was not asked to. Only two shapes are ever
    accepted -- rewriting `consumer_dir` alone in place, or rewriting
    `consumer_dir` together with an *immediately preceding* producer,
    either as two rewritten steps or merged into one -- because that is
    the one shape this project's own chains actually take (`LOCAL.md`'s
    "the single most common way this goes wrong": two adjacent steps,
    the second dangling off the first). Anything else -- a producer that
    is not adjacent, a third step touched, a step outside the window
    reworded or dropped, a duplicate dir name -- is refused rather than
    guessed through, the same rule every other mechanical gate in this
    project follows: a detector (here, a fix) that is sometimes wrong is
    worse than one that sometimes says nothing.
    """
    orig_dirs = [d for d, _ in steps]
    orig_by_dir = {d: r for d, r in steps}
    if len(orig_dirs) != len(set(orig_dirs)):
        return None
    proposed_dirs = [item["dir"] for item in proposed]
    if len(proposed_dirs) != len(set(proposed_dirs)):
        return None  # the model's own reply names one dir twice

    if producer_dir is not None:
        try:
            p_idx = orig_dirs.index(producer_dir)
        except ValueError:
            return None
        if p_idx != idx - 1:
            return None  # only the adjacent shape is handled here
        window_start = p_idx
        window_dirs = [producer_dir, consumer_dir]
    elif idx > 0:
        # No earlier step literally mentions "version" -- the exact live
        # gap this repair exists to close, since the real producer often
        # never spells the word out ("push this html to the applet" IS
        # creating a version, in this API). The immediately preceding
        # step is offered as an optional merge target for the same
        # reason `chain_dangling_version_problems`' own message always
        # suggests merging with whatever sits right before the consumer:
        # that is the one shape this project's own chains actually take.
        # The model is still free to leave it alone and rewrite only the
        # consumer in place.
        window_start = idx - 1
        window_dirs = [orig_dirs[idx - 1], consumer_dir]
    else:
        window_start = idx
        window_dirs = [consumer_dir]
    window_end = window_start + len(window_dirs)
    outside = orig_dirs[:window_start] + orig_dirs[window_end:]

    proposed_by_dir = {item["dir"]: item for item in proposed}
    for d in outside:
        item = proposed_by_dir.get(d)
        if item is None or item["request"] != orig_by_dir[d]:
            return None  # a step outside the window was reworded or dropped

    window_items = [item for item in proposed if item["dir"] not in outside]
    if not window_items or len(window_items) > len(window_dirs):
        return None
    if consumer_dir not in [item["dir"] for item in window_items] and (
            len(window_items) == len(window_dirs)):
        return None  # renamed everything in the window but never touched
        # the consumer under any name -- the one step this is supposed
        # to fix

    def _window_sort_key(item: Dict[str, str]) -> float:
        if item["dir"] == window_dirs[0]:
            return 0
        if item["dir"] == consumer_dir:
            return 1
        return 0.5

    window_items = sorted(window_items, key=_window_sort_key)

    raw_by_dir = {str(item["dir"]): item for item in raw}
    new_raw: List[Dict[str, Any]] = []
    for d in orig_dirs[:window_start]:
        new_raw.append(raw_by_dir[d])
    for item in window_items:
        merged = dict(raw_by_dir.get(item["dir"], {}))
        merged["dir"] = item["dir"]
        merged["request"] = item["request"]
        if item.get("api"):
            merged["api"] = item["api"]
        elif "api" not in merged:
            merged["api"] = ""
        new_raw.append(merged)
    for d in orig_dirs[window_end:]:
        new_raw.append(raw_by_dir[d])

    new_steps = [(str(item["dir"]), str(item["request"])) for item in new_raw]
    if intent.chain_dangling_version_problems(new_steps):
        return None  # the fix did not actually resolve it
    if intent.chain_output_json_problems(new_steps):
        return None  # or it broke a promise the other check protects
    return new_raw


def repair_dangling_version_chain(
        raw: List[Dict[str, Any]], cfg: swarm.Config, state: swarm.State,
        max_repairs: int = 3
        ) -> Tuple[List[Dict[str, Any]], List[str], List[str]]:
    """Ask the pool to fix whatever `intent.chain_dangling_version_problems`
    found, instead of only reporting it and stopping the run before any
    real API call happens.

    That check is deliberately never fixed by a regex, and the reason is
    worth restating here rather than only in its own docstring: "the new
    version" names no key, so proving a fix from the chain's own text --
    the way `autofix_chain_output_json` proves one for a missing
    `output.json` read/write pair -- is not possible; there is nothing to
    read the key back off of. What is possible is asking a reader to do
    the one thing regex cannot: recognise that an earlier step which
    never says the word "version" is nonetheless the step that creates
    one (a request that says "push this html to the applet" IS creating
    a version, in this API, even though it never spells that out), and
    propose the correction that follows from noticing that.

    A model saying so is not trusted on its say-so, though -- the same
    rule this project applies everywhere a model is asked to fix rather
    than merely judge: every candidate fix is checked mechanically, by
    `_validate_dangling_version_fix`, against the exact same two ground-
    truth functions (`chain_dangling_version_problems`,
    `chain_output_json_problems`) an operator would otherwise have to
    satisfy by hand, before it is ever applied. A fix that does not pass
    both is discarded, not applied optimistically -- this can only ever
    make a broken chain fixed or leave it exactly as broken as before;
    it cannot make a working chain worse, because nothing here runs
    unless `chain_dangling_version_problems` already found something
    wrong.

    Capped at `max_repairs` network round-trips total (not per finding),
    since this is a small text-editing judgement call, not a code
    generation task that benefits from a repair ladder -- if the pool's
    first answer for a given finding does not validate, retrying the
    identical question rarely helps and the operator is better served by
    the existing report-and-stop behaviour for that one step.
    """
    notes: List[str] = []
    tried: Set[str] = set()
    attempts = 0
    while attempts < max_repairs:
        try:
            steps = [(str(item["dir"]), str(item["request"]))
                     for item in raw]
        except (KeyError, TypeError):
            break
        problems = intent.chain_dangling_version_problems(steps)
        if not problems:
            break
        findings = intent.dangling_version_findings(steps)
        candidates = [f for f in findings if f[1] not in tried]
        if not candidates:
            break
        idx, consumer_dir, producer_dir = candidates[0]
        tried.add(consumer_dir)
        attempts += 1
        problem_text = next(
            (p for p in problems if p.startswith(consumer_dir + " ")), "")
        fixed = _dangling_version_repair_attempt(
            raw, idx, consumer_dir, producer_dir, problem_text, cfg, state)
        if fixed is None:
            notes.append(
                "could not repair %s over the network -- leaving it for "
                "a hand edit" % consumer_dir)
            continue
        raw = fixed
        if producer_dir:
            notes.append("repaired %s and %s via the pool"
                        % (producer_dir, consumer_dir))
        else:
            notes.append("repaired %s via the pool" % consumer_dir)
    remaining = intent.chain_dangling_version_problems(
        [(str(item["dir"]), str(item["request"])) for item in raw])
    return raw, remaining, notes


def run_components(components: List[intent.Component], cfg: swarm.Config,
                   state: swarm.State, check: Optional[str] = None,
                   repair: int = 3, answer_tokens: int = 3000,
                   root: Optional[str] = None,
                   tests: Optional[Dict[str, str]] = None,
                   already: Optional[List[intent.Component]] = None,
                   existing: Optional[Dict[str, str]] = None,
                   attached: str = "",
                   env_extra: Optional[Dict[str, str]] = None,
                   mock: Optional[Any] = None,
                   api_name: Optional[str] = None,
                   request: str = ""
                   ) -> Tuple[int, float]:
    """Write every component, respecting dependencies, as wide as possible.

    Two pools, because the whole point is that they overlap: the capable model
    takes the hard components while the small models take the routine ones at
    the same time, and the hard one is usually still going when the routine
    ones land. Whatever has the most work stacked behind it goes first.

    `existing` is this project's files as they stood before this call, keyed
    by path, for any component whose planner-chosen path names one of them.
    Session history tells the *planner* a file already exists and what it
    already defines, so a follow-up request can target it by name -- but
    without this, the model actually asked to write that path never sees its
    current content, only the planner's spec describing the change. It would
    write the file from scratch, blind to everything the spec did not
    mention, and correct-but-unmentioned behaviour would simply vanish.
    """
    root = root or project_root()
    # Read off the plan's own dependency graph, once, rather than trusting
    # the CONTRACT text to have repeated a `main()` clause this round --
    # see `intent.plan_entry_point` for why the CONTRACT alone was not
    # enough to keep other files from also defining `main`.
    entry_point = intent.plan_entry_point(components)
    # Read once, from the same raw request every component was planned
    # against, and reused for every component's `count_check` below -- see
    # `mockapi.Mock.count_problems_for` for the live failure this exists to
    # catch ("uploads 3 units" shipping a task with 2, every gate green).
    expected_counts = intent.required_counts(request)
    # A resource `required_counts` already pins a real number to is
    # excluded here -- that check is exact and already covers it. This
    # only fills the gap where a bulk verb names a plural resource with no
    # number attached at all ("upload units to the task"), which used to
    # mean nothing was ever checked and a literal `{"units": []}`
    # satisfied every gate. See `mockapi.Mock.zero_problems_for`.
    implied_nonempty = (intent.implied_nonempty_counts(request)
                        - set(expected_counts.keys()))
    restrict = cfg.data.get("team", {}).get("restrict_to_family")
    # Was a hardcoded 2, which agreed with `build_components`'s own
    # `count=4` sizing call (line ~1614, used to tell the planner how many
    # strong machines exist) only because there used to be exactly one real
    # floor-4 box -- "top 2 of 1" and "top 4 of 1" return the same thing.
    # Now that capability 4 spans up to three nodes (see config.json's
    # 2026-09-20 e4b capability change), a fixed 2 silently stopped
    # matching what the planner was told and started leaving a genuinely
    # floor-4-capable node without a dedicated floor-4 thread even when
    # there was floor-4 backlog for it. `len(enabled_nodes())` tracks
    # `build_components`'s sizing call by construction instead of by
    # coincidence, and pick_solvers already returns fewer than asked for
    # when fewer nodes qualify, so this is a ceiling, not a promise that
    # every enabled node gets floor-4 work.
    strong = pick_solvers(cfg, state, 4, count=len(cfg.enabled_nodes()),
                          family=restrict)
    # The routine pool spans every capability, not just 1-2. `max_over=1`
    # used to cap this band at floor+1, on the reasoning that a capability-4
    # model doing five minutes of slugify boilerplate is a capability-4
    # model not doing the hard file it exists for. That reasoning only holds
    # for a node this same process already assigned to `strong` -- and the
    # exclusion two lines down already keeps such a node out of `light`
    # regardless of any ceiling, so the ceiling was never the thing
    # protecting that case. What it actually did was stop a capability-4
    # node from helping at all once it *wasn't* one of `strong`'s top
    # `count=2` picks -- e.g. a third floor-4-capable box sitting fully idle
    # for this plan's whole run because nothing else in its own difficulty
    # class was left for it, while real floor-2 work from the same plan
    # waited. That waste compounds across `generate.sh`-style parallel `do`
    # invocations: a plan that collapses to a single file has no floor-2
    # work of its own to hand out, so under the old ceiling any capability-4
    # node not needed by *that* process contributed nothing to any of the
    # *other* processes' floor-2 backlog either, even though `node_claim`
    # already makes it safe for several processes to share one node/model
    # pair concurrently (same-model claims stack; only a different model on
    # the same node has to wait). Every model now qualifies for anything at
    # or below its own capability, so the weakest box (capability 1, if one
    # is ever configured) is the only one that cannot also help elsewhere --
    # capability 2 already could, and this just stops treating capability 4
    # as a reason to sit out routine work instead of a floor under it.
    light = [t for t in pick_solvers(cfg, state, 1, count=4, family=restrict)
             if t[0].name not in {n.name for n, _ in strong}]
    if not strong and not light:
        return 0, 0.0
    # With nothing capable available, the hard parts still have to be
    # written -- toggling the whole g26b box off (`swarm.Config.toggle_26b`)
    # is exactly this case, since it is the only node with a floor-4 model
    # at all. Borrow the fastest light-tier node rather than leaving floor-4
    # work with no worker.
    if not strong:
        sys.stderr.write(
            "no floor-4 node is enabled -- borrowing %s/%s for floor-4 "
            "work anyway\n" % (light[0][0].name, light[0][1]))
        strong = light[:1]
        # `strong` and `light` are about to be spawned as two *separate*
        # worker threads each, one polling floor 4 and one polling floor 2
        # (see the loop below) -- borrowing without removing put the same
        # (node, model) pair, and therefore the same Ollama server, on both
        # threads at once. Every node here is `single_slot` by default, so
        # two threads calling `generate_file` concurrently against it is
        # not two writers, it is one node being asked to hold two models'
        # worth of context and serving neither promptly. Drop it from
        # `light` once borrowed, or a run with no floor-4 node at all
        # quietly starts contending with itself on whichever box is fastest.
        borrowed = {n.name for n, _ in strong}
        light = [t for t in light if t[0].name not in borrowed] or strong
    if not light:
        light = strong

    depth = intent.critical_depth(components)
    # Components carried over from an earlier run count as satisfied
    # dependencies -- their source is on disk and gets handed to whatever
    # depends on them -- but are never rewritten. This is what makes a retry
    # cheap: only the parts that failed are paid for again.
    done: Dict[str, intent.Component] = {c.name: c for c in (already or [])}
    pending = {c.name: c for c in components if c.name not in done}
    lock = threading.Lock()
    started = time.monotonic()

    # Measured once up front: rates do not meaningfully move inside a run, and
    # reading them here keeps the workers off the database entirely.
    #
    # Scaled by `model_bias`, which this loop did not consult until a node
    # was re-enabled specifically to win claim races it would lose on raw
    # throughput -- `preference_multiplier` already treats bias this way for
    # `split`/`run`, and leaving it out here made the same config knob a
    # no-op for `do`/`code`, the commands it actually needed to affect. Bias
    # multiplies the measured rate directly (higher bias, more eager to
    # claim and more likely to be deferred to), the same direction
    # `preference_multiplier` uses even though that one divides a cost
    # instead of scaling a rate -- inverse operation, same effect. Absent
    # from a node's `model_bias`, it is 1.0 and this is a no-op.
    rates = {"%s/%s" % (n.name, m):
             measured_rate(state, n.name, m) * float(n.model_bias.get(m, 1.0))
             for n, m in list(strong) + list(light)}
    # key -> (measured tokens/sec, the floor this worker polls). The tier is
    # not decoration: without it, deferring to a faster worker that cannot take
    # the work deadlocks the run.
    idle: Dict[str, Tuple[float, int]] = {}
    inflight: Dict[str, intent.Component] = {}

    def _checkpoint() -> None:
        """Persist the plan the instant a component's outcome is final, not
        only once the whole run finishes.

        `save_plan` used to be called exactly once, after every component in
        this call had already returned -- which is also the one moment a
        run being interrupted (a wedged node, an operator's own Ctrl-C, a
        crash) is guaranteed to prevent. Measured live: a `main.py` burned
        six attempts, the loop announced it was restarting from a clean
        slate, and the operator killed it there -- at which point nothing
        had ever been written to `.swarm/plans/`, so `--retry` had no error
        to work from and the honest answer to "why did this fail" was
        "nothing was recorded", which is a worse answer than any wrong one.
        `client.py` and `survey.html` had both already passed by then; that
        result was thrown away too, for no reason connected to whether it
        was correct.

        So this runs every time an outcome becomes final -- a component
        passing, failing, being refused as too large, or a worker dying
        under it -- rather than waiting for the ones after it in the plan.
        A `--retry` right after an interruption then sees exactly what
        happened, instead of a plan that was never written and a set of
        already-passing files it has no record of and would otherwise
        rebuild from scratch.

        Held for the whole snapshot-and-write, not just the snapshot: two
        components can finish within microseconds of each other on
        different workers, and two threads each opening the same path for
        `"w"` with no ordering between them is a real interleaving risk,
        not a theoretical one -- unlike the dict reads elsewhere in this
        function, `json.dump` is several separate `write()` calls, not one
        atomic operation. The write itself is a few kilobytes and happens
        at most once per component, so serialising it costs nothing worth
        avoiding the lock for.
        """
        with lock:
            snapshot = (list(done.values()) + list(pending.values())
                       + list(inflight.values()))
            save_plan(root, request, snapshot, check, answer_tokens,
                     api=api_name)

    def claim(floor: int, my_rate: float = 0.0) -> Optional[intent.Component]:
        with lock:
            ready = [c for c in pending.values()
                     if c.floor == floor and all(d in done for d in c.deps)]
            if not ready:
                return None
            # Whoever polls first used to win, which is fine while there is
            # work for everyone and actively harmful at the tail. The last
            # component is the critical path -- every other box sits idle while
            # it runs -- so handing it to the slowest machine because it
            # happened to ask first sets the length of the whole run. Measured
            # on this pool: the join went to a 14.9 tok/s box while a 43.1
            # tok/s one waited, roughly tripling the only task left.
            #
            # So step aside when there are not enough ready components to keep
            # the faster idle workers busy -- but only for workers that could
            # actually take this work. Deferring to a faster machine that is
            # structurally unable to claim the component is not politeness, it
            # is a deadlock: the only floor-4 worker waits for a light box to
            # take a floor-4 file, the light box polls floor 2 and never sees
            # it, and both sleep until killed.
            #
            # That is not hypothetical and it is not rare. It arrived on its
            # own when e4b-linux measured 44.5 tok/s against the 12b's 42.4 --
            # a routine perf sample crossing over, with no code change,
            # silently wedging every plan whose last component was FLOOR 4.
            faster = sum(1 for key, (rate, tier) in idle.items()
                         if rate > my_rate and _can_take(tier, floor))
            if faster and len(ready) <= faster:
                return None
            ready.sort(key=lambda c: -depth.get(c.name, 0))
            return pending.pop(ready[0].name)

    def finished() -> bool:
        with lock:
            return not pending

    def worker(node: swarm.Node, model: str, floor: int) -> None:
        """Run the loop, and make sure dying does not wedge everyone else.

        `claim` removes a component from `pending` before any work starts, and
        `finished` is `not pending`, so a thread that raises partway through
        strands its component: nothing ever lands in `done`, dependents stay
        ready-but-unbuildable, and every surviving worker spins in the claim
        loop while `join` waits on it. That is an unbounded hang presenting as
        a wedged node, which is the most expensive way for this to fail
        because the obvious diagnosis is wrong.
        """
        key = "%s/%s" % (node.name, model)
        try:
            _worker_loop(node, model, floor)
        except BaseException as exc:  # noqa: BLE001 -- deliberately everything
            with lock:
                idle.pop(key, None)
                stranded = inflight.pop(key, None)
                if stranded is not None and stranded.name not in done:
                    stranded.ok = False
                    stranded.error = "worker died: %s: %s" % (
                        type(exc).__name__, exc)
                    # Into `done` so dependents unblock and the run can end.
                    # They will be short a dependency and fail their own gates,
                    # which is a reported failure rather than a silent stall.
                    done[stranded.name] = stranded
            if stranded is not None:
                _checkpoint()
            sys.stderr.write("  [%-18s] worker on %s/%s died: %s\n"
                             % (getattr(stranded, "name", "?")[:18],
                                node.name, model, exc))

    def _worker_loop(node: swarm.Node, model: str, floor: int) -> None:
        key = "%s/%s" % (node.name, model)
        my_rate = rates.get(key, 0.0)
        with lock:
            idle[key] = (my_rate, floor)
        while not finished():
            component = claim(floor, my_rate)
            if component is None:
                # Either blocked on a dependency or this tier is drained. If
                # the strong writer is idle it may as well take routine work
                # rather than watch.
                if floor == 4:
                    # `my_rate` here already carries `model_bias`, and that
                    # bias is deliberately suppressed for this worker's own
                    # model (0.3 on g26b) so it steps aside from routine
                    # floor-2 work for a lighter box while there is still a
                    # chance more floor-4 work shows up for it to do instead.
                    # That reasoning has nothing left to stand on once no
                    # floor-4 component remains at all: deferring then buys
                    # nothing, because there is no floor-4 work left to save
                    # itself for, and the run's tail is decided by whoever
                    # is doing the one file that is left. Measured live: the
                    # only floor-4 worker sat idle rather than take the
                    # final floor-2 file, because its own suppressed bias
                    # made a slower, differently-biased box look faster on
                    # paper. Passing an unbounded rate here means it never
                    # defers on this specific call -- it has nothing to wait
                    # for, so it should not wait.
                    with lock:
                        floor4_left = any(c.floor == 4 for c in pending.values())
                    component = claim(2, my_rate if floor4_left else float("inf"))
                if component is None:
                    time.sleep(0.4)
                    continue
            with lock:
                idle.pop(key, None)
                inflight[key] = component
            with lock:
                context = intent.dependency_context(component, done)
            sys.stderr.write("  [%-18s] %s on %s/%s\n"
                             % (component.name[:18], component.path,
                                node.name, model))
            extra = project_context(component.spec)
            # Baked in, not scored, same reasoning as the maven applet
            # boilerplate just below: a component whose own SPEC promises
            # to write its own output.json, or to read a named value out
            # of a sibling's, gets the literal code for that shape --
            # built from this component's own real key/path, never a
            # generic example -- rather than relying solely on
            # `context/policy-output-json.md`'s prose, which measured
            # live as insufficient on its own (a component failed the
            # same missing-write gate four rungs running, with that
            # policy card already in its system prompt every time). Both
            # helpers are silent unless this component's own spec
            # actually asks for the shape, so a component with no
            # hand-off of its own is never shown or biased toward either.
            extra += codegen.own_output_write_block(component.spec, request)
            extra += codegen.sibling_output_read_block(component.spec)
            # Baked in, not scored: every .html component under `--api
            # maven` gets the reference applet verbatim, deterministically,
            # regardless of whether this component's SPEC happens to share
            # enough words with `policy-applet-html.md` to score above
            # `min_score`. The literal protocol shapes matter more here than
            # a prose description of them ever converged on being followed.
            if ((api_name or "").lower() == "maven"
                    and component.path.lower().endswith((".html", ".htm"))):
                boilerplate = maven_applet_boilerplate()
                if boilerplate:
                    extra += (
                        "\n\nStart from this exact reference applet and "
                        "keep its platform-protocol scaffolding unchanged "
                        "-- APPLET_READY on load, the UNIT_DATA handler "
                        "reading `unit` and `prepopulate` (not `unit_data`), "
                        "STATE_UPDATE on every change, ERROR on a harness-"
                        "facing problem, and the disabled/\"Submitting...\" "
                        "guard in onSubmit. Replace only the task-specific "
                        "parts: the fields inside `.section-box`, "
                        "`applyWorkingOutput`, and `buildCurrentOutput`. Do "
                        "not rename the message types or the field names "
                        "inside them. If any field is a custom widget (a "
                        "star rating, a slider, a toggle group -- anything "
                        "that is not a plain input/textarea/select or a "
                        "real radio/checkbox), read the boilerplate's own "
                        "comment above bindEvents()/buildCurrentOutput() "
                        "before writing it: the delegated input/change "
                        "listener never fires for a clicked span/div, so "
                        "a custom widget that only updates its own CSS on "
                        "click will visibly work and silently save "
                        "nothing. And if this task renders the same widget "
                        "once per item (one rating row per option), wire "
                        "its listener with querySelectorAll+forEach or "
                        "delegation -- a bare, singular querySelector on "
                        "the class every row shares binds only the first "
                        "row and leaves the rest permanently "
                        "unresponsive.\n\n```html\n%s\n```" % boilerplate)
            # Reference material the operator attached: a design document, a
            # wire format, an example of the wanted output. Every writer gets
            # it, unlike `existing` above, which is matched per path -- a
            # specification that only some of the package can see produces
            # files that disagree about what they are implementing, and
            # nothing downstream detects that. Already size-checked in
            # `cmd_do` against the narrowest window in the fleet, precisely so
            # that this line never has to decide whether to drop it.
            #
            # Constant across every component, so it shifts `num_ctx` for the
            # run uniformly rather than varying between calls. That matters:
            # a term that changed per component would make Ollama reload the
            # model on each one.
            extra += attached
            # If this path already existed before this run started, the model
            # is editing it, not authoring it fresh -- and the planner's spec
            # describes only the change, not everything the file already does
            # correctly. Without the real content here, that everything-else
            # is invisible to the one call that actually writes the file, and
            # gets silently replaced by whatever the model assumes was there.
            prior = (existing or {}).get(os.path.normpath(component.path))
            if prior is not None:
                # A whole-file rewrite pays for the file twice against one
                # window: the old content sits in the prompt and the new
                # content comes back as the answer. Truncating it to fit was
                # the previous behaviour and it is the worst of the available
                # options -- the writer is told this is the file's current
                # content and asked to keep whatever the change does not
                # mention, while being physically unable to see the rest, so
                # it returns a complete file that silently drops everything
                # past the cut. Parse, import and smoke all pass, because the
                # result is valid code; it is merely missing. `interface_gate`
                # notices only if some other file imported a dropped name.
                #
                # Measured on this project at the old 8000-character cap: 16
                # of 63 top-level files exceeded it and were being truncated,
                # and three cannot round-trip at any cap (team.py alone needs
                # ~72k tokens against every configured model's 16384 window).
                # So nothing is truncated here. Either the whole file fits, or
                # the component is refused and says so -- a fact the operator
                # can act on, rather than a quietly gutted file they have to
                # notice on their own.
                prior_tokens = swarm.est_tokens(prior)
                room = (node.max_ctx(model)
                        - swarm.est_tokens(extra + component.spec) - 1024)
                if prior_tokens * 2 > room:
                    component.ok = False
                    component.code = ""
                    component.target = "%s/%s" % (node.name, model)
                    component.attempts = 0
                    component.seconds = 0.0
                    component.error = (
                        "too large to rewrite whole: %s is ~%d tokens, and "
                        "replacing it needs ~%d (prompt plus answer) against "
                        "%s's %d-token window. Split the file, or target a "
                        "smaller one." % (component.path, prior_tokens,
                                          prior_tokens * 2, model,
                                          node.max_ctx(model)))
                    with lock:
                        done[component.name] = component
                        inflight.pop(key, None)
                        idle[key] = (my_rate, floor)
                    _checkpoint()
                    sys.stderr.write("  [%-18s] REFUSED -- %s\n"
                                     % (component.name[:18], component.error))
                    continue
                fence = os.path.splitext(component.path)[1].lstrip(".") or "text"
                failed = os.path.isfile(os.path.join(root or "", ".ralph", "last-check.txt"))
                if failed:
                    try:
                        with open(os.path.join(root, ".ralph", "last-check.txt"),
                                  encoding="utf-8", errors="replace") as fh:
                            failed_text = fh.read()
                    except OSError:
                        failed_text = ""
                    calls = calls_from_check(root or "", failed_text, check or "")
                    own = os.path.basename(component.path)
                    cited = [ln.strip() for ln in failed_text.splitlines()
                             if "CHECK FAILED" in ln and own in ln]
                    cited_block = ""
                    if cited:
                        cited_block = (
                            "The check failed on this file:\n%s\n"
                            "A name that line says is not defined must not "
                            "be called, and must not be used except on the "
                            "same line as typeof that name.\n"
                            % "\n".join(cited[:8]))
                    extra += ("\nThis file already exists and the check failed. "
                              "The content below is the version that failed, "
                              "not a contract. Keep the public names the check "
                              "can call. Do not keep a signature, a default, a "
                              "call, or a comment that disagrees with the "
                              "request, the calls below, or the failure lines.\n"
                              "%s%s\n```%s\n%s\n```\n"
                              % (cited_block, ("\n" + calls) if calls else "",
                                 fence, prior))
                else:
                    extra += ("\nThis file already exists. Its current content is "
                              "below; the description above is a CHANGE to make to "
                              "it, not a description of a new file. Keep everything "
                              "that still applies -- do not drop existing classes, "
                              "functions or behaviour the change does not mention:"
                              "\n```%s\n%s\n```\n" % (fence, prior))
            # The shared contract goes to every writer regardless of whether
            # this component declared a dependency. Waiting for a neighbour's
            # finished source is how agreement was reached before, which only
            # works along dependency edges and leaves unrelated files free to
            # invent their own version of a shared type -- the defect that
            # survives every other check.
            if component.contract:
                extra += ("\nEVERY file in this package must agree on these "
                          "exact names and signatures. Use them verbatim; do "
                          "not define your own version of anything here:\n%s\n"
                          % component.contract)
                # Unqualified, the contract reads as a specification of things
                # to write rather than things to agree on, and a small model
                # handed a full class signature writes the class. Saying who
                # owns each name is what makes it a prohibition.
                owns = intent.ownership_note(component.contract,
                                             component.path, entry_point)
                if owns:
                    extra += ("\nOf those names, this file (%s) is responsible "
                              "for only some:\n%s\n" % (component.path, owns))
            extra += ("\nThis file must fit with code that already exists:"
                      "\n\n%s" % context) if context else ""
            # Deliberately not the integration check. That command exercises
            # the finished package, so running it after each file fails every
            # time until the last file exists -- every component burns its
            # repair budget on a gate it cannot pass and is then deleted for
            # being broken. Parse and import are the gates that mean something
            # for one file; the integration check runs once, at the end.
            own_test = (tests or {}).get(component.name)
            # Label this component's gate subprocesses. Components run in
            # parallel against one mock, so the log needs to say who sent
            # what -- handing a writer another file's rejected request is a
            # confident wrong instruction the repair loop would act on.
            component_env = dict(env_extra or {})
            component_env["SWARM_COMPONENT"] = component.path
            rejected = sent_count = count_check = None
            if mock is not None:
                rejected = (lambda since, p=component.path:
                            mock.rejected_for(p, since))
                sent_count = lambda: len(mock.calls)
                count_check = (lambda since, p=component.path:
                              mock.count_problems_for(p, since,
                                                      expected_counts)
                              + mock.zero_problems_for(p, since,
                                                       implied_nonempty))
            # This project's own generated `orchestrate.sh` always invokes
            # a chain step's entry point as `python3 main.py` with zero
            # command-line arguments (see `LOCAL.md`'s `run_step`), so a
            # required argparse argument on *that* file can never once
            # succeed for real, no matter how many times it is retried --
            # see `gate_required_cli_args`. Scoped to the one case that
            # actually is invoked that way: an `--api` run (a mock is
            # running, so this is a real chain step, not a bare `--check`
            # library call) whose path is this plan's own entry point.
            is_chain_entry_point = (mock is not None and entry_point
                                    and os.path.normpath(component.path)
                                    == os.path.normpath(entry_point))

            def _write_component(out_override: Optional[str] = None
                                 ) -> Dict[str, Any]:
                # The oracle is unproven, so it gets two attempts rather than
                # the whole budget. One rejection says nothing -- the code
                # may simply be wrong. Two rejections of two independently
                # written candidates is evidence about the test instead, and
                # continuing to spend on it is how a single bad oracle cost
                # nine minutes on one file.
                #
                # `out_override` exists only for `_write_component_hedged`
                # below: when this attempt might end up racing against idle
                # capacity elsewhere, it has to land on a scratch path first,
                # the same reason `race_generate_file` never lets a racer
                # touch the real file directly -- two writers to one path at
                # once corrupt each other, one thread's `gate_import` reading
                # the file mid-rewrite by the other. Every ordinary call
                # (the common case, nothing idle to race against) passes
                # nothing here and writes the real path exactly as before.
                target = out_override or os.path.join(root, component.path)
                spec = component.spec
                try:
                    with open(os.path.join(root or "", ".ralph", "last-check.txt"),
                              encoding="utf-8", errors="replace") as fh:
                        failed_text = fh.read()
                except OSError:
                    failed_text = ""
                note = failure_build_note(
                    root or "", component.path, failed_text, check or "")
                if note:
                    spec += "\n\n" + note
                # The real check used to run only after this returned ok.
                # A file that parses then passed, and the repair budget was
                # spent on nothing. With one file in the plan the check can
                # only be failing because of this file, so it belongs in the
                # attempts. Two files writing at once cannot share it: each
                # would treat the other's failure as its own.
                file_check = (scoped_check_command(check, component.path)
                              if check and len(components) == 1 else None)
                res = codegen.generate_file(
                    spec, target, node,
                    model, cfg, state,
                    check=file_check or (
                        ("python3 " + own_test) if own_test else None),
                    attempts=min(2, repair) if own_test else repair,
                    answer_tokens=answer_tokens,
                    thinking=thinking_tokens(cfg, model), root=root,
                    extra=extra, verbose=False,
                    uses=dep_modules(component, done, root),
                    env_extra=component_env, rejected=rejected,
                    sent_count=sent_count, count_check=count_check,
                    dep_paths=dep_paths(component, done),
                    forbid_required_cli_args=is_chain_entry_point,
                    env_names=env_vocabulary(cfg, root),
                    original_request=request)
                # A generated test can be wrong, and a wrong oracle rejects
                # correct code forever. If every attempt died against it, try
                # once more on the plain gates and let the integration check
                # have the final say.
                if not res["ok"] and own_test:
                    sys.stderr.write("  [%-18s] retrying without its own "
                                     "test\n" % component.name[:18])
                    res = codegen.generate_file(
                        component.spec, target,
                        node, model, cfg, state, check=None,
                        attempts=max(1, repair - 2),
                        answer_tokens=answer_tokens,
                        thinking=thinking_tokens(cfg, model), root=root,
                        extra=extra, verbose=False, env_extra=component_env,
                        rejected=rejected, sent_count=sent_count,
                        count_check=count_check,
                        dep_paths=dep_paths(component, done),
                        forbid_required_cli_args=is_chain_entry_point,
                        env_names=env_vocabulary(cfg, root),
                        original_request=request)
                return res

            def _write_component_hedged() -> Tuple[Dict[str, Any],
                                                    swarm.Node, str]:
                """Run the initial attempt; if it is still in flight after
                `HEDGE_AFTER_SECONDS` and another node is genuinely idle
                right now, race it against that idle capacity too and
                accept whichever finishes first -- see `HEDGE_AFTER_
                SECONDS` for why this needs to exist at all: every other
                race in this ladder only fires after this call has
                already given up entirely, which can be many minutes deep
                into a single busy box while the rest of the fleet sits
                unused.

                Both the primary and every hedge write to their own
                scratch path -- never the real one -- for the identical
                reason `race_generate_file` does; only the winner is ever
                copied into place, once, and every other in-flight
                attempt (the primary included, if a hedge wins first) is
                abandoned as a daemon thread rather than waited for or
                killed, the same "losers are not waited for" rule that
                function documents. A straggler that finishes later than
                this leaves a harmless scratch file behind rather than
                touching anything a gate would ever read.
                """
                real_path = os.path.join(root, component.path)
                primary_scratch = _race_scratch_path(real_path, "hedge", 0)
                q: "queue.Queue[Tuple[swarm.Node, str, Dict[str, Any], str]]" \
                    = queue.Queue()

                def _primary() -> None:
                    try:
                        r = _write_component(out_override=primary_scratch)
                    except Exception as exc:             # noqa: BLE001
                        r = {"ok": False, "attempts": 0, "seconds": 0.0,
                             "history": [{"stage": "hedge",
                                         "error": str(exc)}],
                             "target": "%s/%s" % (node.name, model)}
                    q.put((node, model, r, primary_scratch))

                threading.Thread(target=_primary, daemon=True).start()
                try:
                    w_node, w_model, r, scratch = q.get(
                        timeout=HEDGE_AFTER_SECONDS)
                    return _promote_hedge_winner(scratch, r, real_path), \
                        w_node, w_model
                except queue.Empty:
                    pass

                # Nothing idle at exactly the 180s mark does not mean
                # nothing idle ever -- keep looking every HEDGE_POLL_
                # SECONDS rather than checking once and waiting untimed
                # for the rest of this component's run. Printed once, not
                # every poll: the fact worth saying is "still waiting,
                # still looking", not a repeated identical line every
                # minute.
                waited = HEDGE_AFTER_SECONDS
                idle_others = pick_idle_race_candidates(
                    cfg, state, node.name, component.floor, family=restrict)
                if not idle_others:
                    sys.stderr.write(
                        "  [%-18s] still running on %s/%s after %ds -- no "
                        "other box is idle right now; will keep checking "
                        "every %ds while this waits\n"
                        % (component.name[:18], node.name, model,
                           int(waited), int(HEDGE_POLL_SECONDS)))
                while not idle_others:
                    try:
                        w_node, w_model, r, scratch = q.get(
                            timeout=HEDGE_POLL_SECONDS)
                        return _promote_hedge_winner(scratch, r, real_path), \
                            w_node, w_model
                    except queue.Empty:
                        pass
                    waited += HEDGE_POLL_SECONDS
                    idle_others = pick_idle_race_candidates(
                        cfg, state, node.name, component.floor,
                        family=restrict)

                sys.stderr.write(
                    "  [%-18s] still running on %s/%s after %ds -- %d "
                    "other box(es) idle right now, racing them too: %s\n"
                    % (component.name[:18], node.name, model,
                       int(waited), len(idle_others),
                       ", ".join("%s/%s" % (n.name, m)
                                for n, m in idle_others)))

                def _hedge(i: int, hnode: swarm.Node, hmodel: str) -> None:
                    tag = "%s#hedge%d" % (component.path, i)
                    scratch = _race_scratch_path(real_path, "hedge", i)
                    env = dict(component_env)
                    env["SWARM_COMPONENT"] = tag
                    hrejected = ((lambda since, p=tag:
                                 mock.rejected_for(p, since))
                                if mock is not None else None)
                    hsent = (lambda: len(mock.calls)) if mock is not None \
                        else None
                    hcount = ((lambda since, p=tag:
                              mock.count_problems_for(p, since,
                                                      expected_counts)
                              + mock.zero_problems_for(p, since,
                                                       implied_nonempty))
                             if mock is not None else None)
                    try:
                        r = codegen.generate_file(
                            component.spec, scratch, hnode, hmodel, cfg,
                            state, check=None, attempts=repair,
                            answer_tokens=answer_tokens,
                            thinking=thinking_tokens(cfg, hmodel), root=root,
                            extra=extra, verbose=False,
                            uses=dep_modules(component, done, root),
                            env_extra=env, rejected=hrejected,
                            sent_count=hsent, count_check=hcount,
                            dep_paths=dep_paths(component, done),
                            forbid_required_cli_args=is_chain_entry_point,
                            env_names=env_vocabulary(cfg, root),
                            original_request=request)
                    except Exception as exc:             # noqa: BLE001
                        r = {"ok": False, "attempts": 0, "seconds": 0.0,
                             "history": [{"stage": "hedge",
                                         "error": str(exc)}],
                             "target": "%s/%s" % (hnode.name, hmodel)}
                    q.put((hnode, hmodel, r, scratch))

                for i, (hnode, hmodel) in enumerate(idle_others):
                    threading.Thread(target=_hedge, args=(i, hnode, hmodel),
                                     daemon=True).start()

                finished: List[Tuple[swarm.Node, str, Dict[str, Any], str]] \
                    = []
                winner = None
                for _ in range(1 + len(idle_others)):
                    item = q.get()
                    finished.append(item)
                    if item[2].get("ok"):
                        winner = item
                        break

                if winner is None:
                    # Nobody has won yet -- every candidate that has
                    # reported in so far failed, so clean those up and
                    # report the first one for a consistent history entry,
                    # the same rule `race_generate_file` follows for the
                    # identical all-lost case.
                    for _n, _m, _r, s in finished:
                        try:
                            os.remove(s)
                        except OSError:
                            pass
                    w_node, w_model, r, _s = finished[0]
                    return r, w_node, w_model

                w_node, w_model, r, scratch = winner
                if (w_node.name, w_model) != (node.name, model):
                    sys.stderr.write(
                        "  [%-18s] %s won the hedge race (started on "
                        "%s/%s)\n"
                        % (component.name[:18],
                           "%s/%s" % (w_node.name, w_model), node.name,
                           model))
                for _n, _m, _r, s in finished:
                    if s != scratch:
                        try:
                            os.remove(s)
                        except OSError:
                            pass
                return _promote_hedge_winner(scratch, r, real_path), \
                    w_node, w_model

            def _promote_hedge_winner(scratch: str, r: Dict[str, Any],
                                      real_path: str) -> Dict[str, Any]:
                """Copy a winning scratch write into the real path, with
                the same backup-before-overwrite step an ordinary write
                already performs -- needed here because every hedge
                candidate, winner included, wrote to a scratch path by
                construction, never to `real_path` directly."""
                if not r["ok"]:
                    try:
                        os.remove(scratch)
                    except OSError:
                        pass
                    return r
                if os.path.exists(real_path):
                    backup = codegen.backup_path(real_path)
                    os.makedirs(os.path.dirname(backup), exist_ok=True)
                    shutil.copy2(real_path, backup)
                shutil.copy2(scratch, real_path)
                try:
                    os.remove(scratch)
                except OSError:
                    pass
                return r

            def _log_attempt(label: str, r: Dict[str, Any]) -> None:
                # Every rung of the ladder below overwrites `res` with its
                # own attempt, and only the very last one survives into
                # `component.error`. That is enough for an operator reading
                # one FAILED line, but not enough for `replan_request`
                # (below) to see the actual trail a request-level
                # diagnosis needs: which rungs were tried, on which boxes,
                # and how each one specifically failed -- "the log" the
                # request-level rewrite is meant to be fed.
                if not r["ok"] and r["history"]:
                    # `Component.__new__` bypasses `__init__` in at least
                    # one existing test fixture, so a component built that
                    # way never got `history_trail` set at all -- fall
                    # back to creating it here rather than raising, since
                    # a missing log is a worse failure mode than a partial
                    # one for a feature that only ever adds context.
                    if not hasattr(component, "history_trail"):
                        component.history_trail = []
                    last = r["history"][-1]
                    dur = last.get("seconds")
                    component.history_trail.append(
                        "[%s] %s (%s): %s" % (
                            label, last.get("stage"),
                            swarm.human(dur) if dur is not None else "?",
                            why_it_failed(last.get("error") or "")))

            res, node, model = _write_component_hedged()
            _log_attempt("initial attempt(s) on %s/%s" % (node.name, model),
                        res)

            def _last_stage_is_budget(r: Dict[str, Any]) -> bool:
                return bool(r["history"]) and r["history"][-1].get("stage") == "budget"

            def _last_stage_is_unreachable(r: Dict[str, Any]) -> bool:
                # `codegen.generate_file` tags a raw `swarm.OllamaError` --
                # the node did not answer at all, as opposed to answering
                # with wrong or ungated code -- with stage "request". This
                # used to fall through both checks below (neither "budget"
                # nor NO_MOCK_MARKER matches it), so a component that hit a
                # dead/wedged node reached `pick_stronger_writer` instead of
                # the fallback-node ladder just like a genuine wrong-answer
                # failure would. Measured live: g26b was unreachable
                # ("cannot reach http://10.0.0.190:11434/api/chat: [Errno
                # 60] Operation timed out"), the initial attempt and the
                # restart both failed that way on the same node, and
                # `pick_stronger_writer` -- which only excludes the current
                # *model*, not the current *node* -- "escalated" to a
                # different model still hosted on that same unreachable
                # box (g26b also carries gemma4-fixed:latest) and failed
                # identically in 7.8s. A dead node has no bearing on
                # whether a *stronger* model would have done better; the
                # fix is a *different box*, exactly the case
                # `_last_stage_is_budget` already exists to route to
                # `pick_fallback_writer`/`pick_idle_race_candidates`
                # instead of quality escalation.
                return bool(r["history"]) and \
                    r["history"][-1].get("stage") == "request"

            def _no_mock(r: Dict[str, Any]) -> bool:
                return bool(r["history"]) and codegen.NO_MOCK_MARKER \
                    in (r["history"][-1].get("error") or "")

            def _repeated_interface_defect(r: Dict[str, Any]) -> bool:
                """True when this call's own attempt history already shows
                the identical `gate_interfaces`/crossref finding on two or
                more attempts.

                A crossref finding is not a model's opinion -- it is an AST
                fact about a call site and the real dependency it names, so
                its text is built purely from those two things and does not
                vary between attempts unless the underlying defect does.
                `REPAIR_PROMPT` already quotes the previous failure back at
                every attempt, so if the model has been shown this exact
                finding once, told to fix it, and produced the identical
                finding again, that is not one more coding mistake to
                retry past -- it is proof the file cannot satisfy it, because
                nothing in a dependent file can invent a method its own
                CONTRACT never gave the dependency in the first place.

                Measured live: a CONTRACT missing a version-creating method
                produced the exact same "calls client.create_applet_version
                (...), but client.py has no such attribute" finding on every
                one of 6 initial attempts, then a full whole-loop restart (6
                more), then an escalation to a stronger model -- 13 attempts
                re-confirming a fact the *second* attempt had already
                established, before `replan_component` (the mechanism built
                specifically for this) was ever consulted. The restart and
                the escalation both assume the previous rung's failures were
                about the model or the roll of the dice; a repeated
                mechanical, non-model-judged finding is evidence about
                neither, so both are worth skipping straight past once this
                fires.
                """
                hits = [h for h in r["history"]
                       if h.get("stage") == "interfaces"]
                if len(hits) < 2:
                    return False
                return len({h.get("error") for h in hits}) == 1

            # A repair loop can get stuck in a rut: `repair` attempts, each
            # one's prompt built on the previous attempt's wrong turn, so a
            # later attempt is not a fresh try, it is the same mistake with a
            # longer prompt attached. Restarting the whole thing once drops
            # that history and starts from the plain spec again -- a
            # genuinely different roll, not attempt `repair + 1` with even
            # more accumulated context.
            #
            # Only skipped for `NO_MOCK_MARKER`, where a second pass is
            # structurally certain to fail the identical way -- no `--api`
            # means no mock, and nothing about a fresh roll changes that.
            # A `"budget: gave up ... the node stopped answering"` failure
            # used to be lumped in with that and skipped too, on the theory
            # that a second pass would just burn the same time again for
            # the same outcome. Measured live: it does not -- a node can
            # be transiently slow or backed up behind other requests on one
            # attempt and answer fine on the next, and a report of "the
            # node stopped answering" is not a claim about the code at all,
            # so there is nothing here for the restart to be certain about.
            # Skipping straight to FAILED after a single timed-out attempt
            # is the actual bug the operator is pointing at, not intended
            # behaviour.
            no_mock = _no_mock(res)
            # A repeated, byte-identical crossref finding is decided
            # already -- see `_repeated_interface_defect` -- so a restart
            # (a fresh roll on the theory the previous attempts were an
            # unlucky draw) and an escalation (a stronger model, on the
            # theory this model specifically was the problem) both assume
            # something this evidence already rules out. Skipping both
            # goes straight to `replan_component`'s existing gate further
            # down, which fires unchanged since `gave_up_early` stays
            # False for this case (it is not a missing mock, a timed-out
            # node, or an unreachable one).
            skip_to_replan = _repeated_interface_defect(res)
            if skip_to_replan:
                sys.stderr.write(
                    "  [%-18s] the same CONTRACT-vs-code mismatch repeated "
                    "on %d attempts -- skipping the restart and any model "
                    "escalation, going straight to a CONTRACT/SPEC "
                    "reconsideration\n"
                    % (component.name[:18],
                       len([h for h in res["history"]
                           if h.get("stage") == "interfaces"])))
            restart_node, restart_model = node, model
            if not res["ok"] and not no_mock and not skip_to_replan:
                # A restart here is a genuinely independent second roll --
                # its whole reason to exist is dropping the accumulated
                # repair history and trying again from the plain spec --
                # so there is no reason it has to stay on the one node
                # that just failed, any more than the budget-exhaustion
                # rung further down has to. If the fleet has other
                # capacity sitting idle *right now*, this restart races
                # against it too, not only the specific "node stopped
                # answering" case below: a restart is a restart either
                # way, and racing one can only ever finish sooner, never
                # later, than waiting it out on a single box first.
                idle_others = pick_idle_race_candidates(
                    cfg, state, node.name, component.floor, family=restrict)
                if idle_others:
                    race_candidates = [(node, model)] + idle_others
                    sys.stderr.write(
                        "  [%-18s] %d attempt(s) exhausted -- %d other "
                        "box(es) are idle right now, racing a fresh "
                        "restart against all of them: %s\n"
                        % (component.name[:18], res["attempts"],
                           len(idle_others),
                           ", ".join("%s/%s" % (n.name, m)
                                    for n, m in race_candidates)))
                    # Own-test gating (`_write_component`'s two-phase
                    # "with the generated test, then without it")
                    # deliberately does not carry over into a race: the
                    # oracle already got its two attempts on the initial
                    # try, and composing that logic across several
                    # concurrent candidates would multiply the oracle's
                    # attempt budget by however many boxes happen to be
                    # idle, which is not what "two attempts" was meant to
                    # bound. Plain gates only, same simplification the
                    # budget-exhaustion race below already makes.
                    res, restart_node, restart_model = race_generate_file(
                        race_candidates, component.spec,
                        os.path.join(root, component.path), cfg, state,
                        attempts=repair, answer_tokens=answer_tokens,
                        root=root, extra=extra, env_extra=component_env,
                        component_label=component.path, mock=mock,
                        expected_counts=expected_counts,
                        implied_nonempty=implied_nonempty,
                        dep_paths_val=dep_paths(component, done),
                        forbid_required_cli_args=is_chain_entry_point,
                        env_names=env_vocabulary(cfg, root),
                        original_request=request)
                    # `race_generate_file` returns a real result even when
                    # every candidate lost -- "won" is only true of that
                    # result when `ok` actually is, and printing "won the
                    # race" over a failure the race never produced would
                    # misreport every candidate as having lost cleanly
                    # rather than say what actually happened.
                    if res["ok"]:
                        sys.stderr.write(
                            "  [%-18s] %s won the restart race\n"
                            % (component.name[:18],
                               "%s/%s" % (restart_node.name, restart_model)))
                        _log_attempt(
                            "won a %d-way idle race on the fresh restart "
                            "(%s/%s)" % (len(race_candidates),
                                        restart_node.name, restart_model),
                            res)
                    else:
                        sys.stderr.write(
                            "  [%-18s] raced a fresh restart against %d "
                            "idle box(es); none succeeded\n"
                            % (component.name[:18], len(idle_others)))
                        _log_attempt(
                            "raced a %d-way idle restart, none succeeded "
                            "(last: %s/%s)" % (len(race_candidates),
                                              restart_node.name,
                                              restart_model), res)
                else:
                    sys.stderr.write("  [%-18s] %d attempt(s) exhausted, "
                                     "restarting the loop fresh\n"
                                     % (component.name[:18], res["attempts"]))
                    res = _write_component()
                    _log_attempt("fresh restart on %s/%s" % (node.name,
                                                             model), res)

            # Tracks wherever the most recent attempt actually ran, so a
            # message or a quality comparison after an escalation refers to
            # the box that just answered, not the one this worker started
            # on. `restart_node`/`restart_model` are `node`/`model`
            # unchanged whenever the restart above never ran or never
            # raced -- only a won restart race moves this.
            cur_node, cur_model = restart_node, restart_model
            # A node that timed out twice in a row is still not evidence
            # about quality -- it is evidence about that one box, so the
            # fix is a different box, of *any* quality at or above the
            # floor, not a *stronger* one. `pick_fallback_writer` is the
            # unconditional "just try someone else" this is; the quality
            # bar in `pick_stronger_writer` below is deliberately not
            # applied here, because a tie or even a downgrade still beats
            # a box that is not answering at all. A raw connection failure
            # (`_last_stage_is_unreachable`) is the same shape of evidence
            # as a budget timeout -- the box did not answer, not "answered
            # wrong" -- so it takes the identical fallback path.
            if not res["ok"] and (_last_stage_is_budget(res)
                                  or _last_stage_is_unreachable(res)):
                # More than one other box sitting idle at exactly this
                # moment is not a case `pick_fallback_writer`'s "try the
                # single best one" answers well: trying the top-ranked
                # idle node, waiting out its whole attempt budget, and
                # only then trying the next idle one in turn wastes
                # whichever of them would actually have answered
                # fastest, on a fleet that had every bit of that spare
                # capacity free to spend at once. So ask for every idle
                # candidate first, and only fall back to the single-pick
                # path when there genuinely is no race to run -- zero
                # idle candidates (pick_fallback_writer still tries the
                # least-bad busy node rather than nothing) or exactly
                # one (nothing to race it against).
                idle_candidates = pick_idle_race_candidates(
                    cfg, state, cur_node.name, component.floor,
                    family=restrict)
                if len(idle_candidates) >= 2:
                    sys.stderr.write(
                        "  [%-18s] %s stopped answering -- %d other box(es) "
                        "are idle right now, racing all of them: %s\n"
                        % (component.name[:18], cur_node.name,
                           len(idle_candidates),
                           ", ".join("%s/%s" % (n.name, m)
                                    for n, m in idle_candidates)))
                    res, fb_node, fb_model = race_generate_file(
                        idle_candidates, component.spec,
                        os.path.join(root, component.path), cfg, state,
                        attempts=max(1, repair - 2),
                        answer_tokens=answer_tokens, root=root, extra=extra,
                        env_extra=component_env,
                        component_label=component.path, mock=mock,
                        expected_counts=expected_counts,
                        implied_nonempty=implied_nonempty,
                        dep_paths_val=dep_paths(component, done),
                        forbid_required_cli_args=is_chain_entry_point,
                        env_names=env_vocabulary(cfg, root),
                        original_request=request)
                    # Same distinction as the restart race above: a
                    # result from `race_generate_file` is only a win when
                    # `ok` says so, and every candidate can still lose.
                    if res["ok"]:
                        sys.stderr.write(
                            "  [%-18s] %s won the race\n"
                            % (component.name[:18], "%s/%s" % (fb_node.name,
                                                                fb_model)))
                        _log_attempt(
                            "won a %d-way idle race on %s/%s (the previous "
                            "box stopped answering)"
                            % (len(idle_candidates), fb_node.name, fb_model),
                            res)
                    else:
                        sys.stderr.write(
                            "  [%-18s] raced %d idle box(es) after %s "
                            "stopped answering; none succeeded\n"
                            % (component.name[:18], len(idle_candidates),
                               cur_node.name))
                        _log_attempt(
                            "raced a %d-way idle fallback, none succeeded "
                            "(last: %s/%s)" % (len(idle_candidates),
                                              fb_node.name, fb_model), res)
                    cur_node, cur_model = fb_node, fb_model
                else:
                    fallback = pick_fallback_writer(cfg, state,
                                                    cur_node.name,
                                                    component.floor,
                                                    family=restrict)
                    if fallback:
                        fb_node, fb_model = fallback
                        sys.stderr.write(
                            "  [%-18s] %s stopped answering -- trying "
                            "%s/%s instead\n"
                            % (component.name[:18], cur_node.name,
                               fb_node.name, fb_model))
                        res = codegen.generate_file(
                            component.spec,
                            os.path.join(root, component.path),
                            fb_node, fb_model, cfg, state, check=None,
                            attempts=max(1, repair - 2),
                            answer_tokens=answer_tokens,
                            thinking=thinking_tokens(cfg, fb_model),
                            root=root, extra=extra, verbose=False,
                            env_extra=component_env, rejected=rejected,
                            sent_count=sent_count, count_check=count_check,
                            dep_paths=dep_paths(component, done),
                            forbid_required_cli_args=is_chain_entry_point,
                            env_names=env_vocabulary(cfg, root),
                            original_request=request)
                        _log_attempt(
                            "fallback node %s/%s (the previous box "
                            "stopped answering)" % (fb_node.name, fb_model),
                            res)
                        cur_node, cur_model = fb_node, fb_model
                    cur_node, cur_model = fb_node, fb_model

            # Everything below this line reads a failure as a verdict on
            # the model or the plan, neither of which a timed-out node, an
            # unreachable node, or a missing `--api` has any bearing on --
            # so all three are excluded here, same as before.
            gave_up_early = (no_mock or _last_stage_is_budget(res)
                            or _last_stage_is_unreachable(res))
            # Two rolls on the same model failing the same way could mean
            # the model, not the plan, is the problem -- a possibility
            # nothing above this line has ever tested, since both the
            # retry loop and the restart above stay on whichever
            # `(node, model)` this worker thread was bound to. Tried once,
            # only if the fleet actually offers something better and only
            # after the restart above has already failed -- see
            # `pick_stronger_writer` for why a tie does not count and why
            # a `model_bias`-suppressed fallback (kept in reserve for
            # exactly this) is still eligible here even though it is
            # excluded from routine selection everywhere else.
            if not res["ok"] and not gave_up_early and not skip_to_replan:
                stronger = pick_stronger_writer(cfg, state, cur_model,
                                                component.floor,
                                                family=restrict)
                if stronger:
                    esc_node, esc_model = stronger
                    sys.stderr.write(
                        "  [%-18s] still failing on %s/%s -- escalating to "
                        "%s/%s for one more attempt\n"
                        % (component.name[:18], cur_node.name, cur_model,
                           esc_node.name, esc_model))
                    # `swarm.node_claim` inside `generate_file` is what
                    # makes this respect the same lock every other writer
                    # on that node waits on -- an escalation to a busy box
                    # queues behind whatever is already running there
                    # rather than pre-empting it, the same as any other
                    # request for that node/model pair.
                    res = codegen.generate_file(
                        component.spec, os.path.join(root, component.path),
                        esc_node, esc_model, cfg, state, check=None,
                        attempts=max(1, repair - 2),
                        answer_tokens=answer_tokens,
                        thinking=thinking_tokens(cfg, esc_model), root=root,
                        extra=extra, verbose=False,
                        env_extra=component_env, rejected=rejected,
                        sent_count=sent_count, count_check=count_check,
                        dep_paths=dep_paths(component, done),
                        forbid_required_cli_args=is_chain_entry_point,
                        env_names=env_vocabulary(cfg, root),
                        original_request=request)
                    _log_attempt("escalated to %s/%s"
                                 % (esc_node.name, esc_model), res)
            # Two independent rolls -- the original attempts, then a full
            # restart from a clean slate -- failing the same way is no longer
            # evidence about the code. `gate_interfaces` already catches the
            # cheap half of this class mechanically, one AST walk per
            # attempt: a call to a method a dependency does not define. What
            # it cannot do is notice that the CONTRACT never gave that method
            # to anyone in the first place, so nothing was ever going to
            # define it. Measured live: a CONTRACT omitted a version-creating
            # method the plan's own components required, the entry point
            # guessed a name and signature for it, and twelve attempts across
            # two full passes produced twelve variations of the same
            # unsatisfiable call -- the CONTRACT was the one place positioned
            # to prevent it and nothing here had ever asked it to reconsider.
            #
            # Skipped for the same reason the restart above is: a component
            # that gave up early did not fail twice, it never got a fair
            # second attempt, so there is nothing yet to read as a verdict on
            # the plan.
            if not res["ok"] and not gave_up_early:
                if res["history"]:
                    last = res["history"][-1]
                    component.error = "%s: %s" % (
                        last.get("stage"), why_it_failed(last.get("error") or ""))
                fix = replan_component(request, component.contract, component,
                                       done, cfg, state, root)
                if fix:
                    sys.stderr.write(
                        "  [%-18s] the contract or spec looks wrong, not "
                        "just the code -- asking the planner to reconsider\n"
                        % component.name[:18])
                    if fix.get("contract"):
                        component.contract = fix["contract"]
                    component.spec = fix["spec"]
                    sib_path = fix.get("sibling_path")
                    if sib_path:
                        sib = next((c for c in done.values()
                                   if c.path == sib_path and c.ok), None)
                        if sib is None:
                            sys.stderr.write(
                                "  [%-18s] the fix names %s, but it is not "
                                "an already-built dependency; skipping the "
                                "patch\n" % (component.name[:18], sib_path))
                        else:
                            sys.stderr.write(
                                "  [%-18s] patching %s: %s\n"
                                % (component.name[:18], sib.path,
                                   fix["sibling_add"]))
                            patch = codegen.generate_file(
                                "%s\n\nADD this to the file. Keep every "
                                "existing method, field and behaviour "
                                "exactly as it is; only add what follows: "
                                "%s" % (sib.spec, fix["sibling_add"]),
                                os.path.join(root, sib.path), node, model,
                                cfg, state, attempts=2,
                                answer_tokens=answer_tokens,
                                thinking=thinking_tokens(cfg, model),
                                root=root,
                                extra=("This file already exists and other "
                                      "files depend on it. Its current, "
                                      "complete content is:\n\n```\n%s\n```"
                                      % sib.code),
                                verbose=False, env_extra=component_env,
                                env_names=env_vocabulary(cfg, root))
                            if patch["ok"]:
                                sib.code = patch.get("code") or sib.code
                                with lock:
                                    done[sib.name] = sib
                                _checkpoint()
                                extra += (
                                    "\n\n%s was just corrected to add %s. "
                                    "Its current, complete content is:\n\n"
                                    "```\n%s\n```"
                                    % (sib.path, fix["sibling_add"], sib.code))
                            else:
                                sys.stderr.write(
                                    "  [%-18s] could not patch %s; leaving "
                                    "it as written\n"
                                    % (component.name[:18], sib.path))
                    res = _write_component()
                    _log_attempt("after CONTRACT/SPEC replan on %s/%s"
                                 % (node.name, model), res)
            component.ok = res["ok"]
            component.code = res.get("code") or ""
            component.target = res["target"]
            component.attempts = res["attempts"]
            component.seconds = res["seconds"]
            if res["ok"]:
                # A retry restores the previous failure onto the component so
                # the writer can be told what went wrong. Succeeding has to
                # retract it, or the saved plan and the session history both
                # record a passing file alongside the error it no longer has,
                # and a later planner reads that as a file still in trouble.
                component.error = ""
            if not res["ok"] and res["history"]:
                last = res["history"][-1]
                component.error = "%s: %s" % (
                    last.get("stage"), why_it_failed(last.get("error") or ""))
            with lock:
                done[component.name] = component
                inflight.pop(key, None)
                idle[key] = (my_rate, floor)
            _checkpoint()
            # `component.error` above is computed either way, but printing
            # only this summary line and never that error left a FAILED
            # component looking like a bare fact with no reason attached --
            # `generate_file` runs with `verbose=False` here (parallel
            # components would otherwise interleave six components' worth
            # of per-attempt chatter into one unreadable stream), so this
            # line is the *only* thing the operator ever sees for it, and
            # it said nothing about why. Measured live: a one-endpoint
            # component failed 6 attempts, restarted, failed 6 more, and
            # the entire generate.log for it read "FAILED after 6
            # attempt(s), 10m33s" -- the actual cause (already sitting in
            # `component.error`, the same string a retry or a replan would
            # have been shown) never printed anywhere.
            sys.stderr.write("  [%-18s] %s after %d attempt(s), %s%s\n"
                             % (component.name[:18],
                                "ok" if res["ok"] else "FAILED",
                                res["attempts"], swarm.human(res["seconds"]),
                                ("  -- " + component.error)
                                if not res["ok"] and component.error else ""))
            # The line above is a verdict on the *final* attempt only, and
            # a component that eventually succeeded retracts `.error`
            # right above -- so a component that failed its first six
            # attempts, restarted, and then passed prints exactly "ok
            # after 1 attempt(s), 1m31s" with no trace that anything ever
            # went wrong. Measured live: asked afterwards what the first
            # attempts on an already-succeeded component had actually
            # failed on, there was nothing to point to anywhere --
            # `generate_file` ran with `verbose=False` (parallel
            # components would otherwise interleave), `component.error`
            # only ever survives for a component that is *currently*
            # FAILED, and `save_plan` persists that same field, so it
            # vanishes from disk too the instant the component passes.
            # `history_trail` was built for exactly this and, before this
            # line existed, was only ever read by `replan_request` (never
            # reached for a component that succeeded) or printed in the
            # whole-run GIVE UP banner (never reached either). So: print
            # it here, unconditionally, whenever it is non-empty --
            # succeeded or not, since "why did this need three rungs
            # before it passed" is exactly as real a question about a
            # component that now says "ok" as about one that still says
            # "FAILED".
            trail = getattr(component, "history_trail", None)
            if trail:
                sys.stderr.write(
                    "  [%-18s] needed %d rung(s) before this result:\n"
                    % (component.name[:18], len(trail)))
                for line in trail:
                    sys.stderr.write("      " + line + "\n")
            # `generate_file` runs with verbose=False here for the exact
            # reason noted above -- and an advisory note (a malformed
            # platform link, an output.json key holding the wrong
            # resource's id) is exactly as real a thing to have found
            # whether or not verbose happened to be on. It used to be
            # printed only when verbose=True, which meant a parallel
            # component's advisory notes were not merely delayed, they
            # were gone: nothing else in this pipeline ever reads them,
            # so `codegen.generate_file` now returns them in `notes`
            # regardless of `verbose`, and this is the one place they
            # can be printed without interleaving one component's output
            # into another's -- by the time `res` exists, this
            # component's own generation has already finished.
            # Deduped again here, not only inside generate_file: a
            # result dict can also arrive from race_generate_file (the
            # winning candidate's own notes, already deduped by
            # generate_file) or from any other caller that assembles one
            # by hand, and this is the one place that has to be right
            # regardless of which path produced it.
            notes = codegen._dedupe_preserve_order(res.get("notes") or [])
            if notes:
                sys.stderr.write(
                    "  [%-18s] %d advisory note(s) from generation "
                    "(non-blocking):\n"
                    % (component.name[:18], len(notes)))
                for note in notes:
                    sys.stderr.write("      " + note + "\n")

    # Workers poll for one floor each -- 4 and 2 -- and `claim` matches it
    # exactly, so a component labelled 3 belongs to nobody: it is never
    # claimed, `pending` never empties, and every worker sleeps and retries
    # until killed. That is a silent deadlock with no error and no CPU, which
    # is the worst shape a hang can take, and the planner only has to write one
    # unexpected digit to cause it. Round to a tier that exists, upwards, so an
    # unusual floor costs a stronger machine rather than the whole run.
    for component in components:
        wanted = 4 if component.floor >= 3 else 2
        if component.floor != wanted:
            sys.stderr.write("  [%-18s] floor %d has no worker; running it at "
                             "%d\n" % (component.name[:18], component.floor,
                                       wanted))
            component.floor = wanted

    threads: List[threading.Thread] = []
    for node, model in strong:
        threads.append(threading.Thread(target=worker, args=(node, model, 4),
                                        daemon=True))
    for node, model in light:
        threads.append(threading.Thread(target=worker, args=(node, model, 2),
                                        daemon=True))
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    return sum(1 for c in components if c.ok), time.monotonic() - started


def integration_gate(check: str, components: List[intent.Component],
                     cfg: swarm.Config, state: swarm.State,
                     answer_tokens: int, root: str,
                     rounds: int = 2) -> bool:
    """Run the whole-package check once every file exists, and repair failures.

    A per-file gate proves a file parses and imports. It cannot prove the
    pieces agree with each other, which is exactly where independently written
    components go wrong. So the real test runs here, and when it fails the
    error goes back to the files it actually names rather than to everyone.
    """
    by_path = {c.path: c for c in components}
    for attempt in range(1, rounds + 1):
        ok, out = codegen.run_command(check, root, timeout=600)
        if ok:
            pages = codegen.page_console_errors(root)
            if pages:
                ok = False
                out = pages
        if ok:
            sys.stderr.write("  integration check passed\n")
            return True
        verdict = check_verdict(out)
        first = (verdict.strip().splitlines() or ["check failed"])[0]
        # sys.stderr, not print() -- same buffering reason as
        # interface_gate above: stdout is block-buffered the instant it
        # is redirected to a file (every generated orchestrate.sh does
        # `> generate.log 2>&1`), so a print()'d failure reason can sit
        # unflushed for the whole remaining repair loop while the
        # process is still running.
        sys.stderr.write("  integration check failed: %s\n" % first[:120])
        if attempt == rounds:
            break

        full = out
        out = verdict
        blamed_names, how = blame_for_check(root, full, check)
        blamed = [p for p in by_path
                  if by_path[p].ok and os.path.basename(p) in blamed_names]
        if blamed and how == "loaded":
            sys.stderr.write("  check names no file; repairing what it "
                             "loads: %s\n" % ", ".join(
                                 os.path.basename(p) for p in blamed))
        elif blamed and how == "called":
            sys.stderr.write("  check's failing line calls into %s\n"
                             % ", ".join(os.path.basename(p) for p in blamed))
        elif blamed and how == "produced":
            sys.stderr.write("  check measures a value produced by %s\n"
                             % ", ".join(os.path.basename(p) for p in blamed))
        if not blamed:
            sys.stderr.write("  failure names no generated file; fix by "
                             "hand\n")
            break
        if (attempt == 1 and blamed
                and not any(approach_for(root, p) for p in blamed)
                and recurring_failures(ralph_round_kinds(root))):
            stuck_approach(root, check, cfg, state)

        for path in blamed:
            component = by_path[path]
            calls = calls_from_check(root, out, check)
            try:
                with open(os.path.join(root, path),
                          encoding="utf-8", errors="replace") as fh:
                    current = fh.read(20_000)
            except OSError:
                current = ""
            mine = failures_for_file(root, full, check, path)
            spec = ("%s\n\nThe finished package fails this check:\n\n    %s\n\n"
                    "with this output:\n\n%s\n\n%s\n\nThe current file failed. "
                    "It is not a contract. Keep the public names the check "
                    "can call. A name the output says is not defined must "
                    "not be called, and must not be used except on the same "
                    "line as typeof that name. Do not keep a signature, a "
                    "default, or a comment that disagrees with the request "
                    "or with the calls above.\n\n```\n%s\n```"
                    % (component.spec, check, mine or out[-2000:], calls, current))
            note = failure_build_note(root, path, full, check)
            if note:
                spec += "\n\n" + note
            found = pick_writer(cfg, state, component.floor,
                                family=cfg.data.get("team", {}).get(
                                    "restrict_to_family"))
            if not found:
                sys.stderr.write("  no enabled node can write %s at all; "
                                 "skipping\n" % path)
                continue
            node, model = found
            if int(cfg.model_meta(model).get("capability", 1)) < component.floor:
                sys.stderr.write("  no floor-%d writer available; repairing "
                                 "%s on %s/%s anyway\n"
                                 % (component.floor, path, node.name, model))
            else:
                sys.stderr.write("  repairing %s on %s/%s\n"
                                 % (path, node.name, model))
            codegen.generate_file(
                spec, os.path.join(root, path), node, model, cfg, state,
                check=scoped_check_command(check, path), attempts=4,
                answer_tokens=answer_tokens,
                thinking=thinking_tokens(cfg, model), root=root, verbose=False,
                env_names=env_vocabulary(cfg, root))
    return False


def interface_gate(components: List[intent.Component], cfg: swarm.Config,
                   state: swarm.State, answer_tokens: int, root: str,
                   rounds: int = 2, boilerplate: str = "",
                   mock: Optional[Any] = None,
                   env_extra: Optional[Dict[str, str]] = None) -> bool:
    """Check that the parts refer to each other correctly, and fix them if not.

    This is the gate the per-file ones cannot be: a component is checked
    against what its neighbours actually define rather than against what it
    imagined they define. Every defect in two real runs was of that kind, and
    all of them survived parse, import, the smoke run and a model review.

    The findings double as repair instructions, which is why this can be a
    loop rather than a report. `imports PlayerShip from collision.py, which
    does not define it -- it defines: check_collision, ...` is precisely what
    a writer needs, and unlike a review it cannot be wrong: it is read off the
    syntax tree of the file being cited.

    Only the file carrying the finding is rewritten, and only its own spec plus
    the finding is sent, so a mismatch in one corner cannot cascade into
    rewriting a package that works.

    `boilerplate` is `cmd_do`'s own `attached_text` -- the env var names
    ("read API_BASE_URL/API_KEY from the environment, never hardcode a
    hostname"), the mock's base-URL note, and any attached reference
    material every ordinary write already receives via `run_components`'s
    `attached=` argument. This repair call was the one place in the pipeline
    that still built its own prompt from scratch and left all of that out.
    Measured live: a component that correctly read `API_BASE_URL` on its
    first pass got flagged for an unrelated interface mismatch
    (`requests.HTTPError` on a wrapper class), and the repair rewrite that
    fixed the mismatch also produced a file that hardcoded
    `https://api.example.com` and `"Bearer YOUR_API_TOKEN"` -- because
    nothing in this call's prompt ever told it there was an environment
    variable to read in the first place. The dependency context below
    already carries a fix for a cross-file mismatch; this carries the
    reason the file needs no *invented* facts to fill in around it.
    """
    paths = [c.path for c in components if c.ok]
    if not paths:
        return True

    deps = {c.name: list(c.deps) for c in components if c.ok}
    paths_by_component = {c.name: c.path for c in components if c.ok}
    for attempt in range(rounds + 1):
        findings = crossref.scan(paths, root, deps, paths_by_component)
        if not findings:
            if attempt:
                sys.stderr.write("  interfaces line up after repair\n")
            else:
                sys.stderr.write("\n%d file(s) refer to each other "
                                 "correctly.\n" % len(paths))
            return True

        # sys.stderr, not print() -- every call site below this one
        # (`generate_file`'s own per-attempt progress, `pick_writer`'s
        # caller two lines down) already writes to stderr specifically
        # because it is unbuffered, while stdout is fully block-buffered
        # the instant it is redirected to a file rather than a terminal --
        # exactly what every orchestrate.sh-generated wrapper does
        # (`> generate.log 2>&1`). Measured live: a `generate.log` tailed
        # mid-run showed "repairing main.py on e2b-2/gemma4:e2b" with no
        # explanation anywhere above it, because the finding text below
        # was still sitting in Python's own stdout buffer, unflushed,
        # while the process was still running (and, per the fix above,
        # taking a long time on a slow node) -- an operator watching the
        # log had no way to tell a real defect was found from a false
        # alarm, since the one line that says which is print()'d, not
        # written.
        sys.stderr.write(("\ninterface problems between files:" if not attempt
                          else "\nstill mismatched:") + "\n")
        for f in findings:
            sys.stderr.write("  " + f.text() + "\n")
        if attempt == rounds:
            sys.stderr.write("  not resolved after %d round(s); fix by "
                             "hand\n" % rounds)
            return False

        by_path = {c.path: c for c in components}
        grouped = crossref.group_by_file(findings)
        repaired = 0
        for path, items in grouped.items():
            component = by_path.get(path)
            if component is None:
                continue
            detail = "\n".join(
                "  - line %d: %s%s" % (f.line, f.message,
                                       ("; " + f.detail) if f.detail else "")
                for f in items)
            spec = ("%s\n\nIMPORTANT: this file does not fit the rest of the "
                    "package. These are facts read from the other files, not "
                    "opinions:\n%s\n\nFix only these problems. Use the names "
                    "that actually exist, and keep everything else in the file "
                    "exactly as it is." % (component.spec, detail))
            restrict = cfg.data.get("team", {}).get("restrict_to_family")
            found = pick_writer(cfg, state, component.floor, family=restrict)
            if not found:
                sys.stderr.write("  no enabled node can write %s at all; "
                                 "skipping\n" % path)
                continue
            node, model = found
            if int(cfg.model_meta(model).get("capability", 1)) < component.floor:
                sys.stderr.write("  no floor-%d writer available; repairing "
                                 "%s on %s/%s anyway\n"
                                 % (component.floor, path, node.name, model))
            else:
                sys.stderr.write("  repairing %s on %s/%s\n"
                                 % (path, node.name, model))
            dep_ctx = intent.dependency_context(
                component, {c.name: c for c in components if c.ok})
            out_path = os.path.join(root, path)
            gen_kwargs = dict(
                check=None, attempts=2, answer_tokens=answer_tokens,
                root=root, extra=(dep_ctx + boilerplate),
                env_extra=env_extra, mock=mock,
                env_names=env_vocabulary(cfg, root))
            # A repair here used to call `generate_file` with no
            # `env_extra` at all, regardless of whether this run has a
            # mock running. Without it, `codegen.local_urls` rewrites
            # any real `API_BASE_URL` the ambient environment happens to
            # carry to the dead `127.0.0.1:1` sink, so `gate_smoke`
            # always took the "no mock configured" free pass -- an
            # interface repair for an `--api` component was validated by
            # import/parse alone, never actually run against the mock
            # the way every ordinary write attempt is. Now the same
            # shared mock env `run_components` already built for this
            # run's ordinary attempts is threaded through here too.
            #
            # This call also had none of `run_components`' own idle-race
            # protection: a single `pick_writer` pick, committed to
            # unconditionally, with no fallback if that node turns out
            # to be slow. Measured live: two successive repair rounds on
            # the same file both landed on this fleet's slowest,
            # most-often-asleep box, and the run visibly stalled for
            # close to half an hour with no other node ever tried. If
            # other capacity is idle *right now*, race this repair
            # against it too, the same way an ordinary restart already
            # does -- zero or one idle alternatives falls through to the
            # unchanged single-node call below.
            idle_others = pick_idle_race_candidates(
                cfg, state, node.name, component.floor, family=restrict)
            if idle_others:
                race_candidates = [(node, model)] + idle_others
                sys.stderr.write(
                    "  %d other box(es) idle -- racing this repair "
                    "against all of them: %s\n"
                    % (len(idle_others),
                       ", ".join("%s/%s" % (n.name, m)
                                for n, m in race_candidates)))
                res, won_node, won_model = race_generate_file(
                    race_candidates, spec, out_path, cfg, state,
                    attempts=2, answer_tokens=answer_tokens, root=root,
                    extra=(dep_ctx + boilerplate), env_extra=env_extra,
                    component_label=path, mock=mock)
                if res["ok"]:
                    sys.stderr.write("  %s/%s won the repair race\n"
                                     % (won_node.name, won_model))
                else:
                    sys.stderr.write("  raced repair against %d idle "
                                     "box(es); none succeeded\n"
                                     % len(idle_others))
            else:
                res = codegen.generate_file(
                    spec, out_path, node, model, cfg, state,
                    thinking=thinking_tokens(cfg, model), verbose=False,
                    **gen_kwargs)
            # `component.history_trail`/`attempts`/`seconds` are what
            # `save_plan` persists and `bulk_plan_report.py` reads back
            # across many runs -- and this repair call used to update
            # none of them, so the interface-repair rung that caused the
            # actual live stall this file's own comments above describe
            # was invisible to both, even after the component's ordinary
            # ladder had already recorded its ok result. Recorded here
            # the same way `run_components`' own `_log_attempt` records
            # every other rung, success or failure, since "how long did
            # the interface repair take, and did it need a race" is
            # exactly the question a bulk debug pass over successful
            # runs needs an answer to.
            if not hasattr(component, "history_trail"):
                component.history_trail = []
            component.attempts = int(getattr(component, "attempts", 0) or 0) \
                + int(res.get("attempts") or 0)
            component.seconds = float(getattr(component, "seconds", 0.0) or 0.0) \
                + float(res.get("seconds") or 0.0)
            component.history_trail.append(
                "[interface repair on %s/%s] %s (%s)"
                % (node.name, model, "ok" if res["ok"] else "FAILED",
                   swarm.human(res.get("seconds") or 0.0)))
            if res["ok"]:
                repaired += 1
        if not repaired:
            sys.stderr.write("  nothing could be repaired; fix by hand\n")
            return False
    return False


def depends_on(component: intent.Component, owner_path: str,
               by_path: Dict[str, intent.Component]) -> bool:
    """Whether this component was actually handed the owner's finished source.

    Only a dependency can be imported from: the source of a non-dependency was
    never in the prompt, and the arrow may well point the other way, in which
    case importing back is a cycle.
    """
    owner = by_path.get(owner_path)
    return owner is not None and owner.name in component.deps


def repair_redefinitions(components: List[intent.Component],
                         clashes: List[Tuple[str, str, str]],
                         cfg: swarm.Config, state: swarm.State,
                         check: Optional[str], answer_tokens: int,
                         root: str, boilerplate: str = "") -> bool:
    """Rewrite the duplicating file to import instead of redeclare.

    `boilerplate` is the same `attached_text` `interface_gate` now also
    receives, for the identical reason: this call to `codegen.generate_file`
    used to pass no `extra` whatsoever, so a redefinition repair had even
    less to go on than an interface repair did, and a rewrite pulled into
    this path can invent the same hardcoded host/credential a rewrite
    pulled into `interface_gate` already did.
    """
    by_path = {c.path: c for c in components}
    grouped: Dict[str, List[Tuple[str, str]]] = {}
    for path, symbol, owner in clashes:
        grouped.setdefault(path, []).append((symbol, owner))

    any_fixed = False
    for path, items in grouped.items():
        component = by_path.get(path)
        if component is None:
            continue
        lines = []
        for symbol, owner in items:
            module = owner[:-3].replace(os.sep, ".")
            # Which instruction is possible depends on the direction of the
            # arrow. A file that depends on the owner was handed its source and
            # can import from it. A file that does not was handed nothing, and
            # telling it to import anyway is unsatisfiable in the ordinary case
            # and a circular import in the bad one -- so the only correct fix
            # is to delete the declaration. Measured: `constants.py`, which
            # depends on nothing, was told to import Shape from `shapes.py` and
            # rewrote the class both attempts before the loop gave up.
            if depends_on(component, owner, by_path):
                lines.append("  - delete your %s and use the real one: "
                             "`from %s import %s`" % (symbol, module, symbol))
            else:
                lines.append("  - delete %s entirely. %s owns it, this file "
                             "does not use it, and it must NOT be imported "
                             "here." % (symbol, owner))
        spec = ("%s\n\nIMPORTANT: the file you wrote declares names that "
                "belong to other files in this package:\n%s\n\nThis file is "
                "only responsible for what its description above asks for. "
                "Delete anything else it grew -- extra classes, a main() it "
                "was never asked for, a program loop -- and keep the rest "
                "exactly as it is." % (component.spec, "\n".join(lines)))
        # Band this like any other write. pick_role_model sorts by capability
        # first, which is right for judging and wrong here: swapping an import
        # for a duplicated class is routine, and handing it to the specialist
        # spends minutes on a mechanical edit.
        found = pick_writer(cfg, state, component.floor,
                            family=cfg.data.get("team", {}).get(
                                "restrict_to_family"))
        if not found:
            sys.stderr.write("  no enabled node can write %s at all; "
                             "skipping\n" % path)
            continue
        node, model = found
        if int(cfg.model_meta(model).get("capability", 1)) < component.floor:
            sys.stderr.write("  no floor-%d writer available; repairing %s "
                             "on %s/%s anyway\n"
                             % (component.floor, path, node.name, model))
        else:
            sys.stderr.write("  repairing %s on %s/%s\n" % (path, node.name, model))
        res = codegen.generate_file(
            spec, os.path.join(root, path), node, model, cfg, state,
            check=None, attempts=2, answer_tokens=answer_tokens,
            thinking=thinking_tokens(cfg, model), root=root, verbose=False,
            extra=boilerplate, env_names=env_vocabulary(cfg, root))
        if res["ok"]:
            component.code = res.get("code") or component.code
            any_fixed = True
    return any_fixed


def cmd_do(args, cfg: swarm.Config, state: swarm.State) -> int:
    """One entrypoint. Say what you want; the pool works out what that means.

    Having to announce that something is an audit, or wide, or worth splitting
    is the part that should not exist -- classifying a request is a language
    problem, and there are idle language models on the LAN to do it. A small
    fast model triages, and the work is routed from there.
    """
    request = " ".join(args.request).strip()
    # `--retry` never needs new request text -- it is reusing the saved
    # plan, and `--file`/`--error`/`--run` are how it says what to fix.
    # Reading stdin here anyway is a real hang, not a hypothetical one:
    # any caller that spawns this process with stdin as a pipe it never
    # explicitly closes -- exactly what `run_step`'s `team do --retry
    # --run` looks like from an orchestrator/agent subprocess wrapper
    # that inherits stdin without redirecting it -- blocks forever on
    # `sys.stdin.read()` waiting for an EOF nobody is ever going to send,
    # with nothing printed to say why. Measured directly: a subprocess
    # started with `stdin=PIPE` and never `communicate()`d against was
    # still running 6+ seconds later, every time, before this guard.
    if not request and not args.retry and not sys.stdin.isatty():
        request = sys.stdin.read().strip()
    root = project_root()
    if (args.file or args.error or args.run) and not args.retry:
        print("--file, --error and --run only do anything with --retry -- "
              "they name a file from the saved plan and the error to fix "
              "it with", file=sys.stderr)
        return 2
    if args.run and args.error:
        print("--run captures the failure itself by actually executing the "
              "file; --error is for pasting one you already have. Use "
              "one or the other, not both.", file=sys.stderr)
        return 2
    if not request and not args.retry:
        print("nothing to do", file=sys.stderr)
        return 2
    if args.retry and not request:
        request = _retry_restored_request(root, request)

    # A bare asset filename with no path at all is the shape that produced
    # a `main.py` resolving `survey.html` next to itself forever, against
    # the real absolute project directory, because nothing in the request
    # said it lived anywhere else -- not the scratch-sandbox version of
    # "not run yet" `_missing_sibling_error` exists for, a real, permanent
    # wrong-directory guess that no amount of retrying fixes. This cannot
    # be resolved on this side of the request -- there is no way to know
    # which sibling step actually produced it -- so it is surfaced here,
    # before planning spends anything, as something for the operator to
    # fix in the request text the same way a JSON hand-off already has to
    # be: `../04_create_survey/survey.html`, not `survey.html`.
    if not args.retry:
        for asset in intent.unqualified_sibling_asset_refs(request, root):
            print("  warning: request mentions %s with no path, and it "
                  "does not exist in this directory. If a previous step "
                  "created it, name its real relative path (e.g. "
                  "../04_create_survey/%s) -- otherwise the generated "
                  "code has no way to know where it lives and will guess "
                  "it is local, which fails against the real file every "
                  "time, not just until that step runs." % (asset, asset),
                  file=sys.stderr)

    # `--attach` states the whole set rather than adding to it, so passing it
    # with no paths is how an attachment is removed. Recorded before anything
    # else runs, so a clear takes effect even on the call that also fails for
    # some other reason -- an operator detaching a document that is breaking
    # their runs should not have to get the rest of the command right first.
    prior_attachments = session.attachments(root)
    if args.attach is not None and not args.retry:
        session.set_attachments(root, [attach.store(root, p)
                                       for p in args.attach])

    restrict = cfg.data.get("team", {}).get("restrict_to_family")

    kind, paths, scope = args.kind, [], "narrow"
    if args.retry:
        # A retry carries its own request and plan from the saved run, so
        # there is nothing to triage and nothing for the operator to retype.
        kind = "code"
    # "ask" answers with prose printed to stdout, for a human reading it
    # right then. `--api` is one way to know nobody is: it names a spec to
    # slice, a mock to stand up, source to hand to writers, none of which
    # means anything for a question being answered. But it is not the only
    # way, and scoping the rule to it was too narrow -- measured live, the
    # request that actually triggered this ("create a survey.html file")
    # carried no `--api` at all and would have been triaged "ask" the
    # identical way run as a bare `team do`, because nothing about the
    # request names an API; the orchestrator running it was the only fact
    # that made "ask" wrong, and that fact is visible directly.
    # `sys.stdout.isatty()` is false the moment output is redirected to a
    # file or a pipe -- exactly what every `generate.sh`/`orchestrate.sh`
    # this project's own boilerplate produces does to every `team do` call
    # inside it -- regardless of whether that call happens to name
    # `--api`. A human typing the command at a live terminal still gets
    # `True` and keeps "ask" available, since that really is a human
    # asking a question there.
    unattended = bool(args.api) or not sys.stdout.isatty()
    if not kind and intent.obvious_code(request, bool(args.check)):
        kind = "code"
        print("read as: code  (unambiguous, no triage needed)")
    if not kind:
        triage_target = pick_solvers(cfg, state, 1, count=1, family=restrict)
        if triage_target:
            node, model = triage_target[0]
            prompt = intent.TRIAGE_PROMPT.format(request=request)
            try:
                r = swarm.chat_complete(
                    node, model, [{"role": "user", "content": prompt}],
                    num_ctx=swarm.pick_num_ctx(cfg, node, model,
                                               swarm.est_tokens(prompt), 200,
                                               reasoning=False),
                    answer_tokens=120, headroom=1.6, think=False,
                    temperature=0.0, timeout=600)
                state.record_perf(node.name, model, r["sample"])
                state.mark_resident(node.name, model)
                t = intent.parse_triage(r["text"], root)
                kind, paths, scope = t.kind, t.paths, t.scope
                print("read as: %s%s%s  (via %s/%s)"
                      % (kind, ", wide" if scope == "wide" else "",
                         (", paths: " + ", ".join(paths)) if paths else "",
                         node.name, model))
            except swarm.OllamaError as exc:
                sys.stderr.write("triage failed (%s); treating as a question\n"
                                 % exc)
                kind = "ask"
        else:
            kind = "ask"

    if kind == "ask" and unattended and not args.kind:
        # An "ask" answer is prose printed to stdout, for a human reading
        # it right then -- an orchestrator has no one to read it, and this
        # is true whether the triage model chose "ask" itself, the triage
        # call errored, or no triage candidate was even available. Only
        # overrides an auto-triaged result: an explicit `--kind ask` is a
        # deliberate instruction and is left alone, unattended or not.
        print("read as: code, not ask  (stdout is not a live terminal, or "
             "--api was given -- an orchestrator has no one to read an "
             "answer, so ask is not a use case here)")
        kind = "code"

    if args.paths:
        paths = args.paths

    if kind == "audit":
        targets = paths or ["."]
        audit_args = argparse.Namespace(
            paths=[os.path.join(root, p) for p in targets], floor=2, n=3,
            no_second=False, keep_going=True, verbose=False, json=args.json)
        return cmd_audit(audit_args, cfg, state)

    if kind == "code":
        # Continuity across separate invocations: what this project's history
        # says was asked before, and what files already exist so a follow-up
        # request can edit them in place instead of the planner inventing a
        # second copy under a new name. Skipped entirely on --retry, which
        # already carries its own saved plan and needs none of this.
        context = ("" if args.retry else
                   session.context_for(root, public_names))
        # Snapshotted now, before anything is written, so a component whose
        # planner-chosen path reuses an existing file gets handed what that
        # file actually contains. Skipped on --retry: a failed attempt's
        # leftover file is the broken output being fixed, not prior work to
        # preserve, and that path already resupplies the exact error instead.
        existing_code: Dict[str, str] = {}
        if not args.retry:
            for name in os.listdir(root):
                full = os.path.join(root, name)
                # A straggler from a losing race/hedge candidate (see
                # `_race_scratch_path`) that finished writing after its
                # own call already returned is real Python on disk, but
                # it is not real project content -- reading it back here
                # would hand a later request's planner a phantom file
                # (and its fabricated/rejected code) that nobody asked
                # for and nothing in this project's history explains.
                if (os.path.splitext(name)[1].lower() in intent.WRITABLE
                        and os.path.isfile(full)
                        and not intent.is_race_scratch_name(name)):
                    try:
                        with open(full, encoding="utf-8", errors="replace") as fh:
                            existing_code[os.path.normpath(name)] = fh.read()
                    except OSError:
                        pass
        # A request naming no file at all ("make it dance faster") is a
        # question the planner cannot answer from names alone -- "faster" is
        # decided by whatever line actually holds the speed, and a name list
        # does not say which file that is. Reading bodies to answer that on
        # the scarce floor-4 planner itself would not scale to a larger
        # project; reading them locally, cheaply, on e2b does. Best-effort:
        # `ground` never raises, and an empty result changes nothing below.
        if existing_code and not args.no_ground and not _stored_active(root):
            grounded = ground.ground(request, existing_code, cfg, state)
            if grounded:
                context += "\n\n" + grounded
        elif _stored_active(root):
            sys.stderr.write("  stored set stays stored; not re-reading the project\n")
        # Attached reference material, plus anything named by `--paths`. The
        # two arrive differently -- one sticks to the project, the other is
        # named for this request -- but they are the same thing to a model
        # reading them, so they are rendered and budgeted as one set.
        #
        # `--paths` content used to be spliced in here directly: first four
        # files only, each cut at 6000 characters, every one fenced as
        # `python`. That is the truncation failure the whole-file rewrite path
        # already had, with a mislabelling bug on top -- a markdown design
        # note presented as Python to the models least able to notice.
        attach_paths = list(session.attachments(root))
        for p in paths:
            stored = attach.store(root, p)
            if stored not in attach_paths and os.path.isfile(attach.resolve(root, p)):
                attach_paths.append(stored)
        attached_text = ""
        if attach_paths:
            content, problems = attach.read(root, attach_paths)
            for problem in problems:
                print("  attachment skipped -- %s" % problem, file=sys.stderr)
            attached_text = attach.render(content)
            # Checked here, once, rather than per worker. An attachment goes
            # into every writer's prompt, so a per-worker check would attach
            # it on the boxes with room and drop it on the ones without,
            # leaving a package where some files were written against the
            # spec and some never saw it. Nothing downstream can tell.
            too_big = attach.check_size(attached_text, cfg)
            if too_big:
                # Roll back to whatever was attached before this call. An
                # attachment set that cannot be used must not become sticky:
                # it would refuse this run and then every unrelated request in
                # this directory afterwards, each time for a reason the
                # operator has to connect back to a flag they typed once.
                session.set_attachments(root, prior_attachments)
                print("attachments refused: %s" % too_big, file=sys.stderr)
                if args.attach:
                    print("  not attached. still attached: %s"
                          % (", ".join(prior_attachments) or "nothing"),
                          file=sys.stderr)
                return 1
            if content:
                print(attach.describe(content, cfg))
            context += attached_text

        # An API spec is sliced against this very request, rather than
        # attached whole. Separate from `--attach` and deliberately not
        # sticky: the slice is derived from the request, so carrying it into
        # the next one would attach the previous question's endpoints to a
        # different question. The registered spec stays; the cut does not.
        mock_server = None
        mock = None
        api_env: Dict[str, str] = {}
        chosen: List[Dict[str, Any]] = []
        api_name = getattr(args, "api", None)
        # Computed once, unconditionally, and reused below to also force
        # --single-file (see that block's own comment) -- this used to be
        # computed only inside `if api_name`, which meant a pure-static
        # request with no --api at all (e.g. a chain step whose steps.json
        # entry simply has no "api" key) never got this check run against
        # it either. Measured live: "create a survey.html that shows 5
        # point rating axes ..." with no --api anywhere in the call still
        # went through the full planner and came back as four files --
        # main.py, api_client.py, survey_generator.html, survey_logic.js
        # -- a fabricated API-client pipeline around content that named no
        # endpoint at all, in 13 minutes, and the actual HTML file it
        # produced was not even named what the request asked for
        # (survey_generator.html, not survey.html), which is why the next
        # chain step's own reference to survey.html then failed outright.
        static_only_file = intent.is_pure_static_file_request(request)
        if api_name and not args.retry:
            static_file = static_only_file
            if static_file:
                # Measured live: "create a survey.html" run under `--api
                # maven` still ran the full slicing/CONTRACT/mock pipeline,
                # `propose_multi` found "2 endpoints" for a request with no
                # possible use for any, and the CONTRACT built from them
                # biased the planner into inventing `survey_generator.py`
                # and `data_processor.py` around a static three-question
                # form that needed neither. A request this narrow -- one
                # verb, one non-Python filename, nothing else -- cannot
                # need an endpoint no matter what `--api` names, so the
                # flag is skipped for this call rather than trusted, the
                # same way `--single-file` already overrides the planner
                # mechanically when the request's own shape says so.
                print("  skipping --api %s: this request is nothing but "
                     "\"create %s\" -- a static file with no possible use "
                     "for an endpoint, so slicing one in would only bias "
                     "the plan" % (api_name, static_file))
                api_name = None
        if args.retry and not api_name:
            # The slice is derived from the request and a retry has no new
            # one, but the mock is not a slice -- it is the service the gates
            # talk to, and dropping it is why a retried client failed three
            # attempts against a dead port.
            api_name = (load_plan(root) or {}).get("api")
            if api_name:
                print("  --api %s, remembered from the run being retried"
                      % api_name)
        if api_name:
            try:
                import openapi
                spec = openapi.load(openapi.resolve(api_name))
            except (OSError, ValueError) as exc:
                print("--api %s: %s" % (api_name, exc), file=sys.stderr)
                return 1
            # The local model reads the whole index and names the endpoints
            # this request means, which term matching cannot do when the
            # request and the endpoint share no words. Free, on this
            # machine, and every suggestion is checked against the real
            # operation table before it is used. Skipped with --no-ground,
            # which already means "do not consult the local reader".
            #
            # Gated on `request` being non-empty rather than on `not
            # args.retry`: a retry's `request` is restored from the saved
            # plan just above this block now (it always existed in the
            # saved plan -- only the CLI's local variable used to stay
            # empty), so a retry re-slices against the exact original
            # request instead of skipping this whole block. Measured live:
            # a `create_task` step retried after a real 401 got the mock
            # back (the half this always did restore) but never got
            # `auth_block`/`connection_setup_block` back in its repair
            # prompt, because this block used to be skipped outright on
            # every retry -- the repair loop was fixing a credentials bug
            # with no reminder of how credentials are supposed to be
            # built. The one remaining genuinely-empty case (a decompose-
            # from-scratch retry with a request that was itself somehow
            # blank) still skips cleanly, same as a fresh `do` with no
            # request would.
            if request:
                hints, avoid = [], []
                if not args.no_ground:
                    hints, avoid = openapi.propose_multi(spec, request,
                                                         cfg, state)
                # What is left of the attachment ceiling once anything the
                # operator attached by hand is paid for. The slice trims
                # itself to fit instead of refusing, dropping its weakest
                # term matches -- those were guesses, while the endpoints
                # that make the others callable are not.
                headroom = attach.budget(cfg) - swarm.est_tokens(attached_text)
                # A standing "never" (`openapi.excluded_tags`, set via
                # `./openapi.py NAME --exclude-tag TAG`) is a fact about the
                # operator's preference for this service across every future
                # run, not a per-request judgement like `avoid` above -- so
                # it is read from the registry rather than from this one
                # sentence, and it holds even on a request that never
                # mentions the excluded area at all.
                api_text, chosen = openapi.slice_for(spec, request,
                                                     limit=args.api_limit,
                                                     hints=hints, avoid=avoid,
                                                     budget=headroom,
                                                     exclude_tags=openapi.excluded_tags(api_name))
                print("api %s: %d of %d operations, %d tokens"
                      % (args.api, len(chosen), len(openapi.operations(spec)),
                         swarm.est_tokens(api_text)))
                for entry in chosen[:8]:
                    print("    %-6s %s" % (entry["method"], entry["path"]))
                too_big = attach.check_size(attached_text + api_text, cfg)
                if too_big:
                    # Same rule as an oversize attachment, and the remedy is one
                    # the operator can act on: a smaller --api-limit, or --path
                    # on `openapi.py` to pick the endpoints by hand.
                    print("api slice refused: %s" % too_big, file=sys.stderr)
                    print("  try a smaller --api-limit (currently %d)"
                          % args.api_limit, file=sys.stderr)
                    return 1
                attached_text += api_text
                context += api_text

            # A stand-in for the service, built from the same document the
            # slice came from, listening on loopback. The gates run the
            # generated code, and `codegen`'s network guard stops that
            # reaching anything real -- which would leave an API client
            # unable to execute at all. This is what it executes against.
            #
            # It is not a stub that says yes. An invented route 404s and a
            # missing required field 422s, so the smoke run stops proving
            # only "it did not crash" and starts proving "it sent requests
            # the real service would have accepted".
            if not args.no_mock:
                try:
                    import mockapi
                    mock_server, mock, mock_url = mockapi.serve(spec)
                except Exception as exc:            # noqa: BLE001
                    print("  mock API unavailable (%s) -- gates will run "
                          "without one" % exc, file=sys.stderr)
                else:
                    api_env["API_BASE_URL"] = mock_url
                    print("  mock API on %s -- gates will exercise it"
                          % mock_url)
                    # The writers have to be told, or they will hardcode the
                    # host out of the spec's `servers` block and never reach
                    # it. Reading a base URL from the environment is what
                    # the code should do anyway.
                    base_note = (
                        "\n\nBASE URL: read the API base URL from the "
                        "environment variable API_BASE_URL, falling back to "
                        "the spec's own server URL when it is unset. Never "
                        "hardcode a hostname. This is how the code is tested "
                        "against a local stand-in for the service.\n")
                    attached_text += base_note
                    context += base_note

        # Credential vocabulary, not credentials. A `.env` is never read for
        # its values and never attached; what the pool gets is the list of
        # names, so generated code reaches for `STRIPE_API_KEY` rather than
        # inventing `STRIPE_KEY` or writing a plausible literal.
        #
        # The pool's own standard names lead that list. Without them a
        # writer picks its own, and three consecutive runs asked for
        # AUTH_TOKEN, API_KEY and API_AUTH_TOKEN -- each file consistent,
        # each run clean, and the operator exporting the previous name
        # every time. They come from config.json rather than from the
        # directory, because a name derived from whatever files are already
        # here is a different name in every new project, which is the same
        # problem arriving more slowly.
        secret_names = env_vocabulary(cfg, root)
        if secret_names:
            names_block = attach.render_env_names(secret_names)
            attached_text += names_block
            context += names_block
            print("env vars (names only, values never read): %s"
                  % ", ".join(secret_names))
        carried: List[intent.Component] = []
        replanned = False
        request_rewritten = False
        while True:
            saved = load_plan(root) if args.retry else None
            if args.retry and not saved:
                print("no previous run recorded for %s" % root, file=sys.stderr)
                return 1
            # A run that failed to decompose at all never had a component
            # to resume -- `saved["components"]` is `[]` on purpose (see
            # the save_plan call at the "could not decompose" branch
            # below), which used to be indistinguishable from "every
            # component in the last run already succeeded" (the ordinary
            # meaning of an empty failed-components list). That collision
            # made `--retry` on a totally-failed run print "nothing failed
            # in the last run; there is nothing to retry" and exit 0 --
            # actively wrong, since nothing had ever been attempted.
            # Treated here as its own case: re-run decomposition from the
            # saved request rather than the resume path below, using the
            # saved api/check as defaults the same way the ordinary resume
            # path already does.
            total_decompose_failure = bool(
                saved and saved.get("decompose_failed") and not saved.get("components"))
            if total_decompose_failure:
                # `--api` for a retry is already restored above, before this
                # loop, from the same saved plan (`api_name = (load_plan(root)
                # or {}).get("api")`) -- nothing further to do for it here.
                request = saved.get("request") or request
                if args.check is None and saved.get("check"):
                    args.check = saved["check"]
                print("  previous run never got past planning -- retrying "
                     "decomposition from scratch")
            if args.retry and not total_decompose_failure:
                restored = [intent.Component(c["name"], c["path"], c["floor"],
                                             c["deps"], c["spec"])
                            for c in saved["components"]]
                for comp, raw in zip(restored, saved["components"]):
                    comp.ok = raw["ok"]
                    comp.error = raw["error"]
                    comp.contract = saved.get("contract", "")
                    # Restored so a retry's own `replan_request` (fired if
                    # this retry also fails the whole-plan restart) still
                    # has the previous run's rungs to reason about, not
                    # just whatever this retry itself accumulates -- a
                    # plan saved before this field existed simply has
                    # none, which reads the same as "nothing happened
                    # yet," the correct fallback for an older plan file.
                    comp.history_trail = list(raw.get("history_trail") or [])
                    # A plan records what was attempted, not what was written,
                    # so a restored component carries no source -- and
                    # `dependency_context` hands over a dependency only when it
                    # has its code. A retried component therefore saw nothing
                    # of the files it was built on and guessed their interface,
                    # which is the failure that machinery exists to prevent:
                    # three attempts at a main.py importing `TaskResponse` and
                    # then `AppletEngine`, neither of which any file defines.
                    # The files are on disk, and disk is the better source
                    # anyway, being where a hand edit would land.
                    if comp.ok:
                        try:
                            with open(os.path.join(root, comp.path),
                                      encoding="utf-8", errors="replace") as fh:
                                comp.code = fh.read()
                        except OSError:
                            pass
                if args.run:
                    target_file = resolve_run_target(args.file, restored)
                    if not target_file:
                        print("--run needs --file PATH -- this plan has no "
                              "single obvious entry point to run on its own "
                              "(name the file explicitly)", file=sys.stderr)
                        return 1
                    if not os.path.isfile(os.path.join(root, target_file)):
                        print("--run: %s does not exist" % target_file,
                              file=sys.stderr)
                        return 1
                    print("running python3 %s to capture what actually "
                          "happens..." % target_file)
                    # A 502/503/504 is the platform failing to answer in
                    # time, not the code doing anything wrong --
                    # rerunning the identical script is the actual fix,
                    # and it needs no model, no code change, and no
                    # repair attempt spent. Purely mechanical: a regex
                    # match on the real captured output, tried a few
                    # times with a short pause before falling through to
                    # the ordinary repair path exactly as if this check
                    # did not exist.
                    code, output, gateway_retries = run_with_gateway_retry(
                        root, target_file)
                    if gateway_retries:
                        print("%s: saw a 502/503/504 (the platform, not "
                              "the code) and reran unchanged %d time(s)"
                              % (target_file, gateway_retries))
                    # Same shape, one rung more expensive: a version
                    # conflict is not transient, so this rewrites the
                    # colliding literal in the source (to a fresh uuid)
                    # rather than rerunning unchanged, then reruns for
                    # real -- still no model, no repair attempt, tried
                    # before anything here falls through to one.
                    if code is not None and code != 0:
                        code, output, version_retries = \
                            run_with_version_conflict_retry(root, target_file)
                        if version_retries:
                            print("%s: saw a version-already-exists "
                                  "rejection from the real API and replaced "
                                  "the colliding literal with a fresh uuid "
                                  "in the source %d time(s) -- no model or "
                                  "repair attempt spent"
                                  % (target_file, version_retries))
                    if code is None:
                        # The real API and real input, not the gate's typed
                        # stdin and dead-port mock -- a program legitimately
                        # waiting on a prompt is exactly what would hang
                        # here, and that is worth reporting rather than
                        # guessing at a fix for output that never arrived.
                        print("%s did not finish within the timeout (it may "
                              "be waiting on input); rerun by hand and use "
                              "--error @file with what you see"
                              % target_file, file=sys.stderr)
                        return 1
                    if code == 0:
                        print("ran clean (exit 0) -- nothing to retry. If "
                              "the output is wrong anyway, describe what's "
                              "wrong with --error instead of --run.")
                        return 0
                    args.file = target_file
                    # Only reached when the mechanical uuid-swap above
                    # either could not locate the colliding literal as
                    # its own quoted token, or the conflict recurred even
                    # after a fresh value -- the one case this project's
                    # own rule ("if the model isn't getting the
                    # information it needs, it should") calls for
                    # spending a real repair attempt. Named explicitly so
                    # the model does not re-propose the exact mechanical
                    # fix that was already tried and failed, and reaches
                    # instead for the actual defect: the value has to be
                    # generated in code, at call time, not just swapped
                    # once from the outside.
                    still_conflicting = looks_like_version_conflict_error(
                        output)
                    if still_conflicting:
                        args.error = (
                            "MECHANICAL NOTE: this failure is a "
                            "version-uniqueness conflict ('%s' was "
                            "rejected by the real API as already "
                            "existing). An automatic fix already tried "
                            "replacing that exact literal with a fresh "
                            "uuid.uuid4() value in the source and "
                            "rerunning for real -- and either the "
                            "conflict recurred, or that literal could not "
                            "be found as its own quoted string to safely "
                            "replace. Do not just swap in another fixed "
                            "literal. Generate this field's value from "
                            "uuid.uuid4() (or another source guaranteed "
                            "different on every run) in the code itself, "
                            "at call time, so a second run of this exact "
                            "script never collides again on its own.\n\n%s"
                            % (still_conflicting, output))
                    else:
                        args.error = output
                    print("captured a failure (exit %d, %d chars) -- "
                          "feeding it to the repair loop\n" % (code, len(output)))
                if args.file:
                    # The gates only saw the mock, typed stdin, and placeholder
                    # credentials -- a component can clear every one of those
                    # and still be wrong against the real service or real
                    # input, and there is nothing in the saved plan recording
                    # that, because nothing failed here. This is the same
                    # repair loop with the error supplied by the one thing
                    # that actually ran the code for real: the operator.
                    if not args.error:
                        print("--file needs --error TEXT (or --error @file) -- "
                              "the failure to fix it with", file=sys.stderr)
                        return 1
                    error_text = args.error
                    if error_text.startswith("@"):
                        try:
                            with open(error_text[1:], encoding="utf-8",
                                      errors="replace") as fh:
                                error_text = fh.read()
                        except OSError as exc:
                            print("could not read %s: %s"
                                  % (error_text[1:], exc), file=sys.stderr)
                            return 1
                    err, additions = apply_operator_error(
                        restored, args.file, error_text)
                    if err:
                        print(err, file=sys.stderr)
                        return 1
                    existing_code.update(additions)
                carried = [c for c in restored if c.ok]
                components = [c for c in restored if not c.ok]
                if not components:
                    print("nothing failed in the last run; there is nothing to "
                          "retry", file=sys.stderr)
                    return 0
                # Hand the model what went wrong last time. A repair loop inside a
                # single run already does this; across runs the error would
                # otherwise be lost, and the model would repeat the same mistake
                # with no idea it had made it.
                for c in components:
                    if c.error:
                        c.spec += ("\n\nA previous attempt at this file failed and "
                                   "was discarded. The failure was:\n%s\n"
                                   "Write it again, avoiding that failure."
                                   % c.error)
                if args.check is None and saved.get("check"):
                    args.check = saved["check"]
                request = saved.get("request") or request
                print("resuming: %d of %d component(s) failed last time"
                      % (len(components), len(restored)))
            else:
                # Relying on a model to remember to type `--single-file`
                # for a chained single-capability step is the exact failure
                # this project keeps finding and keeps fixing the same way:
                # a prose rule in a guidance doc gets applied to some steps
                # in a chain and not others -- measured live, a six-step
                # plan used it on steps 2 and 3 and not on 1, 5, or 6, the
                # last of which is the one where it mattered most. So this
                # is decided here, mechanically, off the request text
                # alone, before the planner ever runs -- no flag to forget.
                # `--single-file` passed explicitly always wins either way,
                # and a request that names a second file itself
                # (`client.py`, "two files") is left alone rather than
                # silently overridden.
                # A request that is nothing but "create X.html" (or
                # .css/.js/.md/.txt) has exactly one thing to write and no
                # API to call -- the same mechanical certainty
                # `is_pure_static_file_request` already uses to skip a
                # stray `--api` above, applied here unconditionally so a
                # request with no `--api` at all gets the same protection.
                # Forced to write under its own real, requested filename
                # (`args.out`), not `main.py`: the planner-invented shape
                # this replaces was also caught naming the file something
                # else entirely (`survey_generator.html` for a request
                # that said `survey.html`), which is exactly the defect a
                # sibling step's own `../this/survey.html` reference then
                # has no way to recover from.
                if (not args.single_file and not args.out
                        and static_only_file):
                    args.single_file = True
                    args.out = static_only_file
                    print("  auto: this request is nothing but \"create "
                          "%s\" -- writing it directly as that one file "
                          "(--single-file) instead of letting the planner "
                          "build a pipeline around it." % static_only_file)
                if (not args.single_file
                        and intent.reads_sibling_output(request)
                        and not intent.wants_multi_file(request)):
                    args.single_file = True
                    print("  auto: this request reads a sibling step's "
                          "output -- writing it as one file (--single-file) "
                          "instead of waiting for the planner to (usually) "
                          "split it into client.py + main.py anyway.")
                if args.single_file:
                    # Same one-component shape the "could not decompose"
                    # fallback below already produces and already runs
                    # cleanly through every gate -- requested up front here
                    # instead of arrived at by the planner failing. The
                    # slicing, closure, mock and credential-name context
                    # built above (all of it, before the planner is ever
                    # consulted) is computed from `request`/`cfg` alone, so
                    # skipping the planner loses none of it.
                    components = [intent.Component(
                        "main", args.out or "main.py", 4, [], request)]
                else:
                    def _reconsider_api() -> Optional[str]:
                        # Called between empty planning attempts, never on
                        # a successful one -- see `openapi.reconsider_slice`
                        # for why this asks a different question than the
                        # REQUIRED-endpoint note appended further down
                        # (that gap is already covered regardless of this;
                        # a closure entry is guaranteed to already be in
                        # `chosen`, so re-slicing cannot add what it is
                        # missing). This is about the slice itself having
                        # starved or bloated the planner's prompt before a
                        # CONTRACT was ever written, which is what actually
                        # correlates with an empty or unusable decompose.
                        nonlocal chosen, context, attached_text, api_text
                        if not api_name or not chosen:
                            return None
                        try:
                            result = openapi.reconsider_slice(
                                spec, request, chosen, cfg, state,
                                args.api_limit, hints, avoid,
                                budget=headroom,
                                exclude_tags=openapi.excluded_tags(api_name))
                        except Exception:
                            return None
                        if result is None:
                            return None
                        new_text, new_chosen, reason = result
                        if api_text not in context:
                            return None
                        context = context.replace(api_text, new_text, 1)
                        attached_text = attached_text.replace(
                            api_text, new_text, 1)
                        api_text = new_text
                        chosen = new_chosen
                        print("  " + reason)
                        return context

                    focus = check_focus(root, args.check or "")
                    if focus:
                        context = (context + "\n\n" + focus) if context else focus
                    stored = direct_stored(
                        root, args.check or "", request, cfg, state)
                    if stored == STORED_DONE:
                        sys.stderr.write("  stored outputs pass the check\n")
                        return 0
                    if stored:
                        sys.stderr.write("  stored set stays stored; not planning "
                                         "a procedure\n")
                        return 1
                    approach = stuck_approach(
                        root, args.check or "", cfg, state)
                    if approach:
                        context = (context + "\n\n" + approach) if context else approach
                    components = build_components(
                        request, cfg, state, context, root=root,
                        reconsider_api=(_reconsider_api if api_name
                                       and not args.retry else None))
                    before = [c.path for c in components]
                    components = narrow_to_check(components, root, args.check or "")
                    dropped = [p for p in before if p not in {c.path for c in components}]
                    if dropped:
                        kept = ", ".join(os.path.basename(c.path) for c in components)
                        try:
                            with open(os.path.join(root, ".ralph", "last-check.txt"),
                                      encoding="utf-8", errors="replace") as fh:
                                how = blame_for_check(root, fh.read(), args.check or "")[1]
                        except OSError:
                            how = "named"
                        if how == "loaded":
                            print("  check names no file; it loads %s; not rewriting %s"
                                  % (kept, ", ".join(dropped)))
                        else:
                            print("  check failure names %s; not rewriting %s"
                                  % (kept, ", ".join(dropped)))
                last_check = os.path.join(root or "", ".ralph", "last-check.txt")
                if not (os.path.isfile(last_check) and os.path.getsize(last_check) > 0):
                    components = intent.ensure_entry_point(components, request)
                renamed_entry = intent.enforce_requested_entry_point(
                    components, request)
                if renamed_entry:
                    old_path, new_path = renamed_entry
                    print("  renamed %s to %s: the request named this as "
                         "the runnable entry point verbatim"
                         % (old_path, new_path))
                elif args.api:
                    # Covers the same shape one level further out: a
                    # `--api` step whose request never said "the runnable
                    # entry point is main.py" in those words at all, so
                    # there was nothing for the check above to match.
                    # Every `--api` component is a script meant to be run
                    # against a real service, never a pure library, so a
                    # single one gets `main.py` regardless of what name
                    # the planner happened to pick for it.
                    renamed_entry = intent.default_api_entry_point(components)
                    if renamed_entry:
                        old_path, new_path = renamed_entry
                        print("  renamed %s to %s: every --api component "
                             "is a runnable script, and generate.sh only "
                             "ever looks for main.py"
                             % (old_path, new_path))
                shadowed = intent.deshadow(components)
                for old, new in shadowed:
                    print("  renamed %s to %s: it would shadow the standard "
                          "library module of the same name" % (old, new))
                # The existing-files prose already told the planner which of two
                # things a request is; this asks the same question narrowly and
                # enforces the answer rather than suggesting it. Only entry
                # points with a recorded reason are checked, so a project's
                # first request never triggers this, and only e4b's answer
                # decides -- the planner does not get a second vote.
                reasons = {p: r["why"] for p, r in
                          session.file_reasons(root).items()
                          if session.defines_main(os.path.join(root, p))}
                blocked = (ground.entry_point_conflicts(request, reasons, cfg, state)
                          if reasons else [])
                rescued = intent.rescue_entry_points(components, blocked, root,
                                                     request)
                for old, new in rescued:
                    print("  renamed %s to %s: unrelated to what %s already "
                          "does, so it gets its own file instead of "
                          "overwriting it" % (old, new, old))
                # A REQUIRED closure endpoint (see openapi.close_content_pushes
                # and close_pointer_updates) sits in every writer's own
                # prompt, and the planner can still leave it with no CONTRACT
                # method -- prose saying "required" is advice, and advice has
                # already lost this argument once in this project. Detected
                # here, mechanically, against the CONTRACT text the planner
                # actually emitted, then appended to that same CONTRACT as an
                # explicit exception to "do not define your own version of
                # anything here" -- the instruction that otherwise stops a
                # writer from adding the missing method on its own.
                if components and chosen:
                    import openapi
                    gaps = openapi.contract_missing_endpoints(
                        components[0].contract, chosen)
                    if gaps:
                        note = openapi.describe_missing_endpoints(gaps)
                        for c in components:
                            c.contract += note
                        print("  warning: the CONTRACT gives no method for "
                              "%d REQUIRED endpoint(s); appending a note so "
                              "writers know to add one:"
                              % len(gaps))
                        # NOT `why` -- a for-loop variable is not scoped to
                        # the loop body in Python, so naming it `why` here
                        # shadowed the module-level `why(error)` function
                        # (used below to format a FAILED component's error)
                        # for the rest of this function call. Measured
                        # live: any run whose plan had a REQUIRED-endpoint
                        # gap *and* a component that actually failed hit
                        # `TypeError: 'str' object is not callable` at the
                        # summary print, after the run had already
                        # finished -- the crash was purely cosmetic to the
                        # actual generation, but it ate the real pass/fail
                        # summary every single time both conditions lined
                        # up.
                        for entry, reason in gaps:
                            print("    %s %s -- %s"
                                  % (entry.get("method", "?"),
                                     entry.get("path", "?"), reason))
            if not components:
                print("could not decompose; falling back to a single file",
                      file=sys.stderr)
                if not args.out:
                    print("give --out for a single-file build", file=sys.stderr)
                    # Nothing has been saved for this run at all -- every
                    # other failure path reaches `save_plan` further down,
                    # but this one returns before ever getting there, so a
                    # decompose failure this total used to leave `--retry`
                    # with nothing to work from ("no previous run recorded
                    # for <dir>"), forcing the request to be retyped from
                    # scratch. Measured live: a planner call that landed on
                    # a demoted floor-2 model (the bug fixed above, in
                    # `claim_first_free_role`) failed to decompose, and
                    # `team do --retry` in that same directory could not
                    # even attempt a second try. Recording the request/
                    # api/check here, with an empty component list, gives
                    # `--retry` (below) something to re-decompose from.
                    save_plan(root, request, [], args.check,
                             args.answer_tokens, api=api_name,
                             decompose_failed=True)
                    return 1
                components = [intent.Component("main", args.out, 4, [], request)]

            # A single-component plan chained off a sibling step's output has
            # no other file in this plan to amortise the pool's ceremony
            # against (see `intent.low_parallelism_note`) -- and two of that
            # ceremony's automatic behaviours are actively counterproductive
            # for exactly this shape, so both are disarmed here rather than
            # only reported.
            serial_link = intent.low_parallelism_note(request, components)
            effective_repair = args.repair
            # Whether the fleet has nothing better to offer this component's
            # own floor -- the one condition that actually justifies cutting
            # this step slack, as opposed to the mere fact that it happens to
            # be a single-component chain link. A single file's CONTRACT can
            # absolutely still be wrong (a planner missing a REQUIRED
            # endpoint, exactly like the gap note printed above) -- that is
            # a real planning defect a fresh roll of the planner can fix, so
            # "one file" alone must never skip the restart that would try
            # again. Only a genuine capability gap in the fleet earns that;
            # this is computed once and reused for both decisions below so
            # they can never disagree about which case they are in.
            no_capable_writer = bool(
                serial_link and components and components[0].floor >= 4
                and not pick_solvers(cfg, state, 4, count=1, family=restrict))
            if no_capable_writer:
                # A "no floor-4 model is enabled, borrowing a weaker one"
                # writer failing repeatedly on a lone file is evidence about
                # the fleet's capability, not about needing more attempts --
                # the same call this project already makes for a generated
                # oracle ("two independently written candidates failing the
                # same test is evidence about the test"). Measured live: this
                # exact shape burned 6 attempts and 8m15s against a borrowed
                # model before failing anyway.
                effective_repair = min(args.repair, 2)
                print("\n  note: no real floor-%d writer is enabled, and "
                      "this single-component step cannot parallelise "
                      "around that -- capping repair at %d attempt(s) "
                      "instead of grinding the full budget against a "
                      "borrowed model unlikely to converge."
                      % (components[0].floor, effective_repair))

            print("\nplan:")
            if components and components[0].contract:
                print("  contract: %s" % components[0].contract)
            for c in components:
                # Whether a path already exists is a filesystem fact, so saying
                # it cannot be a false positive -- and it is the one thing about
                # a plan an operator may want to stop. A component replaces its
                # whole file, so a planner reusing main.py for new work deletes
                # the script that was working; the backup survives, but finding
                # that out after two minutes of pool time is worse than reading
                # it here first.
                replaces = (not args.retry
                            and os.path.isfile(os.path.join(root, c.path)))
                print("  %-20s %-30s floor %d%s%s"
                      % (c.name[:20], c.path, c.floor,
                         ("  after " + ", ".join(c.deps)) if c.deps else "",
                         "  [replaces existing]" if replaces else ""))
            # Files here that this plan will not touch are almost always debris
            # from an earlier attempt, and they are dangerous precisely because
            # they still run: a stale main.py left over from a previous plan gets
            # executed, imports a name from a freshly written module that no longer
            # defines it, and reports a failure belonging to a run that is gone.
            # `carried` counts as planned. A retry runs only the components that
            # failed, so measuring against those alone called every file the same
            # plan had just written successfully "not part of this plan" and
            # advised starting from an empty directory -- which would delete the
            # working half of the run being repaired.
            planned = {os.path.normpath(c.path) for c in components + carried}
            stale = sorted(f for f in os.listdir(root)
                           if f.endswith(".py") and os.path.normpath(f) not in planned
                           and os.path.isfile(os.path.join(root, f)))
            if stale:
                print("\n%d other python file(s) here are not part of this plan: %s"
                      % (len(stale), ", ".join(stale[:6])))
                print("  they will be left untouched, and running them may fail "
                      "against the new files. An empty directory is cleaner.")

            if args.dry_run:
                return 0

            # Opt-in. A generated oracle is only worth its cost if it is right more
            # often than it is wrong, and measured here it never was: six for six
            # rejected correct code across two runs of this plan, while consuming
            # 314 of the 767 model-seconds one run spent. A hand-written --check
            # costs a few hundred tokens of the orchestrator's output and caught
            # everything these missed.
            tests: Dict[str, str] = {}
            if args.tests and not args.no_tests:
                print("\nwriting an invariant test per component...")
                light = pick_solvers(cfg, state, 1, count=4, family=restrict,
                                     max_over=1)
                tests = checks.build_tests(components, light, cfg, state, root)

            print()
            ok, elapsed = run_components(components, cfg, state, check=args.check,
                                         repair=effective_repair,
                                         answer_tokens=args.answer_tokens,
                                         root=root, tests=tests,
                                         already=carried + external_dependencies(
                                             components, carried, root),
                                         existing=existing_code,
                                         attached=attached_text,
                                         env_extra=api_env or None,
                                         mock=mock, api_name=api_name,
                                         request=request)
            if mock is not None:
                # What the generated code actually sent, which is the only
                # evidence here that is not a claim about the code. A 404 means
                # it invented an endpoint; a 422 means it got the body wrong.
                # Both are reported rather than failing the run, because the
                # client may legitimately not call anything from `main` -- and a
                # gate that demanded traffic would force a network call into
                # every entry point.
                import mockapi
                print("\nwhat the code sent to the mock API:")
                print(mockapi.summarise(mock))
                bad = [c for c in mock.calls if not c["ok"]]
                if bad:
                    print("  %d request%s the real API would have rejected"
                          % (len(bad), "" if len(bad) == 1 else "s"))
                try:
                    mock_server.shutdown()
                except Exception:                       # noqa: BLE001
                    pass
            components = carried + components
            ok += len(carried)

            if (not (args.retry or replanned) and ok != len(components)
                    and not no_capable_writer):
                replanned = True
                print("\n  %d of %d component(s) did not pass their own "
                      "gates even after per-component repair; the plan "
                      "itself may be the problem, not the code -- "
                      "restarting from planning, once, from the "
                      "original request." % (len(components) - ok,
                                              len(components)))
                if mock is not None:
                    mock.calls = []
                continue
            # The rung above already tried "the same request, a fresh
            # decomposition" once and it did not converge either -- two
            # independent CONTRACTs from the same text both ending in the
            # same failure is no longer evidence about which files ended
            # up broken, it is starting to look like evidence about what
            # the request itself did or did not say. `replan_component`
            # already gets a look at this per-file, grounded in the real
            # source of the component's own siblings; this is the same
            # move one level up, grounded in the real source of every
            # component that *did* succeed plus the full attempt trail of
            # every one that did not (`Component.history_trail`), not the
            # bare last-error line a per-file replan sees.
            #
            # Fires at most once (`request_rewritten`), never on --retry
            # (there is no fresh decomposition to feed a rewritten request
            # into on a retry -- see resolve_run_target's own guard for the
            # matching restriction), and never when the fleet itself was
            # the gap (`no_capable_writer`) -- a rewritten request still
            # has to be decomposed and written by the same underpowered
            # models, which the note printed just below already declines
            # to retry for the identical reason.
            if (not args.retry and replanned and not request_rewritten
                    and ok != len(components) and not no_capable_writer):
                request_rewritten = True
                contract = next((c.contract for c in components if c.contract),
                                "")
                print("\n  restarting from planning did not converge "
                      "either -- asking whether the request text itself "
                      "was the problem before giving up...")
                new_request = replan_request(request, contract, components,
                                             cfg, state, root)
                if new_request and new_request.strip() != request.strip():
                    print("  the request looks like the actual defect; "
                          "rewriting it and decomposing once more:")
                    print("    was: %s" % request)
                    print("    now: %s" % new_request)
                    request = new_request
                    if mock is not None:
                        mock.calls = []
                    continue
                print("  no rewrite proposed -- the request itself does "
                      "not look like the problem; reporting as failed.")
            if no_capable_writer and ok != len(components):
                # Restarting from planning is not what a genuine capability
                # gap needs -- a fresh CONTRACT still has to be written by
                # the same underpowered fleet, so replanning here would
                # only pay the doubled cost this whole change exists to
                # avoid, for a roll no more likely to converge than the
                # last one against the same models. This is *not* the
                # general "single file, nothing to replan" claim -- a
                # single file's CONTRACT can absolutely still be wrong (see
                # the gap note above), which is exactly what a real writer
                # gets a fresh shot at fixing via the ordinary restart path.
                print("\n  no real floor-%d writer is enabled -- restarting "
                      "from planning would only hand the same gap to the "
                      "same borrowed model again; not restarting. See the "
                      "note above." % components[0].floor)
            save_plan(root, request, components, args.check,
                      args.answer_tokens, api=api_name)
            session.record(root, request, components, ok, len(components), elapsed,
                           existing=existing_code, check=args.check)
            print("\n" + "=" * 66)
            for c in components:
                status = "ok" if c.ok else ("FAILED  " + why(c.error))
                print("  %-20s %-28s %-22s %s"
                      % (c.name[:20], c.path, c.target, status))
            print("\n%d/%d component(s) passed every gate in %s"
                  % (ok, len(components), swarm.human(elapsed)))
            if ok != len(components) and request_rewritten:
                # Distinct from an ordinary FAILED run: every rung has now
                # been tried -- per-component repair, a fresh decomposition
                # of the same request, and a decomposition of a *corrected*
                # request the planner itself proposed -- and it still did
                # not converge. Nothing left in this ladder is going to
                # fix it by trying again with the same inputs, so this says
                # so in words an operator or an orchestrator log scan can
                # tell apart from "just retry it," rather than looking
                # identical to the first, ordinary kind of failure.
                print("\nGIVE UP: every self-repair rung was tried,  "
                      "including reconsidering and rewriting the request "
                      "text itself, and the plan still does not pass. "
                      "This needs a human to read the failures above, not "
                      "another retry.")
                for c in components:
                    if not c.ok and getattr(c, "history_trail", None):
                        print("\n  %s -- full attempt trail:" % c.path)
                        for line in c.history_trail:
                            print("    " + line)

            # What to type next. Read off the generated file's own syntax tree,
            # so it cannot describe a flag the file does not have.
            import usage
            howto = usage.render(entry_points(components), root)
            if howto:
                print("\n" + howto)

            # Per-file gates cannot catch a file that redeclares its dependency's
            # types instead of importing them: it parses, imports, and passes. Two
            # definitions of one name is a mechanical fact, so check it as one.
            clashes = intent.redefined_symbols([c for c in components if c.ok], root)
            if clashes:
                print("\nintegration problem -- these are defined twice:")
                for path, symbol, owner in clashes:
                    print("  %s redeclares %s, which belongs to %s"
                          % (path, symbol, owner))
                fixed = repair_redefinitions(components, clashes, cfg, state,
                                             args.check, args.answer_tokens, root,
                                             boilerplate=attached_text)
                clashes = intent.redefined_symbols([c for c in components if c.ok],
                                                   root)
                if clashes:
                    print("  still duplicated after repair; fix by hand:")
                    for path, symbol, owner in clashes:
                        print("    %s: %s" % (path, symbol))
                elif fixed:
                    print("  resolved: each name now has one definition")

            # Names, not behaviour: does every file refer to the others correctly?
            # Runs before the integration check because a mismatch here is the
            # likeliest reason that check is about to fail, and the message is far
            # more useful than the ImportError it would otherwise produce.
            interfaces_ok = interface_gate(components, cfg, state,
                                           args.answer_tokens, root,
                                           boilerplate=attached_text,
                                           mock=mock, env_extra=api_env or None)

            if not (args.retry or replanned) and not interfaces_ok:
                replanned = True
                print("\n  components passed individually but do not "
                      "fit together; restarting from planning, once, "
                      "from the original request.")
                if mock is not None:
                    mock.calls = []
                continue

            integrated = True
            if args.check and ok == len(components):
                print("\nrunning the integration check...")
                integrated = integration_gate(args.check, components, cfg, state,
                                              args.answer_tokens, root)
            elif args.check:
                print("\nskipping the integration check: %d component(s) failed"
                      % (len(components) - ok))
                integrated = False

            written = [os.path.join(root, c.path) for c in components if c.ok]
            if written and not args.no_audit:
                # The free half, always. Parse errors and the AST detectors cost
                # milliseconds and were the only things that found real bugs in a
                # night of measurement.
                static_report(written, root)
            if written and args.audit and not args.no_audit:
                # The expensive half, only when asked. On a clean graphkit run the
                # model review took 3m24s against 1m03s of actual generation --
                # three quarters of the wall clock -- and both findings it
                # confirmed were wrong: a KeyError that Python does not raise, and
                # non-determinism the spec allows. That is the same trade already
                # rejected for generated oracles, and running the code is a better
                # test than asking a model to imagine running it.
                print("\nreviewing with the pool (--audit)...")
                audit_args = argparse.Namespace(
                    paths=written, floor=2, n=3,
                    no_second=False, keep_going=True, verbose=False, json=False)
                cmd_audit(audit_args, cfg, state)
            return 0 if ok == len(components) and integrated and interfaces_ok else 1

    # A question. Wide ones fan out; narrow ones go to whichever model the
    # router thinks is right for the difficulty.
    if scope == "wide" and paths:
        files = []
        for p in paths:
            full = os.path.join(root, p)
            if os.path.isdir(full):
                for dirpath, dirnames, filenames in os.walk(full):
                    dirnames[:] = [d for d in dirnames
                                   if d not in evidence.SKIP_DIRS]
                    files.extend(os.path.join(dirpath, f)
                                 for f in sorted(filenames) if f.endswith(".py"))
            elif os.path.isfile(full):
                files.append(full)
        if files:
            split_args = argparse.Namespace(
                prompt=[request], paths=files, reduce=True, out=None,
                floor=2, reduce_floor=None, reduce_to="model", est_output=350,
                verify=False, verify_floor=4, max_chars=12000)
            return cmd_split(split_args, cfg, state)

    def _stream(piece: str) -> None:
        sys.stdout.write(piece)
        sys.stdout.flush()

    # A narrow question about this project -- "why does main.py look like
    # that, please give guidance on how to use it" -- had nothing to answer
    # from: the bare request text carries no file names, no history and no
    # code, so a model asked about "the file" had to guess what it even
    # was. `code` already gets continuity and a writer editing a file gets
    # that file's own real content; a question got neither, which is the
    # actual gap -- there was no missing command, `ask`'s existing fallback
    # simply never carried the project with it. See
    # `session.question_context` for what it grounds the answer in and why.
    ask_context = session.question_context(root, public_names, request,
                                           paths, cfg)
    full_prompt = (ask_context + "\n\n" + request) if ask_context else request

    result = swarm.run_prompt(cfg, state, full_prompt, stream_to=_stream)
    print()
    print("  (%s/%s, %s)" % (result["node"], result["model"],
                             swarm.human(result["seconds"])))
    return 0


def cmd_code(args, cfg: swarm.Config, state: swarm.State) -> int:
    """Write code locally instead of paying a frontier model to type.

    The division of labour this is built for: the expensive model decides what
    to build and what correct means, the 26b writes the body, and deterministic
    gates decide whether the result is kept. Nothing survives on the strength
    of sounding right -- it has to parse, import, and pass the check command.

    A batch fans across nodes, which only helps if more than one model clears
    the floor; at the default floor of 4 that is the 26b alone and the files
    are written one after another. Lower the floor to spread boilerplate across
    the pool -- the gates are the same either way, so a weaker writer costs
    repair attempts rather than correctness.
    """
    jobs: List[Dict[str, Any]] = []
    if args.batch:
        with open(args.batch, "r", encoding="utf-8") as fh:
            loaded = json.load(fh)
        jobs = loaded["files"] if isinstance(loaded, dict) else loaded
    else:
        spec = " ".join(args.spec).strip()
        if not spec and not sys.stdin.isatty():
            spec = sys.stdin.read().strip()
        if not spec or not args.out:
            print("need a spec and --out (or --batch)", file=sys.stderr)
            return 2
        jobs = [{"out": args.out, "spec": spec}]

    for job in jobs:
        if not job.get("out") or not job.get("spec"):
            print("every job needs 'out' and 'spec'", file=sys.stderr)
            return 2

    restrict = cfg.data.get("team", {}).get("restrict_to_family")
    # Hold to the requested tier first. Only widen if that leaves nobody,
    # so "floor 2" does not quietly become "the 26b is also allowed".
    writers = pick_solvers(cfg, state, args.floor, count=args.n,
                           family=restrict, max_over=args.ceiling)
    if not writers:
        writers = pick_solvers(cfg, state, args.floor, count=args.n,
                               family=restrict)
    if not writers:
        print("no model at capability >= %d" % args.floor, file=sys.stderr)
        return 1
    print("writers: %s" % ", ".join("%s/%s" % (n.name, m) for n, m in writers))
    if len(writers) == 1 and len(jobs) > 1:
        print("  (one eligible writer, so %d files are written in sequence; "
              "use --floor 2 to spread them)" % len(jobs))

    check = args.check
    root = project_root()
    results: List[Optional[Dict[str, Any]]] = [None] * len(jobs)
    queue = list(enumerate(jobs))
    lock = threading.Lock()

    # Warm each writer at the window its loop will use, since a reload costs
    # more than most of the generation.
    def warm(node: swarm.Node, model: str) -> None:
        ctx = codegen.plan_context(jobs[0]["spec"], cfg, node, model,
                                   args.answer_tokens,
                                   thinking_tokens(cfg, model), state=state)
        try:
            swarm.chat(node, model, [{"role": "user", "content": "hi"}],
                       num_ctx=ctx, num_predict=1, temperature=0.0, timeout=600)
            state.mark_resident(node.name, model)
        except swarm.OllamaError:
            pass

    warmers = [threading.Thread(target=warm, args=(n, m), daemon=True)
               for n, m in writers]
    for t in warmers:
        t.start()
    for t in warmers:
        t.join()

    started = time.monotonic()

    def worker(node: swarm.Node, model: str) -> None:
        while True:
            with lock:
                if not queue:
                    return
                i, job = queue.pop(0)
            sys.stderr.write("[%s] %s on %s/%s\n"
                             % (job["out"], "writing", node.name, model))
            results[i] = codegen.generate_file(
                job["spec"], os.path.join(root, job["out"]), node, model,
                cfg, state, check=job.get("check", check),
                attempts=args.repair, answer_tokens=args.answer_tokens,
                thinking=thinking_tokens(cfg, model),
                think=args.think, root=root,
                extra=job.get("extra", ""),
                env_names=env_vocabulary(cfg, root))

    threads = [threading.Thread(target=worker, args=(n, m), daemon=True)
               for n, m in writers]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    elapsed = time.monotonic() - started
    print("\n" + "=" * 66)
    good: List[str] = []
    for job, res in zip(jobs, results):
        if not res:
            print("  %-28s no result" % job["out"])
            continue
        if res["ok"]:
            good.append(job["out"])
            print("  %-28s ok    %-22s %d attempt(s)  %s"
                  % (job["out"], res["target"], res["attempts"],
                     swarm.human(res["seconds"])))
        else:
            print("  %-28s FAILED %-21s %d attempt(s)  %s"
                  % (job["out"], res["target"], res["attempts"],
                     swarm.human(res["seconds"])))
            last = res["history"][-1] if res["history"] else {}
            if last:
                print("      last failure (%s): %s"
                      % (last.get("stage"),
                         (last.get("error") or "").splitlines()[0][:80]))

    print("\n%d/%d file(s) passed every gate in %s"
          % (len(good), len(jobs), swarm.human(elapsed)))
    if not good:
        return 1

    if args.audit and good:
        print("\nauditing generated files...")
        audit_args = argparse.Namespace(
            paths=[os.path.join(root, p) for p in good], floor=args.floor,
            n=args.n, no_second=False, keep_going=False, verbose=False,
            json=False)
        cmd_audit(audit_args, cfg, state)
    return 0


def cmd_lint_chain(args, cfg: swarm.Config, state: swarm.State) -> int:
    """Check a whole multi-step chain's request text against itself,
    before any of it runs.

    `intent.chain_output_json_problems` does the actual check; this is
    only the CLI wrapper an operator or an orchestrating agent runs once,
    against the full list of steps, before issuing a single `team do`
    call. `--json` is the file format: a JSON array of
    `{"dir": "...", "request": "..."}` objects, in the order the steps
    will actually run -- the same shape an orchestrating agent already
    has to build in memory to write `generate.sh`/`orchestrate.sh` in the
    first place, so producing this file costs nothing beyond what was
    already being decided.

    Exits 1 with every problem printed if the chain is inconsistent
    (after fixing what it can -- see below), exits 0 silently if it is
    not -- a clean chain should not print anything, the same as every
    other advisory check in this project that only speaks up when there
    is something to say.

    Fixing is the default, not a flag an orchestrating agent has to
    remember to add. An earlier version required `--fix` to opt in, on
    the theory that mutating a file in place should be asked for -- and
    that is backwards for exactly the caller this exists for: an
    orchestrator writing `generate.sh` from a template has no reason to
    type a flag it was never told mattered, and templates that could
    forget it are templates that will. The safe default here is not
    "leave it broken until asked to fix it," it is "fix everything that
    is provably fixable, always" -- there is no reading under which a
    correct chain is changed by this, since `intent.
    autofix_chain_output_json` only ever touches a step whose request
    text is missing a promise a sibling already asked for by name, and a
    request with nothing wrong comes back byte-identical. `--check-only`
    is the escape hatch for the rarer case of wanting a report without
    touching the file (a chain already committed to a repo, say).

    Either way, `intent.autofix_chain_output_json`
    (`intent.chain_output_json_problems` under `--check-only`) does the
    actual check. `args.steps` is a JSON array of `{"dir": ...,
    "request": ...}` objects, in the order the steps will actually run
    -- the same shape an orchestrating agent already has to build in
    memory to write `generate.sh`/`orchestrate.sh` in the first place,
    so producing this file costs nothing beyond what was already being
    decided.

    A fix rewrites `args.steps` in place with the corrected request text
    -- the same file `generate.sh` is about to build its real `team do`
    calls from, so the fix lands exactly where it needs to before
    anything runs rather than in a second file nobody rereads. What is
    left in the printed problem list after a fix is exactly what could
    not be proven fixable from the chain's own text -- a step that does
    not exist at all, or a read phrased in a way that names no
    recoverable key -- and that still exits 1, on purpose: a step named
    nowhere in this chain, or a request too vague to name what to save,
    is a real gap in the chain, not something to guess through.
    """
    try:
        with open(args.steps, "r", encoding="utf-8") as fh:
            raw = json.load(fh)
    except (OSError, json.JSONDecodeError) as exc:
        print("could not read %s: %s" % (args.steps, exc), file=sys.stderr)
        return 2
    try:
        steps = [(str(item["dir"]), str(item["request"])) for item in raw]
    except (KeyError, TypeError) as exc:
        print("%s must be a JSON array of {\"dir\": ..., \"request\": "
              "...} objects: %s" % (args.steps, exc), file=sys.stderr)
        return 2

    if not args.check_only:
        fixed_steps, problems = intent.autofix_chain_output_json(steps)
        changed = [(d, r) for (d, r), (_, orig) in
                   zip(fixed_steps, steps) if r != orig]
        new_raw = raw
        if changed:
            # Only ever overwrite the "request" field. `raw` may carry
            # other keys per step -- "api", "flags", anything a template
            # like generate.sh's launch loop reads back -- and a fix
            # that rewrote the file as bare {"dir", "request"} objects
            # would silently drop every one of them, which is worse than
            # not fixing anything: the chain would look consistent and
            # then launch with no --api on a step that needs one.
            fixed_requests = dict(fixed_steps)
            new_raw = []
            for item in raw:
                item = dict(item)
                item["request"] = fixed_requests[str(item["dir"])]
                new_raw.append(item)
            with open(args.steps, "w", encoding="utf-8") as fh:
                json.dump(new_raw, fh, indent=2)
            print("fixed %d step(s)' request text in %s:"
                  % (len(changed), args.steps))
            for dirname, request in changed:
                print("  %s -> %s" % (dirname, request))
        # Never *mechanically* autofixable the way a named `_id` key is
        # -- see `intent.chain_dangling_version_problems`. It is fixable
        # over the network, though (`repair_dangling_version_chain`),
        # since recognising which earlier step secretly creates the
        # version is exactly the kind of judgement call regex cannot
        # make and a reader can. Run against the *fixed* steps, since a
        # step this pass just repaired should not also be judged against
        # its old text.
        version_problems = intent.chain_dangling_version_problems(
            fixed_steps)
        version_notes: List[str] = []
        if version_problems:
            new_raw, version_problems, version_notes = (
                repair_dangling_version_chain(new_raw, cfg, state))
            if version_notes:
                with open(args.steps, "w", encoding="utf-8") as fh:
                    json.dump(new_raw, fh, indent=2)
        if version_notes:
            print("asked the pool to repair the dangling version "
                  "reference(s) below instead of stopping the run:")
            for note in version_notes:
                print("  " + note)
        # Mechanically fixable exactly when an earlier step's own request
        # already names a content-producing filename -- see
        # `intent.autofix_chain_missing_content_source`'s own docstring
        # for why this is the same class of fix as the output.json case
        # above, not a guess. Run against `fixed_steps` for the identical
        # reason the version check is: a step this pass already repaired
        # should be judged (and fixed further) against its new text, not
        # its old one.
        pre_content_steps = fixed_steps
        fixed_steps, content_problems = (
            intent.autofix_chain_missing_content_source(fixed_steps))
        content_changed = [
            (d, r) for (d, r), (_, orig) in
            zip(fixed_steps, pre_content_steps) if r != orig]
        if content_changed:
            content_fixed_requests = dict(fixed_steps)
            new_raw = [dict(item) for item in new_raw]
            for item in new_raw:
                item["request"] = content_fixed_requests[str(item["dir"])]
            with open(args.steps, "w", encoding="utf-8") as fh:
                json.dump(new_raw, fh, indent=2)
            print("fixed %d step(s)' request text in %s (content source):"
                  % (len(content_changed), args.steps))
            for dirname, request in content_changed:
                print("  %s -> %s" % (dirname, request))
        # Never mechanically fixable -- see the function's own docstring
        # for why (no key name anywhere to copy, same reasoning as the
        # dangling-version case above). Run against the fully-fixed
        # steps for the same reason every check above is: a step this
        # pass already repaired should be judged against its new text.
        dir_ref_problems = intent.chain_dangling_directory_reference_problems(
            fixed_steps)
        if not problems and not version_problems and not content_problems \
                and not dir_ref_problems:
            print("chain is consistent (after the fix above)"
                  if (changed or version_notes or content_changed) else
                  "chain is consistent: every ../DIR/output.json a step "
                  "reads has a matching write promise in DIR's own request")
            return 0
        if problems:
            print("could not fix everything -- these need a real edit to "
                  "the request text, not a guess:", file=sys.stderr)
            for problem in problems:
                print("  " + problem, file=sys.stderr)
        if version_problems:
            print("these still consume \"the new version\" without ever "
                  "saying where it comes from -- a duplicate, throwaway "
                  "version will be created instead of reusing the real "
                  "one, and the network repair above could not resolve "
                  "them either:", file=sys.stderr)
            for problem in version_problems:
                print("  " + problem, file=sys.stderr)
        if content_problems:
            print("these create or update an applet with no real content "
                  "source named anywhere -- a version will be created "
                  "with fabricated placeholder content instead of the "
                  "real thing:", file=sys.stderr)
            for problem in content_problems:
                print("  " + problem, file=sys.stderr)
        if dir_ref_problems:
            print("these name another step's directory directly with no "
                  "real ../dir/... reference to it anywhere in the same "
                  "request -- the generated code has no wired way to see "
                  "this dependency and will invent a path or a value "
                  "instead of failing loudly:", file=sys.stderr)
            for problem in dir_ref_problems:
                print("  " + problem, file=sys.stderr)
        return 1

    # --check-only: report without touching the file.
    problems = intent.chain_output_json_problems(steps)
    version_problems = intent.chain_dangling_version_problems(steps)
    content_problems = intent.chain_missing_content_source_problems(steps)
    dir_ref_problems = intent.chain_dangling_directory_reference_problems(
        steps)
    if not problems and not version_problems and not content_problems \
            and not dir_ref_problems:
        print("chain is consistent: every ../DIR/output.json a step reads "
              "has a matching write promise in DIR's own request")
        return 0
    if problems:
        print("this chain will silently default ids instead of failing "
              "loudly -- fix the request text before running any of it, "
              "or drop --check-only to have this repair whatever can be "
              "inferred automatically:", file=sys.stderr)
        for problem in problems:
            print("  " + problem, file=sys.stderr)
    if version_problems:
        print("these consume \"the new version\" without ever saying "
              "where it comes from -- a duplicate, throwaway version "
              "will be created instead of reusing the real one:",
              file=sys.stderr)
        for problem in version_problems:
            print("  " + problem, file=sys.stderr)
    if content_problems:
        print("these create or update an applet with no real content "
              "source named anywhere -- a version will be created with "
              "fabricated placeholder content instead of the real "
              "thing:", file=sys.stderr)
        for problem in content_problems:
            print("  " + problem, file=sys.stderr)
    if dir_ref_problems:
        print("these name another step's directory directly with no "
              "real ../dir/... reference to it anywhere in the same "
              "request -- the generated code has no wired way to see "
              "this dependency and will invent a path or a value "
              "instead of failing loudly:", file=sys.stderr)
        for problem in dir_ref_problems:
            print("  " + problem, file=sys.stderr)
    return 1


def cmd_steps_to_bash(args, cfg: swarm.Config, state: swarm.State) -> int:
    """Print `steps.json` as four ready-to-`eval` bash array assignments.

    This exists to remove a shape from `generate.sh`/`orchestrate.sh`
    templates, not to add one: reading `steps.json` back into bash arrays
    used to mean writing `eval "$(python3 -c '<multi-line python
    program>')"` directly into the orchestration script -- three
    nested closing delimiters (`'`, `)`, `"`) that have to land in
    exactly that order after seven lines of an embedded program, with
    nothing about the middle of it looking any different from the end.

    Measured live: an orchestrating model wrote that exact construct with
    one extra stray `'` right after the python string's real closing
    quote (`'')"` instead of `')"`), and its own comment in the same file
    -- "abbreviated for brevity, but I'll write the full thing" -- shows
    it was reconstructing the shape from memory rather than copying it
    character for character. That single extra quote opened a second,
    unterminated string that swallowed the rest of the file, and bash
    reported it as `unexpected EOF while looking for matching` \\`'\\`\\` at
    the *next* invocation, 80+ lines later, pointing nowhere near the
    actual mistake -- this project has already hit this exact failure
    shape once before, for the same underlying reason, in a two-line
    `echo` with a quote seam in the middle.

    The fix used there was "stop handing anything a template shaped so
    that copying it wrong is this easy," and the same move applies here:
    `team.py` is already assumed to be on `PATH` in every directory this
    kind of script runs in (the same script calls `team do` and `team
    lint-chain` right next to this), so the seven-line embedded program
    moves in here, where it is written once, tested, and never
    regenerated from memory by anything. What the template needs becomes
    one line with no nested string delimiters at all:

        eval "$(team steps-to-bash steps.json)"

    Emits the array-reset line too (`STEP_DIRS=(); ...`), so this one
    line fully replaces both the reset and the old inline python call --
    there is no second line left for a future edit to duplicate,
    reorder, or drop out of sync with this one.
    """
    try:
        with open(args.steps, "r", encoding="utf-8") as fh:
            steps = json.load(fh)
    except (OSError, json.JSONDecodeError) as exc:
        print("could not read %s: %s" % (args.steps, exc), file=sys.stderr)
        return 2
    print("STEP_DIRS=(); STEP_REQS=(); STEP_APIS=(); STEP_FLAGS=()")
    for step in steps:
        try:
            dirname = str(step["dir"])
            request = str(step["request"])
        except (KeyError, TypeError) as exc:
            print("%s: each step needs \"dir\" and \"request\": %s"
                  % (args.steps, exc), file=sys.stderr)
            return 2
        api = str(step.get("api", ""))
        flags = str(step.get("flags", ""))
        print("STEP_DIRS+=(%s); STEP_REQS+=(%s); STEP_APIS+=(%s); "
              "STEP_FLAGS+=(%s)"
              % (shlex.quote(dirname), shlex.quote(request),
                 shlex.quote(api), shlex.quote(flags)))
    return 0


# `swarm.HERE`, not a second `os.path.dirname(os.path.abspath(__file__))`
# computed independently here: this project already settled "resolve the
# symlink, not the invocation path" for exactly this class of problem
# (`swarm.HERE` uses `realpath`, precisely so state/specs/backups/sessions
# all agree on one real directory regardless of which of `team`/`swarm`/
# `openapi`'s symlinks was actually invoked). This constant duplicated
# that logic instead of reusing it, and the duplicate used `abspath`,
# which leaves a symlink's own path untouched rather than resolving it.
# `team` is normally invoked through `~/.local/bin/team -> .../team.py`,
# so `abspath(__file__)` there is `~/.local/bin/team`, and this pointed
# every generated `orchestrate.sh` at `~/.local/bin/.env` -- a directory
# no `.env` has ever lived in -- instead of the real one beside this file.
# The preamble's `[ -f "$_SWARM_ENV" ]` check was therefore always false,
# so every credential export it exists to guarantee silently did nothing.
# Measured live: `API_KEY environment variable is not set` on the very
# first step of a run, on a machine whose `.env` was never missing, only
# unreachable from the path this had computed for itself instead of
# asking `swarm` for the one it already gets right.
_SWARM_ENV_PATH = os.path.join(swarm.HERE, ".env")

_ORCHESTRATE_RUN_STEP_TEMPLATE = '''#!/bin/bash
# orchestrate.sh -- generated by `team orchestrate-sh`, not hand-written.
# Do not reconstruct this file from memory or from LOCAL.md's prose; the
# whole reason this command exists is that the retry ladder below has
# been dropped, half-copied, or quote-mangled every time an orchestrating
# agent retyped it by hand (see LOCAL.md, "the retry ladder is not
# optional" and "a long echo used to be wrapped across two lines"). Rerun
# `team orchestrate-sh steps.json > orchestrate.sh` instead of editing
# this by hand if the step list changes.
#
# ONE FILE, BOTH PHASES. Earlier revisions of this command split the
# write phase (the `team do` fan-out) into a separate `generate.sh` that
# this script called with `nohup bash generate.sh ...`. That was
# measured to fail exactly the way splitting anything across two
# generated files fails here: an orchestrating agent ran only
# `team orchestrate-sh`, got a script whose first real action was
# `bash: generate.sh: No such file or directory`, because nothing had
# ever created the other file. Two files sharing one steps.json is two
# places a caller can run only one of; one file is not. The write phase
# below is exactly as inert as `generate.sh` used to be (no
# `python3 main.py` anywhere in it), it is simply not a separate
# document anymore.

# SELF-LOGGING: this script writes its own orchestrate.log, in its own
# directory, regardless of whether whatever launched it -- a hand-written
# batch driver, a bare `bash orchestrate.sh`, an interactive terminal --
# remembered to redirect it there. Measured live, twice, after LOCAL.md
# already said in as many words to redirect this exact call: a
# hand-written driver ran `bash orchestrate.sh` with no redirect at all,
# so this run's real output went wherever the driver's own stdout
# happened to already be pointed (an outer batch log, or nowhere), and
# `run_N/orchestrate.log` was never created. Depending on every future
# caller to remember `> orchestrate.log 2>&1`, forever, is the same
# mistake this project already stopped making for a chain's own request
# text (`lint-chain`) and for a driver's own control flow (`batch-sh`) --
# fixed here at the one place a caller's mistake cannot reach: this
# file's own first executable line, before anything it does is capable
# of being lost. The guard variable stops this from re-truncating its
# own log if the script is ever sourced or re-executed from within
# itself; every ordinary invocation only ever sees it unset.
if [ -z "${_ORCHESTRATE_SELF_LOGGED:-}" ]; then
    export _ORCHESTRATE_SELF_LOGGED=1
    exec > orchestrate.log 2>&1
fi

# The one authoritative source of real credentials for this whole run.
# Exported here, once, so every `python3 main.py` call below has them
# regardless of whether that particular file's own `.env` loader fired.
_SWARM_ENV=%(env_path)s
if [ -f "$_SWARM_ENV" ]; then
    while IFS='=' read -r _swarm_k _swarm_v || [ -n "$_swarm_k" ]; do
        case "$_swarm_k" in ''|'#'*) continue ;; esac
        _swarm_v="${_swarm_v%%\\"}"; _swarm_v="${_swarm_v#\\"}"
        _swarm_v="${_swarm_v%%\\'}"; _swarm_v="${_swarm_v#\\'}"
        # setdefault, not overwrite: a value already exported into this
        # shell (by the operator, by CI, by a caller of this script)
        # always wins over the file.
        [ -z "${!_swarm_k:-}" ] && export "$_swarm_k=$_swarm_v"
    done < "$_SWARM_ENV"
fi

# --- write phase: touches nothing real. Every `team do` call below only
# ever talks to the local pool and a mock -- no project, no task, no
# unit, no API call with a side effect. steps.json is the one and only
# place this chain's request text lives; regenerating this script from
# an edited steps.json reproduces this block byte-for-byte.
cat > steps.json <<'STEPS_EOF'
%(steps_json)s
STEPS_EOF

if ! team lint-chain steps.json; then
    echo "orchestrate.sh: the chain's own request text is inconsistent, and not everything could be fixed automatically -- see the problems printed above, fix that step's request by hand, and rerun" >&2
    exit 1
fi

# Read steps.json back -- after lint-chain's own in-place fix it may not
# be byte-identical to what was just written above -- and turn it into
# four parallel bash arrays. `team steps-to-bash`, not an inline
# `python3 -c '...'`, is what does this.
eval "$(team steps-to-bash steps.json)"

echo "Starting generation phase..."
PIDS=(); NAMES=()
for i in "${!STEP_DIRS[@]}"; do
    dir="${STEP_DIRS[$i]}"; req="${STEP_REQS[$i]}"
    api="${STEP_APIS[$i]}"; flags="${STEP_FLAGS[$i]}"
    if [ -f "$dir/.orchestrate_done" ]; then
        echo "$dir already completed a previous run -- skipping regeneration (rm $dir/.orchestrate_done to force)"
        continue
    fi
    echo "launched $dir"
    if [ -n "$api" ]; then
        (mkdir -p "$dir" && cd "$dir" && team do --api "$api" $flags "$req" > generate.log 2>&1) &
    else
        (mkdir -p "$dir" && cd "$dir" && team do $flags "$req" > generate.log 2>&1) &
    fi
    PIDS+=("$!"); NAMES+=("$dir")
done

GEN_FAILED=0
for i in "${!PIDS[@]}"; do
    if wait "${PIDS[$i]}"; then
        echo "${NAMES[$i]} generation succeeded"
    else
        echo "${NAMES[$i]} generation failed" >&2
        GEN_FAILED=1
    fi
done
if [ "$GEN_FAILED" -ne 0 ]; then
    echo "orchestrate.sh: generation failed for at least one step -- see each step's own generate.log -- stopping before anything real runs" >&2
    exit 1
fi
echo "Generation phase succeeded."

# --- run phase: real dependency order, one step at a time, each
# watched to completion before the next starts (never nohup'd on its
# own -- see LOCAL.md, "nohup covers generation, not the real execution
# of a multi-step chain").
run_step() {
    # $1=name  $2=dir  $3.. = the OTHER steps' directories this one reads
    # an output.json from -- everything named in this step's own request
    # text as "../DIR/output.json". Computed automatically below from
    # steps.json; never typed by hand.
    local name="$1" dir="$2"; shift 2
    local deps=("$@")

    # A previous run of this script already executed this step for real
    # -- do not create a second project, a second task, a second unit.
    # `rm "$dir/.orchestrate_done"` forces a genuine re-run if you ever
    # actually want one.
    if [ -f "$dir/.orchestrate_done" ]; then
        echo "$name already succeeded in a previous run -- skipping (rm $dir/.orchestrate_done to force a real rerun)"
        return 0
    fi

    if [ ! -f "$dir/main.py" ]; then
        echo "$name: no main.py -- static content, nothing to run"
        touch "$dir/.orchestrate_done"
        return 0
    fi

    _run_step_try() { (cd "$dir" && python3 main.py); }

    echo "running $name"
    if _run_step_try; then
        echo "$name succeeded"
        touch "$dir/.orchestrate_done"
        return 0
    fi

    echo "$name failed -- asking team do --retry --run to repair it against the real failure it just produced" >&2
    (cd "$dir" && team do --retry --run < /dev/null)
    if _run_step_try; then
        echo "$name succeeded after repairing itself"
        touch "$dir/.orchestrate_done"
        return 0
    fi

    # A self-repair can fix one bug (a swallowed exception, say) and only
    # then unmask a second, different one -- and this bare `python3
    # main.py` retry is never seen by `team do --run`'s own mechanical
    # fixes, since it runs completely outside team.py. Before spending a
    # real repair attempt on whatever this now is, check whether it is a
    # version-uniqueness conflict, which is fixable with no model call at
    # all: `team fix-version-conflict` reruns this exact file for real
    # and, if the rejection names a colliding version literal, swaps in a
    # fresh uuid and reruns again on its own.
    echo "$name still fails -- checking for a mechanically-fixable version conflict before spending a repair attempt" >&2
    if (cd "$dir" && team fix-version-conflict); then
        echo "$name succeeded after a mechanical version-conflict fix (no model call)"
        touch "$dir/.orchestrate_done"
        return 0
    fi

    # Repairing this step's own code did not fix it. If it depends on
    # earlier steps' real output, the actual defect may be upstream --
    # a placeholder id, a missing output.json, a wrong key -- so repair
    # each declared dependency once and try again before giving up.
    if [ "${#deps[@]}" -gt 0 ]; then
        echo "$name still fails after repairing itself -- it depends on ${deps[*]}, so repairing those next" >&2
        local dep
        for dep in "${deps[@]}"; do
            (cd "$dep" && team do --retry --run < /dev/null)
        done
        if _run_step_try; then
            echo "$name succeeded after repairing its dependencies"
            touch "$dir/.orchestrate_done"
            return 0
        fi
    fi

    # Repairing dependencies didn't help either. One more self-repair
    # pass: whatever `python3 main.py` is failing on right now is real,
    # current output that `team do --retry --run` has never actually
    # seen yet (its own last probe was before the dependency repair, or
    # before this file even reached this state) -- so this is a genuine
    # second attempt against new information, not a repeat of the first.
    echo "$name still fails -- repairing itself once more against its current, real failure" >&2
    (cd "$dir" && team do --retry --run < /dev/null)
    if _run_step_try; then
        echo "$name succeeded after a second self-repair"
        touch "$dir/.orchestrate_done"
        return 0
    fi

    echo "$name failed again after repair" >&2
    return 1
}

echo "Starting run phase..."

%(run_step_calls)s

echo "Orchestration complete."
'''


def cmd_orchestrate_sh(args, cfg: swarm.Config, state: swarm.State) -> int:
    """Print one complete, working `orchestrate.sh` for `steps.json` --
    the `steps.json` here-doc, `lint-chain`, the write-phase `team do`
    fan-out, the `.env` export preamble, the full run-phase retry
    ladder, and the dependency-ordered `run_step` calls, all in one
    file, in one command.

    `team steps-to-bash` fixed the one shape that kept getting
    mis-copied inside this script (an inline `eval "$(python3 -c
    ...)"` program). This command originally fixed only the other half
    -- the `run_step` retry ladder and its calls -- and emitted it into
    a *second* file that called a `generate.sh` the caller was expected
    to produce separately with a second command. That split was
    measured, immediately, to recreate the exact class of failure both
    commands exist to prevent: an orchestrating agent ran only
    `orchestrate-sh`, got a script whose first real action was `bash:
    generate.sh: No such file or directory`, because nothing had ever
    created the other file. Splitting the output into two files did not
    remove a place to go wrong; it added one.

    So there is one command and one file. Everything the write phase
    needs -- the `steps.json` here-doc, `team lint-chain`, `team
    steps-to-bash`, the parallel `team do` fan-out -- runs first, real
    dependency order, one step at a time, watched. `run_step`'s own
    retry ladder (self-repair, then dependency repair, then give up) is
    still exactly the ~100-line function an orchestrating agent used to
    be expected to reproduce faithfully by hand; it is simply not
    something to copy anymore.

    Measured live, the shape this whole command exists to prevent: a
    generated `orchestrate.sh` for a real six-step chain had *no* retry
    logic in it at all -- `run_step` just ran `python3 main.py` once and
    returned 1 on failure. Nothing was wrong with the prose describing
    it; the agent assembling that particular script simply did not
    reproduce it, the same failure mode already hit and fixed once for
    a fragile `eval` line and once for a two-line `echo`. Stop asking
    anything to retype a script from memory; print the finished script.

    Dependencies are computed automatically, not typed by the caller: a
    step's `request` text naming `../OTHER_DIR/output.json` anywhere
    (the exact convention `intent.chain_output_json_problems` already
    parses for the identical reason) means this step depends on
    `OTHER_DIR`, and that becomes one of the trailing arguments on its
    `run_step` call. A request naming a directory that is not one of
    this chain's own steps is silently not added as a dependency --
    there is nothing here to repair by re-running a step outside this
    chain, and guessing at one would be exactly the kind of unproven
    fix this project has refused to make elsewhere.

    The `.env` path is this pool's own, resolved once from `team.py`'s
    location rather than hardcoded per project, so the emitted script
    is portable across whichever directory it is dropped into.
    """
    try:
        with open(args.steps, "r", encoding="utf-8") as fh:
            steps = json.load(fh)
    except (OSError, json.JSONDecodeError) as exc:
        print("could not read %s: %s" % (args.steps, exc), file=sys.stderr)
        return 2
    dirs: List[str] = []
    requests_by_dir: Dict[str, str] = {}
    for step in steps:
        try:
            dirname = str(step["dir"])
            request = str(step["request"])
        except (KeyError, TypeError) as exc:
            print("%s: each step needs \"dir\" and \"request\": %s"
                  % (args.steps, exc), file=sys.stderr)
            return 2
        dirs.append(dirname)
        requests_by_dir[dirname] = request

    dir_basenames = {os.path.basename(d): d for d in dirs}
    calls = []
    for dirname in dirs:
        request = requests_by_dir[dirname]
        deps = []
        for m in intent._OUTPUT_JSON_READ_RE.finditer(request):
            dep_name = m.group(1)
            dep_dir = dir_basenames.get(dep_name)
            if dep_dir is not None and dep_dir != dirname and dep_dir not in deps:
                deps.append(dep_dir)
        args_str = " ".join(shlex.quote(a) for a in ([dirname, dirname] + deps))
        calls.append("run_step %s || exit 1" % args_str)

    print(_ORCHESTRATE_RUN_STEP_TEMPLATE % {
        "env_path": shlex.quote(_SWARM_ENV_PATH),
        "steps_json": json.dumps(steps, indent=2),
        "run_step_calls": "\n".join(calls),
    })
    return 0


_BATCH_RUN_TEMPLATE = '''#!/bin/bash
# run_batch.sh -- generated by `team batch-sh`. Do not hand-edit this
# file's control flow; regenerate it with the same command instead if
# something about the chain needs to change. Hand-written versions of
# exactly this loop have twice reproduced the same two bugs: a per-run
# `nohup ... &` + `wait $!` pair that does not actually wait (the `&`
# backgrounds inside a subshell that then exits immediately, so `$!` in
# the parent never refers to the real job), and a missing check for
# whether a run's own orchestrate.log ever got written at all. Both are
# fixed here, mechanically, once, rather than left for every batch
# script to reproduce correctly by hand from LOCAL.md's prose.
#
# nohup THIS SCRIPT ONCE, e.g.:
#   nohup bash run_batch.sh > run_batch.log 2>&1 &
# Nothing inside it is nohup'd again -- each run blocks the one after it
# by construction (no `&`, no `nohup` on the per-run line below).
set -e
N=%(n)d

cat > .batch_steps.json <<"STEPS_EOF"
%(steps_json)s
STEPS_EOF

for i in $(seq 1 "$N"); do
  dir="run_$(printf "%%03d" "$i")"
  echo "=== starting $dir ($(date)) ==="
  mkdir -p "$dir"
  cp .batch_steps.json "$dir/steps.json"
  # NOT nohup'd, NOT backgrounded: this line has to block until
  # orchestrate.sh actually exits, or the next run starts before this
  # one is done.
  ( cd "$dir" &&
    team lint-chain steps.json &&
    team orchestrate-sh steps.json > orchestrate.sh &&
    bash orchestrate.sh > orchestrate.log 2>&1 )
  # Every run must leave its own orchestrate.log behind, inside its own
  # run_N/ -- not the outer run_batch.log, and not any one step's own
  # generate.log (write-phase only, exists even if the run phase never
  # ran). A run that produced nothing here failed silently in a way
  # nothing else here would surface.
  if [ ! -s "$dir/orchestrate.log" ]; then
    echo "=== WARNING: $dir produced no orchestrate.log -- something " \\
         "above never actually redirected into it ===" >&2
  fi
  echo "=== finished $dir ($(date)) ==="
done
'''


def cmd_batch_sh(args, cfg: swarm.Config, state: swarm.State) -> int:
    """Print one complete, working `run_batch.sh` for running the same
    `steps.json` chain `--n` times, sequentially, for repeatability or
    comparison testing.

    This is `orchestrate-sh` one recursion level up: that command exists
    because an orchestrating agent asked to reproduce the write-phase/
    run-phase shape by hand kept dropping pieces of it (a missing retry
    ladder, a fragile inline `eval`). Measured live, a hand-written batch
    driver dropped the equivalent pieces one level up instead: a `nohup
    ... &` + `wait $!` pair that never actually waited, so all N runs
    launched within moments of each other despite the loop iterating "in
    order", and a per-run `orchestrate.log` redirect that silently never
    happened. Both are fixed once, here, in code, rather than documented
    as prose a script has to reproduce correctly every time it is
    written from scratch.
    """
    try:
        with open(args.steps, "r", encoding="utf-8") as fh:
            steps = json.load(fh)
    except (OSError, json.JSONDecodeError) as exc:
        print("could not read %s: %s" % (args.steps, exc), file=sys.stderr)
        return 2
    if args.n < 1:
        print("--n must be at least 1", file=sys.stderr)
        return 2
    print(_BATCH_RUN_TEMPLATE % {
        "n": args.n,
        "steps_json": json.dumps(steps, indent=2),
    })
    return 0


def cmd_calibrate(args, cfg: swarm.Config, state: swarm.State) -> int:
    """Measure the timing model instead of trusting it.

    Each pair gets a small prompt and a large one, back to back. The first
    request pays whatever load cost is outstanding; the second is warm, so the
    difference isolates loading from compute, and the warm request is the one
    that tests the throughput model. Predictions here were within a few tenths
    of a second warm, which is why the honest headline number is the warm one.
    """
    global ASSUME_WARM
    ASSUME_WARM = True
    base = ("Explain in one short paragraph why binary search requires a "
            "sorted list. ")
    targets = pick_solvers(cfg, state, 0, count=99,
                           family=cfg.data.get("team", {}).get("restrict_to_family"))
    if not targets:
        print("no eligible nodes", file=sys.stderr)
        return 1

    print("%-10s %-26s %8s %8s %8s %7s" %
          ("node", "model", "prompt", "predict", "actual", "ratio"))
    print("-" * 74)
    warm_ratios: List[float] = []
    for node, model in targets:
        prefill, decode, _cold = rates(cfg, state, node, model)
        for i, mult in enumerate((1, args.long_mult)):
            prompt = base * mult
            ptoks = swarm.est_tokens(prompt)
            t0 = time.monotonic()
            try:
                r = swarm.chat_complete(
                    node, model, [{"role": "user", "content": prompt}],
                    num_ctx=swarm.pick_num_ctx(cfg, node, model, ptoks, 600,
                                               reasoning=False),
                    answer_tokens=args.answer_tokens, headroom=1.5, think=False,
                    temperature=0.0, timeout=900)
            except swarm.OllamaError as exc:
                print("%-10s %-26s  unreachable: %s" % (node.name, model, exc))
                break
            wall = time.monotonic() - t0
            sample = r["sample"]
            state.record_perf(node.name, model, sample)
            state.mark_resident(node.name, model)
            otoks = sample.get("output_tokens") or 0
            pt = sample.get("prompt_tokens") or ptoks
            load = float(sample.get("load_s") or 0.0)
            predict = pt / prefill + otoks / decode
            ratio = wall / predict if predict > 0.05 else 0.0
            tag = "cold +%.0fs" % load if load > 0.5 else "warm"
            print("%-10s %-26s %8d %7.1fs %7.1fs %6.2fx  %s"
                  % (node.name, model, pt, predict, wall, ratio, tag))
            if load <= 0.5:
                warm_ratios.append(ratio)

    print()
    if warm_ratios:
        warm_ratios.sort()
        median = warm_ratios[len(warm_ratios) // 2]
        print("warm compute accuracy: median %.2fx over %d samples"
              % (median, len(warm_ratios)))
        if 0.75 <= median <= 1.35:
            print("  the throughput model is accurate; schedule drift is load time.")
        else:
            print("  throughput model is off; measured rates will self-correct "
                  "as more samples land.")

    print("\nmeasured cold load (p75 of real loads, what a swap actually costs):")
    for node, model in targets:
        cold = state.cold_load_s(node.name, model)
        if cold:
            print("  %-10s %-26s %6.1fs" % (node.name, model, cold))
    print("\nLoading dominates compute on this hardware, so `team.py warm` "
          "before a run\nis worth more than any estimate tuning.")
    return 0


def cmd_crosscheck(args, cfg: swarm.Config, state: swarm.State) -> int:
    """Two models solve independently; disagreement is the escalation signal.

    A critic shown someone else's draft tends to anchor on it, so agreement
    means little. Two solutions derived without sight of each other are a real
    check, and because they run on separate nodes at the same time the second
    opinion costs almost nothing in wall-clock.
    """
    task_text = " ".join(args.task).strip() or sys.stdin.read().strip()
    if not task_text:
        print("nothing to check", file=sys.stderr)
        return 2

    team_cfg = cfg.data.get("team", {})
    family = team_cfg.get("restrict_to_family")
    solvers = pick_solvers(cfg, state, args.floor, count=args.n, family=family)
    if len(solvers) < 2:
        # A second opinion needs a second *machine*, since each holds one model
        # at a time. Both capable models live on the same box, so above floor 2
        # the pool cannot supply two independent answers however it is asked.
        # Dropping the floor is the only real option and is still worth doing:
        # a weaker model agreeing is weak evidence, but a weaker model
        # disagreeing is exactly the signal this command exists to surface.
        lower = args.floor
        while lower > 1 and len(solvers) < 2:
            lower -= 1
            solvers = pick_solvers(cfg, state, lower, count=args.n, family=family)
        if len(solvers) < 2:
            print("cross-check needs two machines and the pool has %d that can "
                  "run this; check ./swarm.py nodes" % len(solvers),
                  file=sys.stderr)
            return 1
        sys.stderr.write(
            "only one machine can serve floor %d -- both capable models sit on "
            "the same box -- so falling back to floor %d for a second, weaker "
            "opinion. Disagreement still counts; agreement means less.\n"
            % (args.floor, lower))

    sys.stderr.write("solving on %s in parallel\n"
                     % ", ".join("%s/%s" % (n.name, m) for n, m in solvers))
    t0 = time.monotonic()
    answers = solve_parallel(solvers, task_text, cfg, state)
    wall = time.monotonic() - t0
    good = [a for a in answers if a.get("answer")]
    for a in answers:
        sys.stderr.write("  %-26s %5.1fs %s\n"
                         % (a["target"], a["seconds"],
                            "error: %s" % a["error"] if a.get("error")
                            else "%d chars" % len(a["answer"])))
    if not good:
        print("every solver failed", file=sys.stderr)
        return 1

    # When the solvers agree, the content is settled and the only question is
    # which write-up to keep -- so prefer the stronger model's, which tends to
    # show its working rather than emit a bare number.
    def capability_of(entry: Dict[str, Any]) -> int:
        model = entry["target"].split("/", 1)[1]
        return int(cfg.model_meta(model).get("capability", 1))

    good.sort(key=lambda e: (-capability_of(e), e["seconds"]))
    out: Dict[str, Any] = {"answers": answers, "parallel_seconds": round(wall, 1)}

    if len(good) < 2:
        out["verdict"] = "SINGLE"
        print(good[0]["answer"])
        return 0

    judge = judging_model(cfg, state, int(team_cfg.get("judge_floor", 4)))
    if judge is None:
        judge = pick_role_model(cfg, state, int(team_cfg.get("critic_floor", 2)))
    jn, jm = judge  # type: ignore
    cmp_prompt = AGREEMENT_PROMPT.format(task=task_text[:3000],
                                         a=good[0]["answer"][:6000],
                                         b=good[1]["answer"][:6000])
    r = swarm.chat_complete(jn, jm, [{"role": "user", "content": cmp_prompt}],
                            num_ctx=swarm.pick_num_ctx(
                                cfg, jn, jm, swarm.est_tokens(cmp_prompt), 2400),
                            answer_tokens=300, headroom=2.0, temperature=0.0,
                            think=False, timeout=900)
    state.record_perf(jn.name, jm, r["sample"])
    state.mark_resident(jn.name, jm)
    verdict, diffs = parse_agreement(r["text"])
    out["agreement"] = {"target": "%s/%s" % (jn.name, jm), "verdict": verdict,
                        "differences": diffs}
    sys.stderr.write("agreement check on %s/%s: %s\n" % (jn.name, jm, verdict))

    out["escalated"] = False
    if verdict == "DIFFER" and not args.no_escalate:
        strongest = pick_role_model(cfg, state, int(team_cfg.get("reduce_floor", 4)))
        if strongest:
            sn, sm = strongest
            sys.stderr.write("they disagree; adjudicating on %s/%s\n" % (sn.name, sm))
            jp = ("Two independent attempts at the same task disagree. "
                  "Work out the correct answer.\n\nTASK:\n%s\n\nATTEMPT A (%s):\n%s\n\n"
                  "ATTEMPT B (%s):\n%s\n\nGive the correct final answer, and say in one "
                  "line which attempt was right and why."
                  % (task_text, good[0]["target"], good[0]["answer"],
                     good[1]["target"], good[1]["answer"]))
            fr = swarm.chat_complete(sn, sm, [{"role": "user", "content": jp}],
                                     num_ctx=swarm.pick_num_ctx(
                                         cfg, sn, sm, swarm.est_tokens(jp), 3000),
                                     answer_tokens=900, timeout=1800)
            state.record_perf(sn.name, sm, fr["sample"])
            state.mark_resident(sn.name, sm)
            out["escalated"] = True
            out["final"] = {"target": "%s/%s" % (sn.name, sm), "answer": fr["text"]}

    if args.json:
        print(json.dumps(out, indent=2))
    else:
        print((out.get("final") or good[0])["answer"])
        sys.stderr.write("\n[%s%s, %.1fs of parallel solving]\n"
                         % (verdict, ", adjudicated" if out["escalated"] else "", wall))
        for d in diffs:
            sys.stderr.write("  - %s\n" % d)
    return 0


def cmd_review(args, cfg: swarm.Config, state: swarm.State) -> int:
    task_text = " ".join(args.task).strip() or sys.stdin.read().strip()
    if not task_text:
        print("nothing to review", file=sys.stderr)
        return 2

    team = cfg.data.get("team", {})
    primary = team.get("primary_family", "gemma")

    drafter = pick_role_model(cfg, state, args.floor, family=primary)
    if not drafter:
        print("no drafter available in family %r" % primary, file=sys.stderr)
        return 1
    # Cross-family critique defaults off: the only foreign model tested here
    # matched its same-family neighbour for speed but flagged every correct
    # answer as a MAJOR error, and MAJOR is what triggers escalation.
    critic = judging_model(cfg, state, int(team.get("judge_floor", 4)),
                           exclude_family=primary if team.get(
                               "critic_prefers_other_family", False) else None)
    if critic is None:
        critic = pick_role_model(cfg, state, int(team.get("critic_floor", 2)))

    dn, dm = drafter
    sys.stderr.write("draft  : %s/%s\n" % (dn.name, dm))
    if critic:
        sys.stderr.write("critic : %s/%s (%s)\n"
                         % (critic[0].name, critic[1],
                            cfg.model_meta(critic[1]).get("family")))

    # Warm the critic while the drafter is working -- it is idle time otherwise.
    warmer = None
    if critic and not (state.resident_model(critic[0].name) or (None,))[0] == critic[1]:
        def do_warm(node=critic[0], model=critic[1]) -> None:
            try:
                swarm.chat(node, model, [{"role": "user", "content": "hi"}],
                           num_ctx=1024, num_predict=1, temperature=0.0, timeout=300)
                state.mark_resident(node.name, model)
            except swarm.OllamaError:
                pass
        warmer = threading.Thread(target=do_warm, daemon=True)
        warmer.start()

    policy = swarm.standing_policy()
    t0 = time.monotonic()
    draft = swarm.chat_complete(
        dn, dm, swarm.build_messages(task_text, None, "", False, policy),
        num_ctx=swarm.pick_num_ctx(cfg, dn, dm, swarm.est_tokens(task_text), 3000),
        answer_tokens=700, timeout=1800)
    draft_s = time.monotonic() - t0
    state.record_perf(dn.name, dm, draft["sample"])
    state.mark_resident(dn.name, dm)

    out: Dict[str, Any] = {
        "draft": {"target": "%s/%s" % (dn.name, dm), "seconds": round(draft_s, 1),
                  "answer": draft["text"]},
    }

    if not critic:
        out["critique"] = None
        print(json.dumps(out, indent=2))
        return 0

    if warmer:
        warmer.join()
    cn, cm = critic
    prompt = CRITIC_PROMPT.format(task=task_text[:4000], answer=draft["text"][:8000])
    t1 = time.monotonic()
    crit = swarm.chat_complete(
        cn, cm, [{"role": "user", "content": prompt}],
        num_ctx=swarm.pick_num_ctx(cfg, cn, cm, swarm.est_tokens(prompt), 2400),
        answer_tokens=300, headroom=2.0, think=False, temperature=0.0, timeout=900)
    crit_s = time.monotonic() - t1
    state.record_perf(cn.name, cm, crit["sample"])
    state.mark_resident(cn.name, cm)
    verdict, issues = parse_verdict(crit["text"])

    out["critique"] = {
        "target": "%s/%s" % (cn.name, cm),
        "family": cfg.model_meta(cm).get("family"),
        "seconds": round(crit_s, 1),
        "verdict": verdict,
        "issues": issues,
        "raw": crit["text"],
    }

    escalate_on = [s.upper() for s in team.get("escalate_on", ["MAJOR"])]
    out["escalated"] = False
    if verdict in escalate_on and not args.no_escalate:
        judge = judging_model(cfg, state, int(team.get("reduce_floor", 4)))
        if judge:
            jn, jm = judge
            sys.stderr.write("escalating to %s/%s (verdict %s)\n" % (jn.name, jm, verdict))
            jprompt = (
                "Two models disagree. Decide the correct answer.\n\n"
                "TASK:\n%s\n\nDRAFT (%s):\n%s\n\nCRITIQUE (%s, %s):\n%s\n\n"
                "Give the correct final answer. State briefly which concerns were valid."
                % (task_text, dm, draft["text"], cm, verdict, crit["text"])
            )
            t2 = time.monotonic()
            final = swarm.chat_complete(
                jn, jm, [{"role": "user", "content": jprompt}],
                num_ctx=swarm.pick_num_ctx(cfg, jn, jm, swarm.est_tokens(jprompt), 3000),
                answer_tokens=900, timeout=1800)
            state.record_perf(jn.name, jm, final["sample"])
            state.mark_resident(jn.name, jm)
            out["escalated"] = True
            out["final"] = {"target": "%s/%s" % (jn.name, jm),
                            "seconds": round(time.monotonic() - t2, 1),
                            "answer": final["text"]}

    if args.json:
        print(json.dumps(out, indent=2))
    else:
        answer = (out.get("final") or out["draft"])["answer"]
        print(answer)
        sys.stderr.write("\n[verdict %s%s]\n" % (
            verdict, ", escalated" if out["escalated"] else ""))
        for i in issues:
            sys.stderr.write("  - %s\n" % i)
    return 0


# --------------------------------------------------------------------------
# cli
# --------------------------------------------------------------------------


def cmd_warm(args, cfg: swarm.Config, state: swarm.State) -> int:
    """Load a model on every node at once and hold it there.

    Cold loads on this pool run 8-70 seconds, which is longer than most chunks
    take to run. A cold node is not spare capacity -- sending work to it costs
    more than doing the work locally, which is why fan-out quietly collapses
    onto one machine unless the pool is already warm.
    """
    targets: List[Tuple[swarm.Node, str]] = []
    for node in cfg.enabled_nodes():
        if args.node and node.name not in args.node:
            continue
        preferred = None
        for model in node.models:
            meta = cfg.model_meta(model)
            if float(node.model_bias.get(model, 1.0)) < 0.5:
                continue  # pinned out of rotation; warming it would evict the good one
            if preferred is None or int(meta.get("capability", 1)) < int(
                    cfg.model_meta(preferred).get("capability", 1)):
                preferred = model
        if args.floor:
            for model in node.models:
                if int(cfg.model_meta(model).get("capability", 1)) >= args.floor \
                        and float(node.model_bias.get(model, 1.0)) >= 0.5:
                    preferred = model
                    break
        if preferred:
            targets.append((node, preferred))

    results: Dict[str, str] = {}
    lock = threading.Lock()

    def warm(node: swarm.Node, model: str) -> None:
        t0 = time.monotonic()
        try:
            swarm.chat(node, model, [{"role": "user", "content": "hi"}],
                       num_ctx=1024, num_predict=1, temperature=0.0, timeout=600,
                       think=False)
            # Deliberately not recorded: a one-token probe measures nothing.
            state.mark_resident(node.name, model)
            msg = "warm in %.1fs" % (time.monotonic() - t0)
        except swarm.OllamaError as exc:
            msg = "FAILED %s" % exc
        with lock:
            results["%s/%s" % (node.name, model)] = msg

    threads = [threading.Thread(target=warm, args=t, daemon=True) for t in targets]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    for k in sorted(results):
        print("  %-26s %s" % (k, results[k]))
    print("\nSet OLLAMA_KEEP_ALIVE to hold these resident; otherwise they unload "
          "and the next fan-out pays the load cost again.")
    return 0


VERIFY_PROMPT = """You drafted a claim about the source below. Check it against the \
actual text before it goes any further -- a wrong claim that looks confident is worse \
than no claim, because it gets trusted.

For each specific claim in the draft, quote the exact line(s) from the source that \
support it. If you cannot find text in the source that actually supports a claim, \
drop that claim -- do not keep it because it sounds plausible.

Reply with only the surviving claims, each followed by its supporting quote in \
parentheses. If nothing survives, reply exactly: none found

SOURCE:
{source}

DRAFT CLAIMS:
{draft}"""


def cmd_split(args, cfg: swarm.Config, state: swarm.State) -> int:
    """Build a fan-out plan: the same prompt against many inputs."""
    tasks = []
    for i, path in enumerate(args.inputs):
        if os.path.isfile(path) and not args.literal:
            with open(path, "r", encoding="utf-8", errors="replace") as fh:
                body = fh.read()
            if args.max_chars:
                body = body[:args.max_chars]
            content = "%s\n\n--- %s ---\n%s" % (args.prompt, os.path.basename(path), body)
            label = os.path.basename(path)[:14]
        else:
            content = "%s\n\n%s" % (args.prompt, path)
            body = path
            label = ("item%d" % (i + 1))
        leaf_id = "t%d" % (i + 1)
        tasks.append({"id": leaf_id, "label": label, "prompt": content,
                      "floor": args.floor, "est_output": args.est_output})

        if args.verify:
            # Claims that don't survive being checked against their own source
            # get dropped here, before they reach the reduce step and get
            # written into a fix list as if they were fact.
            vprompt = VERIFY_PROMPT.format(source=body[:args.max_chars],
                                           draft="{{%s}}" % leaf_id)
            tasks.append({"id": "v%d" % (i + 1), "label": "verify-%s" % label,
                          "prompt": vprompt, "deps": [leaf_id],
                          "floor": max(args.floor, args.verify_floor),
                          "est_output": args.est_output})

    plan: Dict[str, Any] = {"goal": args.goal or args.prompt, "tasks": tasks}
    if args.reduce:
        plan["reduce"] = {"floor": args.reduce_floor,
                          "to": "assistant" if args.reduce_to_assistant else "model"}
    text = json.dumps(plan, indent=2)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as fh:
            fh.write(text + "\n")
        print("wrote %s (%d tasks%s)"
              % (args.out, len(tasks), ", + reduce" if args.reduce else ""))
    else:
        print(text)
    return 0


def cmd_run(args, cfg: swarm.Config, state: swarm.State) -> int:
    global ASSUME_WARM
    with open(args.plan, "r", encoding="utf-8") as fh:
        plan = Plan(json.load(fh))
    state.prune_leases(float(cfg.routing.get("stale_lease_s", 900)))

    if args.assume_warm:
        ASSUME_WARM = True
    assignments, makespan = schedule(plan, cfg, state)
    serial = serial_estimate(plan, cfg, state)

    print("goal: %s" % (plan.goal or "(none)"))
    print("%d tasks across %d nodes\n"
          % (len(assignments), len({a.node.name for a in assignments})))
    print(render_gantt(assignments, makespan))
    print("\npredicted makespan %s | serial would be %s | speedup %.1fx"
          % (swarm.human(makespan), swarm.human(serial),
             (serial / makespan) if makespan else 1.0))

    # The fan-out and the reduce behave nothing alike: one parallelises, the
    # other is a single long pole. Averaging them hides which one to attack.
    fan = [a for a in assignments if a.task.role != "reduce"]
    red = [a for a in assignments if a.task.role == "reduce"]
    if fan and red:
        fan_span = max(a.finish for a in fan)
        fan_serial = sum(a.finish - a.start for a in fan)
        red_span = sum(a.finish - a.start for a in red)
        print("  fan-out %s across %d nodes (%.1fx vs %s serial); "
              "reduce %s on the long pole"
              % (swarm.human(fan_span), len({a.node.name for a in fan}),
                 fan_serial / fan_span if fan_span else 1.0,
                 swarm.human(fan_serial), swarm.human(red_span)))
        if red_span > fan_span:
            print("  recombination dominates: consider --reduce-to-assistant, "
                  "or a tighter reduce output budget")

    if args.dry_run:
        return 0

    print()
    contexts = plan_contexts(assignments, plan, cfg)
    if cfg.data.get("team", {}).get("warm_first_use", True) and not args.no_warm:
        sys.stderr.write("warming %d nodes in parallel (at run context size)...\n"
                         % len({a.node.name for a in assignments}))
        warm_targets(assignments, cfg, state, contexts)

    sys.stderr.write("executing:\n")
    elapsed = execute(plan, assignments, cfg, state, verbose=True,
                      contexts=contexts)
    bundle = write_bundle(plan, elapsed, makespan)

    failed = [t.id for t in plan.tasks.values() if t.error]
    reduce_task = plan.tasks.get("reduce")
    to_assistant = getattr(plan, "reduce_to", "model") == "assistant"

    print("\ndone in %s (predicted %s)" % (swarm.human(elapsed), swarm.human(makespan)))
    if failed:
        print("failed tasks: %s" % ", ".join(failed))
    report_accuracy(assignments, plan)
    print("bundle: %s" % bundle)

    if args.json:
        print(json.dumps({
            "makespan_predicted_s": round(makespan, 1),
            "elapsed_s": round(elapsed, 1),
            "speedup_vs_serial": round(serial / makespan, 2) if makespan else 1.0,
            "bundle": bundle,
            "failed": failed,
            "tasks": [{"id": t.id, "target": t.actual_target,
                       "seconds": round(t.actual_seconds or 0, 1),
                       "chars": len(t.output or ""), "error": t.error}
                      for t in (plan.tasks[i] for i in plan.order)],
        }, indent=2))
    elif reduce_task and reduce_task.output and not to_assistant:
        print("\n--- final ---\n")
        print(reduce_task.output)
    elif to_assistant:
        print("\nreduce deferred to the assistant; findings are in the bundle above.")
    return 1 if failed else 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="team", description=__doc__.splitlines()[0])
    sub = p.add_subparsers(dest="cmd", required=True)

    sp = sub.add_parser("split", help="generate a fan-out plan from many inputs")
    sp.add_argument("prompt")
    sp.add_argument("inputs", nargs="+", help="files, or literal strings with --literal")
    sp.add_argument("--literal", action="store_true", help="treat inputs as text not paths")
    sp.add_argument("--goal", help="overall goal, used by the reduce step")
    sp.add_argument("--floor", type=int, default=1,
                    help="chunk work is small by construction; keep this low "
                         "so the fast cheap nodes stay eligible")
    sp.add_argument("--est-output", type=int, default=400)
    sp.add_argument("--max-chars", type=int, default=12000)
    sp.add_argument("--verify", action="store_true",
                    help="check each finding against its source before reduce sees it")
    sp.add_argument("--verify-floor", type=int, default=2)
    sp.add_argument("--reduce", action="store_true", help="append a recombination task")
    sp.add_argument("--reduce-floor", type=int, default=4)
    sp.add_argument("--reduce-to-assistant", action="store_true",
                    help="skip local synthesis; bundle findings for the assistant")
    sp.add_argument("--out", "-o")
    sp.set_defaults(func=cmd_split)

    rp = sub.add_parser("run", help="schedule and execute a plan")
    rp.add_argument("plan")
    rp.add_argument("--dry-run", action="store_true", help="show the schedule only")
    rp.add_argument("--no-warm", action="store_true")
    rp.add_argument("--assume-warm", action="store_true",
                    help="plan as if every node already holds its model, to see "
                         "what the pool is worth when kept warm")
    rp.add_argument("--json", action="store_true")
    rp.set_defaults(func=cmd_run)

    wp = sub.add_parser("warm", help="preload every node in parallel")
    wp.add_argument("--node", action="append", help="limit to these nodes")
    wp.add_argument("--floor", type=int, default=0,
                    help="warm the smallest model at or above this capability")
    wp.set_defaults(func=cmd_warm)

    bp = sub.add_parser(
        "between",
        help="after a failed round, write one note for the next round")
    bp.add_argument("--check", default="", help="the round's check command")
    bp.add_argument("--dir", default=".", help="project directory")
    bp.set_defaults(func=cmd_between)

    dp = sub.add_parser("do",
                        help="say what you want; the pool decides how to run it")
    dp.add_argument("request", nargs="*")
    dp.add_argument("--kind", choices=["code", "audit", "ask"],
                    help="skip triage and force a mode")
    dp.add_argument("--paths", nargs="*", help="files the request concerns")
    dp.add_argument("--attach", nargs="*", metavar="FILE",
                    help="reference files -- a design doc, a schema, an "
                         "example of the wanted output -- given to the "
                         "planner and to every writer. Any file type. Sticks "
                         "to this directory until changed, and is re-read "
                         "each run, so editing one takes effect without "
                         "re-attaching. Pass --attach with no files to clear")
    dp.add_argument("--api", metavar="NAME",
                    help="an OpenAPI spec to work against -- a registered "
                         "name (./openapi.py --list) or a path. Sliced "
                         "against this request rather than attached whole, "
                         "so a 291-operation spec costs a few thousand "
                         "tokens instead of 111k")
    dp.add_argument("--api-limit", type=int, default=12, metavar="N",
                    help="most endpoints to include in full with --api")
    dp.add_argument("--no-mock", action="store_true",
                    help="with --api, do not stand up a local stand-in for "
                         "the service. The gates then cannot exercise any "
                         "call, since they are barred from the network")
    dp.add_argument("--check", help="shell command generated code must pass")
    dp.add_argument("--tests", action="store_true",
                    help="have a model write an invariant test per component "
                         "before writing the code. Off by default: measured "
                         "six for six wrong across two runs, at 41%% of the "
                         "pool's total compute. Prefer a hand-written --check")
    dp.add_argument("--no-tests", action="store_true",
                    help=argparse.SUPPRESS)
    dp.add_argument("--retry", action="store_true",
                    help="rewrite only the components that failed last time in "
                         "this directory, feeding each one the error it died "
                         "on. Keeps the parts that already passed")
    dp.add_argument("--file", metavar="PATH",
                    help="with --retry: rewrite this file even though it "
                         "passed its own gates last time, using --error as "
                         "the failure to fix. For an error only found by "
                         "actually running the code -- against the real "
                         "API, with real input -- which the gates cannot "
                         "see and so cannot have failed on")
    dp.add_argument("--error", metavar="TEXT",
                    help="the error --file died on when you ran it. "
                         "@path reads it from a file instead, e.g. "
                         "--error @traceback.txt -- the natural way to hand "
                         "over something pasted from a terminal")
    dp.add_argument("--run", action="store_true",
                    help="with --retry: instead of pasting a traceback with "
                         "--error, actually run --file (or the plan's own "
                         "entry point, if --file is omitted) here and now, "
                         "with your real environment, and feed whatever it "
                         "prints to the repair loop directly -- nothing "
                         "goes through a shell, so there is no quoting to "
                         "clean up. Exits without changing anything if the "
                         "run is clean")
    dp.add_argument("--audit", action="store_true",
                    help="also review the result with the pool. Off by "
                         "default: measured at three quarters of a run's wall "
                         "clock while confirming two findings that were both "
                         "wrong. Parse checks and the static detectors run "
                         "either way, because those are free and accurate")
    dp.add_argument("--out", help="target file if decomposition is skipped")
    dp.add_argument("--single-file", action="store_true",
                    help="skip the planner entirely and write exactly one "
                         "file (--out, default main.py). Every piece of "
                         "--api handling (slicing, closures, the mock, "
                         "credential names, the REQUIRED-endpoint check) "
                         "still runs exactly as it does for a multi-file "
                         "plan -- none of it depends on how many files the "
                         "result is split into. Use this for a genuinely "
                         "single-capability request instead of letting the "
                         "planner default to a client.py/main.py split that "
                         "buys nothing when nothing else shares client.py")
    # Was 6, then 3 (see the history above this line for why 6 -> 3: the
    # race/hedge machinery gives a stuck attempt a way out other than more
    # attempts on the same box). Lowered again, 3 -> 2, because `repair`
    # sets the attempt count for the two rungs that actually dominate
    # wall-clock -- the initial attempt and the whole-loop restart, both
    # called with `attempts=repair` -- while every rung below that
    # (own-test retry, fallback, escalation) already floors at
    # `max(1, repair - 2)` = 1 regardless of whether this is 3 or 2. So
    # this is not a small trim: worst case sequential cost (no idle boxes
    # to race) drops from 3+3=6 attempts to 2+2=4 before the ladder's
    # escalation/replan machinery ever gets a turn, and when idle boxes
    # *are* available the restart rung already races every one of them
    # for free, so reaching it one attempt sooner costs nothing extra.
    # The overall ladder (restart, fallback, escalation, replan) is
    # structurally stronger than repeating the same context on the same
    # box a third time -- get there sooner.
    dp.add_argument("--repair", type=int, default=2)
    dp.add_argument("--answer-tokens", type=int, default=3000)
    dp.add_argument("--dry-run", action="store_true",
                    help="show the decomposition without writing anything")
    dp.add_argument("--no-audit", action="store_true")
    dp.add_argument("--no-ground", action="store_true",
                    help="skip reading existing files locally on e2b to "
                         "disambiguate a vague request before planning")
    dp.add_argument("--json", action="store_true")
    dp.set_defaults(func=cmd_do)

    gp = sub.add_parser("code",
                        help="write code on the pool; keep it only if it passes")
    gp.add_argument("spec", nargs="*", help="what to build")
    gp.add_argument("--out", help="file to write")
    gp.add_argument("--batch", help="JSON list of {out, spec, check?} jobs")
    gp.add_argument("--check", help="shell command that must pass, e.g. a test run")
    gp.add_argument("--floor", type=int, default=4,
                    help="minimum capability allowed to write (4 = hard tier)")
    gp.add_argument("--ceiling", type=int, default=0, metavar="N",
                    help="how far above the floor a writer may be. 0, the "
                         "default, means exactly the floor tier, so --floor 2 "
                         "cannot quietly enrol the hard-tier model on "
                         "boilerplate it would spend minutes on")
    gp.add_argument("-n", type=int, default=3,
                    help="how many writers may work in parallel on a batch")
    # See `do`'s identical --repair default above for why this is 2, not
    # 3 or 6: `repair` sets the attempt count for the two rungs that
    # dominate wall-clock (the initial attempt and the whole-loop
    # restart), while every cheaper rung already floors at 1 attempt
    # either way -- and the race/hedge machinery gives a stuck attempt a
    # way out other than repeating the same context on the same box.
    gp.add_argument("--repair", type=int, default=2,
                    help="attempts before giving up and restoring the original")
    gp.add_argument("--answer-tokens", type=int, default=3000)
    gp.add_argument("--think", action="store_true",
                    help="let the writer reason first; off by default because "
                         "thinking and answer share one token budget and an "
                         "overrun emits no answer at all")
    gp.add_argument("--audit", action="store_true",
                    help="run the evidence-backed audit over what was written")
    gp.set_defaults(func=cmd_code)

    lp = sub.add_parser("lint-chain",
                        help="check a multi-step chain's request text "
                             "against itself before running any of it")
    lp.add_argument("steps", help="JSON array of {\"dir\": ..., "
                                  "\"request\": ...} objects, in run order")
    lp.add_argument("--check-only", action="store_true",
                    help="report problems without rewriting the steps "
                         "file; by default this command repairs "
                         "whatever is mechanically fixable (a missing "
                         "write promise whose key name a consumer "
                         "already stated) in place, and still exits 1 "
                         "for whatever it cannot prove how to fix")
    lp.set_defaults(func=cmd_lint_chain)

    sb = sub.add_parser("steps-to-bash",
                        help="print steps.json as bash array assignments "
                             "ready to eval -- replaces the fragile inline "
                             "'eval \"$(python3 -c ...)\"' shape in the "
                             "generate.sh/orchestrate.sh templates")
    sb.add_argument("steps", help="JSON array of {\"dir\": ..., "
                                  "\"request\": ...} objects, in run order")
    sb.set_defaults(func=cmd_steps_to_bash)

    ob = sub.add_parser("orchestrate-sh",
                        help="print one complete, working orchestrate.sh "
                             "for steps.json -- the write-phase team-do "
                             "fan-out, the .env preamble, the full retry "
                             "ladder, and dependency-ordered run_step "
                             "calls, all in one file, so nothing has to "
                             "be hand-copied from LOCAL.md's template or "
                             "split across two generated scripts")
    ob.add_argument("steps", help="JSON array of {\"dir\": ..., "
                                  "\"request\": ...} objects, in run order")
    ob.set_defaults(func=cmd_orchestrate_sh)

    bb = sub.add_parser("batch-sh",
                        help="print one complete, working run_batch.sh "
                             "that runs the same steps.json chain --n "
                             "times, sequentially, each run to its own "
                             "run_N/ with its own orchestrate.log -- the "
                             "batch-of-runs shape one level above "
                             "orchestrate-sh, generated instead of "
                             "hand-written for the same reason")
    bb.add_argument("steps", help="JSON array of {\"dir\": ..., "
                                  "\"request\": ...} objects, in run order")
    bb.add_argument("--n", type=int, default=5,
                    help="how many sequential runs to generate (default 5)")
    bb.set_defaults(func=cmd_batch_sh)

    fv = sub.add_parser("fix-version-conflict",
                        help="run a component's file for real, and if it "
                             "fails on a version-already-exists rejection, "
                             "mechanically swap in a fresh uuid and rerun "
                             "-- no model call. Meant to be called from "
                             "bash (see orchestrate.sh's run_step) between "
                             "a bare 'python3 main.py' retry and spending "
                             "a real 'team do --retry --run' attempt.")
    fv.add_argument("--dir", default=None,
                    help="directory to run in (default: cwd)")
    fv.add_argument("--file", default="main.py",
                    help="the file to execute, relative to --dir "
                         "(default: main.py)")
    fv.set_defaults(func=cmd_fix_version_conflict)

    kp = sub.add_parser("calibrate",
                        help="measure predicted vs actual timing on every node")
    kp.add_argument("--long-mult", type=int, default=12,
                    help="prompt size multiplier for the warm probe")
    kp.add_argument("--answer-tokens", type=int, default=200)
    kp.set_defaults(func=cmd_calibrate)

    ap = sub.add_parser("audit",
                        help="find bugs, checking every claim against real source")
    ap.add_argument("paths", nargs="+", help="files or directories to audit")
    ap.add_argument("--floor", type=int, default=2,
                    help="minimum capability for the reviewers")
    ap.add_argument("-n", type=int, default=3, help="how many reviewers in parallel")
    ap.add_argument("--no-second", action="store_true",
                    help="skip second-judge confirmation of confirmed findings")
    ap.add_argument("--keep-going", action="store_true",
                    help="review even if some files fail to parse")
    ap.add_argument("--verbose", action="store_true",
                    help="also show refuted claims")
    ap.add_argument("--json", action="store_true")
    ap.set_defaults(func=cmd_audit)

    cp = sub.add_parser("crosscheck",
                        help="two nodes solve independently; disagreement escalates")
    cp.add_argument("task", nargs="*")
    cp.add_argument("--floor", type=int, default=2)
    cp.add_argument("-n", type=int, default=2, help="how many independent solvers")
    cp.add_argument("--no-escalate", action="store_true")
    cp.add_argument("--json", action="store_true")
    cp.set_defaults(func=cmd_crosscheck)

    vp = sub.add_parser("review", help="one model drafts, another critiques it")
    vp.add_argument("task", nargs="*")
    vp.add_argument("--floor", type=int, default=2)
    vp.add_argument("--no-escalate", action="store_true")
    vp.add_argument("--json", action="store_true")
    vp.set_defaults(func=cmd_review)

    return p


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    cfg = swarm.Config.load()
    state = swarm.State()
    try:
        return args.func(args, cfg, state)
    except KeyboardInterrupt:
        return 130
    finally:
        state.close()


if __name__ == "__main__":
    sys.exit(main())
